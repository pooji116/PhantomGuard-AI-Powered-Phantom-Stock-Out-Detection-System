# PhantomGuard demo deployment

This guide prepares the project for a **public synthetic-data demo**. It does not turn the project into a production retail SaaS and does not publish it for you.

## 1. Build demo artifacts

Use Python 3.11–3.13 and install the project dependencies in a clean environment. From the project root:

```powershell
python -m pip install -r requirements-core.txt
python -m pip install -r requirements-saas.txt
python scripts/run_pipeline.py --stage all
```

The committed demonstration inputs contain 18 months for 25 stores and 800 SKUs. The pipeline writes the processed feature panel, model/baseline predictions, ranked alerts, and synthetic evaluation report into ignored output folders. Run this step in the release/build environment after each data or model change. It may need several gigabytes of temporary memory; do not run it on a small web-service startup tier.

All incidents and labels are simulated. They are separate from prediction features and must be described as synthetic in any public presentation. Never claim this demo's metrics as official hackathon results or as verified store incidents.

## 2. Deploy the API

Deploy the repository root as the API service. Use a persistent release artifact containing `data/processed/`, `data/predictions/`, and `reports/evaluation/metrics.json` from step 1. Start it with:

```text
python -m uvicorn backend.main:app --host 0.0.0.0 --port $PORT
```

Set these environment variables on the API service:

```text
PHANTOMGUARD_CORS_ORIGINS=https://YOUR-FRONTEND-DOMAIN
PHANTOMGUARD_ALLOW_AUDIT_WRITES=false
```

The read-only setting is important for a public demo: the current tenant header is a demo label, not login or authorization. With audit writes disabled, the API rejects new inspection outcomes and does not return saved audit rows. Keep generated data public-safe and synthetic.

## 3. Deploy the frontend

Deploy `frontend/` as a Next.js application using Node.js 20.9 or newer. The default same-origin setup keeps the API URL on the server: leave `NEXT_PUBLIC_API_BASE=/api/v1` and set `PHANTOMGUARD_INTERNAL_API_URL` to the deployed API's HTTPS origin (without `/api/v1`). Next.js will proxy browser requests to FastAPI, so configure the API to allow requests from the Next.js server if needed.

For a separately hosted API that the browser calls directly, set this build-time variable instead:

```text
NEXT_PUBLIC_API_BASE=https://YOUR-API-DOMAIN/api/v1
```

Build with `npm ci` and `npm run build`; serve with `npm start`. In direct-browser mode, ensure the frontend origin exactly matches `PHANTOMGUARD_CORS_ORIGINS`, and that the API is reachable over HTTPS.

## 4. Release checks

- Confirm `/api/v1/health` reports `data_ready: true` and `audit_writes_enabled: false`.
- Open the frontend and check that the connection badge says **Public demo · view only**.
- Confirm the store list and alert cards load, a product chart opens, and the Reports page shows the synthetic evaluation and annual estimate.
- Confirm the service returns no more than 20 alerts for any selected store/date.
- Confirm an inspection outcome cannot be submitted in read-only mode.
- Keep the synthetic-data, uncalibrated-risk, and estimated-revenue caveats visible.

For a real store deployment, add user authentication and store-scoped authorization, private data isolation, a managed database with migrations/backups, secrets management, request limits, monitoring, and a security review before enabling inspection writes.
