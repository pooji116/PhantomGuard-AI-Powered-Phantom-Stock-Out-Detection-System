# PhantomGuard project plan

## Business problem and objective

Stores can show positive system inventory while the shelf is empty and sales stay at zero. Replenishment then fails because the system believes stock exists. PhantomGuard ranks SKU-store-date combinations that look like **phantom inventory** so a manager can inspect **at most 20 SKUs per store per day**.

Outputs are **risk estimates that require physical verification**. They do not prove theft, misplacement, or a physical stockout.

## Data assumptions

- Observation key: `date + store_id + sku_id`.
- The supplied combined `sales_data.csv` is integrated, but it is not accompanied by verified anomaly labels or an official evaluator.
- A **synthetic demonstration generator** writes CSVs to `data/raw/` and `data/sample/`.
- Synthetic labels are **not** organizer ground truth.
- Absent SKU-store-days are **not** filled as zero sales unless `missing_dates.fill_as_zero_sales` is enabled.
- Labels are optional at inference time.

Expected logical tables: daily sales, daily on-hand, promotions, store master, optional labels.

## Architecture

```
raw CSVs → prepare_data → master panel
        → features (leakage-safe)
        → baseline rules
        → supervised model (optional GBDT / sklearn)
        → rank_alerts (priority = p × expected daily revenue loss; cap 20)
        → evaluate (independent model and baseline on a shared untouched chronological test window)
        → Streamlit app
```

## Module responsibilities

| Module | Responsibility |
|---|---|
| `src/config.py` | YAML + path helpers |
| `src/prepare_data.py` | Load, map, validate, join, quality report |
| `src/features.py` | Time-aware features, allowlist |
| `src/baseline.py` | Explainable rules |
| `src/model.py` | Chronological training, optional LightGBM/XGBoost |
| `src/rank_alerts.py` | Top-20 ranking, reasons |
| `src/business_impact.py` | Potential revenue math |
| `src/evaluate.py` | Precision@20 macro/micro, recall |
| `src/inspections.py` | Transactional SQLite persistence for shelf-check outcomes |
| `src/dashboard_helpers.py` | Safe store-day filtering and empty-state helpers |
| `app/app.py` | Manager dashboard |
| `scripts/generate_demo_data.py` | Synthetic demo |
| `scripts/run_pipeline.py` | CLI orchestration |

## Data leakage safeguards

- Rolling statistics are **shifted** by one observation.
- Cross-store SKU demand uses **previous-day** aggregates.
- Labels never enter the feature allowlist, ranking features, revenue formulas, or operational dashboard filters.
- Splits are chronological.
- Contiguous labeled anomaly events that cross train/validation/test boundaries are purged before supervised fitting/scoring.
- Calibration uses cross-validation within the training window; validation labels remain reserved for model selection and reporting.
- Scoring time is explicit: default `end_of_day` (today's sales known after close).

## Feature engineering strategy

Demand lags (1/7/14), rolling 7/28 mean/median/std, velocity, weekday baseline, inventory streaks with positive stock, stock-to-demand ratio, promo/store context, lag-1 cross-store SKU demand. See `reports/feature_dictionary.md`.

## Baseline and ML

- Baseline: positive on-hand + zero-sales streak + expected demand + history checks.
- ML: LightGBM and XGBoost when importable; otherwise `HistGradientBoostingClassifier`. These model packages and SHAP are optional extras in `requirements-optional.txt`.
- Model **selection metric is validation Precision@20**, not accuracy.

## Ranking methodology

`priority_score = predicted_probability * estimated_daily_potential_recovery`

`daily_revenue_at_risk = expected_daily_demand * unit_selling_price`; `potential_recovery = daily_revenue_at_risk * recoverable_fraction`.

If prices are missing, rank by probability only and flag reduced reliability. Never pad to 20.

## Evaluation methodology

- Precision@20 **macro** (mean of store-day precisions) and **micro** (pooled selected alerts).
- Rank the complete candidate population before looking at labels; unlabeled selected alerts consume slots but are omitted from the precision denominator.
- Recall on **labeled** positives only.
- Unlabeled rows are omitted, not treated as negatives.
- If an organizer `evaluate.py` appears at repo root, it is the official contract and must not be overwritten.

## Revenue estimation assumptions

- Recoverable fraction default **50%** (configurable).
- Uses expected demand, not today's zero sales.
- Consecutive store-SKU alerts collapse to incidents to limit double counting.
- Actual recovered revenue is not measured from inspection outcomes and is shown as unavailable.
- Annualization is a linear projection, not a forecast.
- Amounts are **potential** INR, never confirmed recovery.

## Dashboard requirements

Implemented in `app/app.py`: centered mobile-style Home / Checks / Reports flow, large risk cards, product detail charts, progress, persistent inspection actions, and friendly performance/impact summaries. It defaults to the newest date/store with alerts. Empty alert lists keep the full navigation available.

## Testing strategy

Pytest covers schema/duplicates/dates, lag alignment, no future leak, no label leak, prediction without labels, ranking cap, priority formula, missing prices, precision/recall, revenue arithmetic, empty inputs.

## Execution commands

See README. Typical path:

```powershell
python scripts/generate_demo_data.py
python scripts/run_pipeline.py --stage all
python -m streamlit run app/app.py
pytest
```

## Milestones and implementation status

| Stage | Status |
|---|---|
| 1. Plan, README, config, tree | Implemented |
| 2. Prepare / quality report | Implemented |
| 3. Features | Implemented |
| 4. Baseline | Implemented |
| 5. Supervised ML + chrono split | Implemented; predictions tagged train/validation/test, final test period held out |
| 6. Top-20 ranking | Implemented; duplicate SKU-store-day inputs rejected |
| 7. Evaluation + business impact | Independent prediction files evaluated on common test candidates; revenue-at-risk/recovery/recovered values separated |
| 8. Streamlit | Home / Checks / Reports mobile-style navigation, risk cards, product details/chart, SQLite check outcomes and progress; AppTest smoke test passes |
| 9. Tests, notebook, verification | Tests cover combined-source ingestion, chronology/event-boundary leakage, ranking uniqueness/budget, evaluation denominators, inspection persistence, dashboard empty states, and impact arithmetic |

Latest verification: **46 pytest tests passed**, including a Streamlit `AppTest` render, latest-alert default selection, inspection outcomes, and deterministic synthetic anomaly tests; `python scripts/run_pipeline.py --stage all` completed on the supplied unlabeled CSV with an empty eligible alert list and withheld evaluation metrics. The synthetic `--demo` path was separately verified not to write into `data/raw/`.

## Known limitations and future improvements

- `data/raw/sales_data.csv` is an unlabeled retail-style panel, not confirmed hackathon ground truth. It has no positive-stock/zero-sales rows, so the current rule produces no eligible alerts and no labeled evaluation is possible. No official evaluator is present.
- Synthetic demo inputs live in `data/sample/`; the explicit `--demo` pipeline path uses them without replacing real inputs.
- The supplied dataset has no shelf/backroom verification, unit cost, or margin. It cannot support cause attribution or profit calculations.
- LightGBM / XGBoost / SHAP are optional and may be absent on newer Python versions.
- Panel rolling uses observed rows, not a filled calendar (by design).
- Promotion windows on large files use a simple loop; replace with interval joins for 10M+ rows.
- SHAP waterfall plots are optional and not required to launch the app.
- Stretch hypothesis categories are heuristics, not diagnoses.
