# PhantomGuard

**Detect suspicious phantom-inventory SKUs and rank a daily shelf-audit list of at most 20 items per store.**

## Business problem

A store can report positive on-hand inventory while the shelf is empty. Sales stay at zero, replenishment never fires, and lost sales go unnoticed. PhantomGuard scores SKU-store-days where **recorded stock and sales behaviour disagree**, then ranks the most valuable inspection candidates.

A model score is a **risk estimate**. It does not prove theft, misplacement, or a physical stockout.

## How PhantomGuard works

1. Join sales, on-hand, promotions, and store attributes on `date + store_id + sku_id`.
2. Build leakage-safe demand, inventory, context, and cross-store features.
3. Score a transparent rule-based baseline.
4. Train a classifier on **permitted labeled** history with a chronological split (when labels exist).
5. Rank by model risk score × expected daily potential recovery, keeping **≤ 20 unique alerts per store-day**.
6. Estimate gross sales at risk separately from potentially recoverable sales; actual recovery is not measured by the current project.

Default **scoring time** is `start_of_day`: the queue uses the current recorded inventory snapshot and known calendar context, with sales evidence only through the previous completed calendar day. Missing daily observations break a zero-sales streak; absent rows are not treated as zero sales. This makes the list usable before today's sales are recorded.

The default alert rule requires two consecutive completed zero-sales days while recorded stock is positive. This avoids escalating a single unusual day; minimum expected demand and at least three prior positive-sales days also keep routine slow movers out of the queue. The model uses sigmoid calibration fitted within the training period when supported; the API and UI identify the value as a model score if calibration is unavailable. Set `features.scoring_time: end_of_day` only when ranking after that date's sales have closed.

## Architecture

```mermaid
flowchart LR
  raw[Raw sales / inventory / promo / stores]
  prep[prepare_data]
  feat[features]
  base[baseline]
  mdl[model]
  rank[rank_alerts]
  eval[evaluate]
  app[Streamlit dashboard]
  raw --> prep --> feat --> base --> rank
  feat --> mdl --> rank
  rank --> eval
  rank --> app
```

## Dataset requirements and expected schemas

Place organizer files in `data/raw/` using the names in `config/config.yaml` (or change the config). Column names are mapped in `columns:`.

**sales.csv (required)**

| Logical column | Default source name |
|---|---|
| date | date |
| store_id | store_id |
| sku_id | sku_id |
| sales | units_sold |
| unit_price | unit_price (optional) |
| promo_flag | promo_flag (optional) |

**inventory.csv (required):** date, store_id, sku_id, on_hand

**promotions.csv (optional):** either daily `promo_flag` on the same key, or `sku_id, start_date, end_date`

**stores.csv (optional):** store_id, store_size, format, city_tier

**labels.csv (optional, training/eval only):** date, store_id, sku_id, is_phantom

The provided `sales_data.csv` is integrated as a combined daily sales/inventory panel. It is a retail-style dataset, not confirmed hackathon ground truth. PhantomGuard does not treat any of its records as verified phantom-stock incidents. No official evaluator is present in this repository.

## Installation

### Windows PowerShell

```powershell
cd PhantomGuard
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If LightGBM, XGBoost, or SHAP fail to install, continue. The pipeline falls back to scikit-learn and skips SHAP.

These packages are optional and are kept out of the core install. To try them separately after the project works, run `python -m pip install -r requirements-optional.txt`. SHAP may need a compatible prebuilt wheel or C++ build tools on some Python/Windows combinations; the dashboard and main pipeline do not require it.

### Linux / macOS

```bash
cd PhantomGuard
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## How to place supplied data files

1. Copy CSVs/Parquet/Excel into `data/raw/` (the supplied source copy is `data/raw/sales_data.csv`; the original in Downloads was left untouched).
2. Align filenames with `config/config.yaml` → `files:` or edit those entries.
3. Align `columns:` with the real headers. Do not rename the original raw files in place if you need to keep them pristine; mapping is enough.
4. Set `project.synthetic_demo: false`.

## How to run the project in this checkout

This folder is currently configured for a reproducible synthetic hackathon demonstration. The generated data is stored in `data/hackathon_demo/`; the supplied `data/raw/sales_data.csv` is retained separately and is not overwritten or used as synthetic ground truth.

Generate the dataset once, then build predictions and evaluation artifacts:

```powershell
python scripts/generate_demo_data.py
python scripts/run_pipeline.py --stage all
python -m streamlit run app/app.py --server.port 8502
```

Regenerate the pipeline artifacts after changing source data or `features.scoring_time`; otherwise the app can continue serving an older ranked queue.

The generator creates 548 daily dates for 25 stores × 800 SKUs (10,960,000 SKU-store-days), with weekday and seasonal demand patterns, promotion periods, store attributes, and separate synthetic incident labels. Labels include phantom stock-outs and two stretch signal types (misplaced shelf and delisted item). They are only used for training/evaluation, never as model input. All generated results are simulation evidence, not confirmed real-world incidents or organizer scores.

For a normal virtual environment, activate `.venv` first. On this machine, if the Python launcher is not on PATH, use its full path, for example:

```powershell
& 'C:\Users\Poojitha\AppData\Local\Python\bin\python.exe' scripts/generate_demo_data.py
& 'C:\Users\Poojitha\AppData\Local\Python\bin\python.exe' scripts/run_pipeline.py --stage all
& 'C:\Users\Poojitha\AppData\Local\Python\bin\python.exe' -m streamlit run app/app.py --server.port 8502
```

**Individual stages:** `--stage prepare|features|baseline|train|rank|evaluate`

## How to train and evaluate

Training uses labeled rows only and a chronological split (`splits.train_frac` / `valid_frac`, or explicit `train_end` / `valid_end`).

```powershell
python scripts/run_pipeline.py --stage train
python scripts/run_pipeline.py --stage evaluate
```

Metrics are written to `reports/evaluation/`. If `project.synthetic_demo` is true, treat every number as a demo, not a leaderboard score.

Prediction does not require the label column.

## How to launch Streamlit

```powershell
python -m streamlit run app/app.py
```

The app reads `data/predictions/ranked_alerts.parquet` (CSV fallback). If artifacts are missing, it shows setup instructions instead of crashing.

## Evaluation metrics

| Metric | Definition |
|---|---|
| Precision@20 (macro) | For each store-day, fraction of selected labeled alerts that are positive; then average store-days. |
| Precision@20 (micro) | Same fraction pooled over all selected labeled alerts. |
| Recall | Captured labeled positives / all labeled positives in the evaluation population. |
| F1@5 / F1@20 | Harmonic mean of micro Precision@k and recall at that same k. |

Alerts are ranked from the **full candidate population** before labels are consulted. Unlabeled selected rows occupy inspection slots but are excluded from the selected-labeled precision denominator; they are never counted as negatives. The report also includes a fixed-k denominator value (`hits / k`) so the convention is visible. Recall uses labeled positives only. Precision@20 cannot distinguish rankings on a store-day with fewer than 20 eligible candidates because all eligible candidates fit; fixed-k precision also decreases when fewer than k candidates exist. This code is a project evaluation utility, not an organizer evaluator. If the organizer supplies `evaluate.py`, use it as the authoritative score contract.

Evaluation uses the final chronological test period, which is kept out of model fitting and validation-based model selection. The saved synthetic artifacts were scored in separate model and baseline passes; boundary-crossing synthetic events are purged from the model candidate set, so the two saved candidate counts differ and their scores are not a paired comparison. Re-run the pipeline before presenting updated results. Read the evaluated date range, candidate counts, and denominator policy in the report.

## Business-impact assumptions

- `daily_revenue_at_risk = expected_demand * observed_unit_price`
- `daily_potential_recovery = daily_revenue_at_risk * recoverable_fraction`
- Ranking uses `predicted_probability * daily_potential_recovery`; missing prices trigger probability-only ranking.
- Default recoverable fraction: **0.50** (`ranking.recoverable_fraction`)
- Incident totals use a capped zero-sales streak (`business_impact.estimated_affected_days_cap`). Consecutive alert dates for one store-SKU are grouped and the highest streak-based estimate is counted once.
- Annualization = deduplicated period potential recovery × 365 / full observed store days — a projection, not a guarantee.
- Actually recovered revenue is **not measured**; an inspection finding does not establish recovered sales.
- Currency display: **INR**
- Missing prices: no invented observed prices; ranking may drop to probability-only

The dashboard separates gross revenue at risk, assumed potentially recoverable revenue, and actually recovered revenue (shown as not measured). Managers can edit the recovery fraction and capped incident days in the impact tab. These are revenue estimates, not profit; this CSV has no margin or cost field, so profit is unavailable.

## Store inspection workflow

Open **Product Details** to record whether a product was found on the shelf. If not, the dashboard prompts for a backroom check. Results are saved to `data/interim/inspection_log.sqlite3`, with optional notes and a pending/completed/awaiting-investigation status. Records can be exported as CSV. PhantomGuard never changes inventory quantities from an inspection record.

The dashboard uses a desktop-first, centered **Overview / Shelf checks / Reports** flow with a commercial-style hero, subtle motion, risk-colored alerts, product names and charts, store-day prioritization, saved inspection outcomes, and impact assumptions. Reports show the deduplicated annual potential-recovery projection and its arithmetic. The dashboard defaults to the newest store/date with alerts, shows a friendly empty state when none qualify, and tracks completed checks with a progress bar. Product outcomes and notes are persisted in SQLite during local development.

## Optional FastAPI + Next.js workspace

The existing Streamlit app remains available. An additional API and React 19 frontend now live alongside it:

- `backend/main.py`: FastAPI endpoints for health, stores, the capped alert queue, product history, evaluation metrics, potential-recovery estimates, and saved inspection outcomes.
- `src/analytics_engine.py`: vectorized signal classification for phantom stock-out, possible misplaced item, regional delisting hypothesis, and slow movers. It does not read label columns. Since this dataset has no shipment/reconciliation ledger, the misplaced classification uses a sales rebound as a hypothesis and cannot verify the cause.
- `frontend/`: Next.js, TypeScript, Tailwind, Radix tabs, a small shadcn-style button primitive, Framer Motion, and Recharts.
- Redis is optional. API response reads fall back to local Parquet when Redis is unset/unavailable. Async SQLAlchemy stores audit outcomes in SQLite by default.

Run the API from the project root after installing its extra dependencies:

```powershell
python -m pip install -r requirements-saas.txt
python -m uvicorn backend.main:app --reload --port 8000
```

In another terminal, start the frontend:

```powershell
cd frontend
.\start-frontend.cmd
```

The launcher uses the project-local Node/npm runtime when present; no global PATH setup is required. By default, the browser calls the same-origin `/api/v1` route and Next.js proxies it to FastAPI at `http://127.0.0.1:8000`. This also works when you open the frontend through a LAN address such as `http://192.168.x.x:3000`. If FastAPI runs on another host, set `PHANTOMGUARD_INTERNAL_API_URL` for the Next.js server. Swagger docs are available at `http://127.0.0.1:8000/docs`.

**Deployment boundary:** this is a synthetic-data demo, not a production multi-tenant service. The `X-Tenant-ID` header is not authentication. For a public portfolio/hackathon demo, set `PHANTOMGUARD_ALLOW_AUDIT_WRITES=false` on the API so visitors can browse generated alerts without writing into a shared audit log; set `PHANTOMGUARD_CORS_ORIGINS` to the exact published frontend origin. The UI then identifies itself as view-only. Do not load private store data or enable shared audit writes publicly. A production service needs authenticated identity and authorization, tenant-owned datasets, secret management, migrations, rate limits, observability, and managed database/cache configuration. See [DEPLOYMENT.md](DEPLOYMENT.md) for a release checklist. The Streamlit version remains available for local use.

## Evaluation procedure

Model training and validation use earlier date ranges. Model and independent rule-based baseline predictions use the untouched final chronological date window. The compact Parquet evaluation path currently scores their candidate sets separately; cross-boundary incident purging can make those sets different, so report each candidate count and avoid treating score differences as a paired ranking comparison. Partial labels are treated as unknown; their precision is a labeled-subset estimate, not an official score unless the organizer's evaluator defines that policy.

## Sample output

Ranked alerts include date, store, SKU, risk score, expected daily revenue loss, priority score, streak, on-hand, expected demand, a template reason, and a verification action. Maximum **20 rows per store-day**.

## Feature documentation

See `reports/feature_dictionary.md` (regenerated by the features stage).
See `reports/data_inventory.md` for the input files and columns present in this checkout.

## Testing

```powershell
pytest
```

Tests use small fixtures and do not claim competition performance. They cover combined-file ingestion, chronological incident-boundary purging, ranking limits, metrics conventions, and inspection persistence.

## Troubleshooting

| Issue | What to do |
|---|---|
| Missing sales/inventory | Run `generate_demo_data.py` or copy files into `data/raw/` |
| Conflicting duplicate keys | Fix the source; PhantomGuard refuses silent conflicting drops |
| LightGBM/XGBoost import error | Ignore; sklearn fallback trains |
| Parquet error | CSV fallback is used automatically |
| Empty ranking | History/demand/on-hand filters may exclude everyone; relax `ranking` / `baseline` in config |
| Streamlit blank | Run the pipeline first so prediction files exist |

## Ethical limitations

- Risk scores can be wrong, especially with short history or slow movers.
- Do not accuse staff of theft from a dashboard score.
- Do not auto-zero inventory without a count.
- End-of-day models cannot warn before that day's sales are known.
- Synthetic demo accuracy is not evidence of competition performance.

## Project layout

Required paths live under this repository: `config/`, `src/`, `app/`, `tests/`, `scripts/`, `notebooks/01_eda_and_validation.ipynb`, `data/`, `models/`, `reports/`.
