"""PhantomGuard Streamlit application package."""
