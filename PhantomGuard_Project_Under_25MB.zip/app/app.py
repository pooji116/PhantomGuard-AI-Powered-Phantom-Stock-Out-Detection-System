"""Desktop-first Streamlit workspace for PhantomGuard store managers."""

from __future__ import annotations

import html
import json
import sys
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.business_impact import aggregate_impact, attach_revenue_fields, format_inr
from src.config import load_config, project_root
from src.dashboard_helpers import filter_product_history, latest_alert_defaults, selection_data_available
from src.inspections import OUTCOMES, latest_inspections, list_inspections, save_inspection
from src.io_utils import read_table

st.set_page_config(page_title="PhantomGuard", layout="wide", page_icon="🛡️")

st.markdown(
    """
<style>
  .stApp { background: radial-gradient(ellipse at 92% 0%, #e7f1ff 0, #f3f6fa 40rem); color: #192638; }
  main .block-container { max-width: 1580px; padding: 1.8rem 2.4rem 3rem; }
  aside { background: #ffffff; border-right: 1px solid #dfe6ef; }
  body, p, label, small, li, h1, h2, h3, h4 { color: #192638; }
  h1 { letter-spacing: -.04em; font-size: 2.25rem !important; }
  h2, h3 { letter-spacing: -.02em; }
  input, textarea, [role="combobox"] { background: #fff !important; color: #192638 !important; }
  .pg-subtitle { color: #526174; font-size: 1.05rem; margin-top: -.6rem; }
  .pg-badge { display:inline-flex; align-items:center; gap:7px; background:#fff7df; color:#6e4c00; border:1px solid #ecd58d; border-radius:999px; padding:5px 11px; font-size:.78rem; font-weight:700; }
  .pg-badge:before { content:""; width:7px; height:7px; border-radius:50%; background:#c58b00; box-shadow:0 0 0 3px #f8eab9; }
  .pg-hero { position:relative; overflow:hidden; display:flex; align-items:center; justify-content:space-between; gap:2rem; min-height:206px; margin:1.15rem 0 1.35rem; padding:28px 32px; border-radius:19px; color:#fff; background:linear-gradient(112deg,#102c4d 0%,#174779 58%,#2463a5 100%); box-shadow:0 14px 35px rgba(20,56,94,.16); animation:pg-rise .55s cubic-bezier(.2,.8,.2,1) both; }
  .pg-hero:after { content:""; position:absolute; width:310px; height:310px; border:1px solid rgba(255,255,255,.13); border-radius:50%; right:45px; top:-178px; box-shadow:0 0 0 31px rgba(255,255,255,.035),0 0 0 65px rgba(255,255,255,.025); }
  .pg-hero-copy { position:relative; z-index:1; max-width:850px; }
  .pg-hero-kicker { color:#b8d7fb; text-transform:uppercase; font-size:.73rem; font-weight:800; letter-spacing:.13em; margin-bottom:9px; }
  .pg-hero h2 { color:#fff; font-size:1.75rem; margin:0 0 8px; }
  .pg-hero p { color:#e2eefb; font-size:.98rem; line-height:1.55; margin:0; max-width:760px; }
  .pg-flow { display:flex; flex-wrap:wrap; gap:9px; margin-top:18px; }
  .pg-flow span { color:#fff; background:rgba(255,255,255,.10); border:1px solid rgba(255,255,255,.16); border-radius:999px; padding:6px 11px; font-size:.78rem; font-weight:650; }
  .pg-flow b { color:#a9d2ff; margin-right:5px; }
  .pg-hero-art { position:relative; z-index:1; flex:0 0 160px; height:145px; display:grid; place-items:center; }
  .pg-hero-orbit { position:absolute; width:130px; height:130px; border:1px solid rgba(210,235,255,.45); border-radius:50%; animation:pg-orbit 14s linear infinite; }
  .pg-hero-orbit:before,.pg-hero-orbit:after { content:""; position:absolute; border-radius:50%; background:#82c7ff; box-shadow:0 0 16px rgba(130,199,255,.8); }
  .pg-hero-orbit:before { width:9px; height:9px; top:13px; left:21px; }
  .pg-hero-orbit:after { width:6px; height:6px; bottom:19px; right:6px; background:#f5bd60; }
  .pg-hero-core { width:80px; height:80px; display:grid; place-items:center; border:1px solid rgba(255,255,255,.4); border-radius:24px; color:#fff; background:linear-gradient(145deg,rgba(255,255,255,.25),rgba(255,255,255,.08)); box-shadow:0 8px 24px rgba(0,0,0,.16); font-size:1.1rem; font-weight:850; letter-spacing:.04em; animation:pg-float 4s ease-in-out infinite; }
  .pg-kpi { background:#fff; color:#192638; border:1px solid #dce4ed; border-radius:15px; padding:17px 19px; min-height:112px; box-shadow:0 4px 14px rgba(25,38,56,.035); transition:transform .2s ease,box-shadow .2s ease,border-color .2s ease; animation:pg-rise .45s cubic-bezier(.2,.8,.2,1) both; }
  .pg-kpi:hover { transform:translateY(-3px); border-color:#c0d3e8; box-shadow:0 12px 24px rgba(25,57,94,.09); }
  .pg-kpi-label { color:#526174; font-size:.86rem; font-weight:650; margin-bottom:8px; }
  .pg-kpi-value { color:#142235; font-size:1.55rem; line-height:1.2; font-weight:750; }
  .pg-kpi-note { color:#65748a; font-size:.78rem; margin-top:6px; }
  .pg-card { background:#fff; color:#192638; border:1px solid #dce4ed; border-radius:15px; padding:18px; box-shadow:0 4px 14px rgba(25,38,56,.035); }
  .pg-card h3, .pg-card h4, .pg-card strong { color:#192638; }
  .pg-risk { color:#8a4b00; background:#fff0d6; border:1px solid #e9c785; border-radius:999px; padding:3px 9px; font-size:.76rem; font-weight:700; }
  .pg-critical { color:#9f2633; background:#ffebed; border:1px solid #f1b8bf; border-radius:999px; padding:3px 9px; font-size:.76rem; font-weight:750; }
  .pg-medium { color:#245a91; background:#e9f3ff; border:1px solid #c4dcf5; border-radius:999px; padding:3px 9px; font-size:.76rem; font-weight:700; }
  .pg-complete { color:#1d6538; background:#e5f4e9; border:1px solid #afd6b9; border-radius:999px; padding:3px 9px; font-size:.76rem; font-weight:700; }
  .pg-empty { background:#fff; color:#26364a; border:1px solid #dce4ed; border-left:4px solid #3675c5; border-radius:12px; padding:18px 20px; box-shadow:0 4px 14px rgba(25,38,56,.035); animation:pg-rise .4s ease both; }
  .pg-muted { color:#596a7d; }
  .pg-table-head { color:#53647a; font-size:.78rem; font-weight:750; text-transform:uppercase; letter-spacing:.035em; }
  .pg-table-row { background:#fff; color:#1b2a3d; border:1px solid #e0e6ed; border-radius:9px; padding:9px 8px; min-height:52px; transition:background .16s ease,border-color .16s ease; }
  .pg-table-row:hover { background:#f8fbff; border-color:#c6d8eb; }
  .pg-divider { border-top:1px solid #e2e7ee; margin:12px 0; }
  button { color:#183a62; transition:transform .16s ease,box-shadow .16s ease; }
  button:hover { transform:translateY(-1px); box-shadow:0 5px 13px rgba(25,57,94,.10); }
  @keyframes pg-rise { from { opacity:0; transform:translateY(11px); } to { opacity:1; transform:translateY(0); } }
  @keyframes pg-float { 0%,100% { transform:translateY(0) rotate(-2deg); } 50% { transform:translateY(-7px) rotate(2deg); } }
  @keyframes pg-orbit { from { transform:rotate(0deg); } to { transform:rotate(360deg); } }
  @media (max-width: 900px) {
    main .block-container { padding:1.2rem 1rem 2rem; }
    .pg-kpi { min-height:95px; padding:13px; }
    .pg-kpi-value { font-size:1.25rem; }
    .pg-hero { padding:22px; }
    .pg-hero-art { flex-basis:110px; transform:scale(.82); margin-right:-10px; }
    .pg-hero h2 { font-size:1.4rem; }
  }
  @media (max-width: 640px) { .pg-hero-art { display:none; } .pg-hero { min-height:0; } }
  @media (prefers-reduced-motion: reduce) { *,*::before,*::after { animation-duration:.01ms !important; animation-iteration-count:1 !important; scroll-behavior:auto !important; transition-duration:.01ms !important; } }
</style>
""",
    unsafe_allow_html=True,
)


@st.cache_data(show_spinner=False)
def _load_cfg() -> dict:
    return load_config()


@st.cache_data(show_spinner=False)
def _load_table(relative_path: str, modified_ns: int) -> pd.DataFrame | None:
    path = _existing(project_root() / relative_path)
    if path is None:
        return None
    frame = read_table(path)
    if "date" in frame.columns:
        frame["date"] = pd.to_datetime(frame["date"], errors="coerce")
    return frame


def _existing(path: Path) -> Path | None:
    if path.exists():
        return path
    fallback = path.with_suffix(".csv")
    return fallback if fallback.exists() else None


def _product_name(row: pd.Series) -> str:
    for column in ("product_name", "Product Name", "product", "Category", "category"):
        value = row.get(column)
        if value is not None and not pd.isna(value) and str(value).strip():
            return str(value)
    return "Product name not provided"


def _inspection_key(row: pd.Series) -> tuple[str, str, str]:
    return (pd.Timestamp(row["date"]).date().isoformat(), str(row["store_id"]), str(row["sku_id"]))


def _saved_map(db_path: Path) -> dict[tuple[str, str, str], object]:
    records = latest_inspections(db_path)
    if records.empty:
        return {}
    return {
        (str(row.alert_date), str(row.store_id), str(row.sku_id)): row
        for row in records.itertuples(index=False)
    }


def _progress(day: pd.DataFrame, saved: dict[tuple[str, str, str], object]) -> tuple[int, int]:
    total = len(day)
    done = sum(
        1 for _, row in day.iterrows()
        if (record := saved.get(_inspection_key(row))) is not None and record.outcome != "inspection_incomplete"
    )
    return done, total


def _priority(row: pd.Series) -> str:
    """Use ranked queue position for a transparent priority grouping."""
    rank = pd.to_numeric(pd.Series([row.get("rank")]), errors="coerce").iloc[0]
    if pd.isna(rank):
        return "Medium"
    if rank <= 3:
        return "Critical"
    if rank <= 8:
        return "High"
    return "Medium"


def _risk_score(row: pd.Series) -> str:
    """Display the model score without implying a confirmed incident."""
    value = pd.to_numeric(pd.Series([row.get("predicted_probability", row.get("baseline_score"))]), errors="coerce").iloc[0]
    return f"{value:.0%}" if pd.notna(value) else "Not available"


def _revenue_at_risk(row: pd.Series) -> float | None:
    value = row.get("estimated_daily_revenue_at_risk")
    if value is None or pd.isna(value):
        return None
    return float(value)


def _reason(row: pd.Series) -> str:
    for field in ("reason", "baseline_reason"):
        value = row.get(field)
        if value is not None and not pd.isna(value) and str(value).strip():
            return str(value)
    return "No explanation was included with this alert."


def _queue_row(item: pd.Series, saved: dict, key: str, open_callback) -> None:
    done = (record := saved.get(_inspection_key(item))) is not None and record.outcome != "inspection_incomplete"
    rank = item.get("rank", "—")
    rank_text = str(int(rank)) if pd.notna(rank) and str(rank).replace(".", "", 1).isdigit() else str(rank)
    amount = _revenue_at_risk(item)
    product = _product_name(item)
    reason = _reason(item)
    cols = st.columns([0.38, 1.0, 0.7, 0.82, 0.76, 2.3, 1.0, 0.65], vertical_alignment="center")
    cols[0].markdown(f"<div class='pg-table-row'><b>{html.escape(rank_text)}</b></div>", unsafe_allow_html=True)
    cols[1].markdown(f"<div class='pg-table-row'>{html.escape(product)}</div>", unsafe_allow_html=True)
    cols[2].markdown(f"<div class='pg-table-row'>{html.escape(str(item.get('sku_id', '—')))}</div>", unsafe_allow_html=True)
    priority = "Completed" if done else _priority(item)
    css_class = "pg-complete" if done else "pg-critical" if priority == "Critical" else "pg-risk" if priority == "High" else "pg-medium"
    cols[3].markdown(f"<div class='pg-table-row'><span class='{css_class}'>{html.escape(priority)}</span></div>", unsafe_allow_html=True)
    cols[4].markdown(f"<div class='pg-table-row'><b>{_risk_score(item)}</b></div>", unsafe_allow_html=True)
    cols[5].markdown(f"<div class='pg-table-row'>{html.escape(reason[:180])}{'…' if len(reason) > 180 else ''}</div>", unsafe_allow_html=True)
    cols[6].markdown(f"<div class='pg-table-row'>{format_inr(amount) if amount is not None else 'Not available'}</div>", unsafe_allow_html=True)
    if cols[7].button("Open", key=key, on_click=open_callback, args=(str(item.get("sku_id", "")),), use_container_width=True):
        pass


def _overview_hero(store: str, date_text: str) -> None:
    st.markdown(
        "<section class='pg-hero'>"
        "<div class='pg-hero-copy'>"
        "<div class='pg-hero-kicker'>Retail inventory monitor</div>"
        "<h2>Spot stock that exists in the system, not on the shelf.</h2>"
        "<p>PhantomGuard looks for products with recorded stock but unexpectedly quiet sales, then helps your team verify the most important checks first.</p>"
        f"<div class='pg-flow'><span><b>01</b> Read sales patterns</span><span><b>02</b> Compare recorded stock</span><span><b>03</b> Prioritize up to 20 checks</span></div>"
        f"<div style='color:#c8dcf2;font-size:.78rem;margin-top:13px'>{html.escape(store)} · {html.escape(date_text)}</div>"
        "</div><div class='pg-hero-art' aria-hidden='true'><div class='pg-hero-orbit'></div><div class='pg-hero-core'>PG</div></div>"
        "</section>",
        unsafe_allow_html=True,
    )


def _chart(history: pd.DataFrame, sku: str, date_text: str) -> None:
    if history.empty or not {"date", "sales", "on_hand"}.issubset(history.columns):
        st.info("Sales or inventory history is unavailable for this product and date.")
        return
    history = history.sort_values("date").tail(56)
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.14, subplot_titles=("Daily sales (units)", "Recorded stock (units)"))
    fig.add_trace(go.Bar(x=history["date"], y=history["sales"], marker_color="#3675c5", name="Sales"), row=1, col=1)
    fig.add_trace(go.Scatter(x=history["date"], y=history["on_hand"], mode="lines+markers", line={"color": "#d17a18", "width": 2}, name="Recorded stock"), row=2, col=1)
    fig.update_yaxes(title_text="Units sold", rangemode="tozero", row=1, col=1)
    fig.update_yaxes(title_text="Units on hand", rangemode="tozero", row=2, col=1)
    fig.update_xaxes(title_text="Date", row=2, col=1)
    fig.update_layout(title=f"SKU {sku} · selected data date {date_text}", height=470, showlegend=False, margin={"l": 20, "r": 20, "t": 65, "b": 40}, paper_bgcolor="#ffffff", plot_bgcolor="#ffffff", font={"color": "#1b2a3d"})
    st.plotly_chart(fig, use_container_width=True)


def _empty_state(message: str) -> None:
    st.markdown(f"<div class='pg-empty'>{html.escape(message)}</div>", unsafe_allow_html=True)


def _show_diagnostics(cfg: dict, features: pd.DataFrame | None, alerts: pd.DataFrame | None, quality: dict, loaded_files: list[str], load_error: str | None) -> None:
    with st.expander("Diagnostics", expanded=False):
        stores_count = quality.get("n_stores")
        sku_count = quality.get("n_skus")
        row_count = quality.get("row_count")
        start, end = quality.get("date_min"), quality.get("date_max")
        span_days = (pd.Timestamp(end) - pd.Timestamp(start)).days + 1 if start and end else None
        months = span_days / 30.4375 if span_days else None
        sales_rows = quality.get("sales_source_validation", {}).get("rows_read", row_count)
        inventory_join = next((j for j in quality.get("joins", []) if j.get("join") == "inventory"), {})
        inventory_rows = inventory_join.get("right_rows", row_count)
        actual_alerts = len(alerts) if alerts is not None else "Unavailable"
        st.markdown("#### Dataset coverage")
        st.write(f"Stores: **{stores_count if stores_count is not None else 'Unavailable'}** (requested: 25)")
        st.write(f"Products/SKUs: **{sku_count if sku_count is not None else 'Unavailable'}** (requested: approximately 800)")
        st.write(f"Date range: **{start or 'Unavailable'} to {end or 'Unavailable'}** ({months:.1f} months observed" + ("; requested: 18 months)." if months is not None else ")."))
        st.write(f"Sales rows: **{sales_rows if sales_rows is not None else 'Unavailable'}** · Inventory rows: **{inventory_rows if inventory_rows is not None else 'Unavailable'}**")
        st.write(f"Alert rows: **{actual_alerts}**")
        st.write("Dataset size requirements: **Not met** (the loaded panel contains fewer stores and SKUs than requested)." if (stores_count is not None and stores_count != 25) or (sku_count is not None and sku_count < 700) else "Dataset size requirements: **Met**.")
        st.write("Last pipeline run: **Not recorded by the current pipeline.**")
        st.markdown("#### Loaded files")
        if loaded_files:
            for path in loaded_files:
                st.code(path, language=None)
        else:
            st.write("No input paths were recorded.")
        if load_error:
            st.markdown("#### Check-list loading issue")
            st.write(f"The check-list file could not be read ({load_error}). Run the data pipeline and review this page again.")


def main() -> None:
    cfg = load_config()
    base = project_root()
    synthetic = bool(cfg.get("project", {}).get("synthetic_demo", False))
    alert_rel = str(Path(cfg["paths"]["predictions_dir"]) / cfg["files"]["ranked_alerts"])
    dashboard_features = cfg.get("files", {}).get("dashboard_features")
    feature_file = dashboard_features or cfg["files"]["features"]
    feature_rel = str(Path(cfg["paths"]["processed_dir"]) / feature_file)
    feature_path = _existing(base / feature_rel)
    if feature_path is None and dashboard_features:
        feature_rel = str(Path(cfg["paths"]["processed_dir"]) / cfg["files"]["features"])
        feature_path = _existing(base / feature_rel)
    alert_path = _existing(base / alert_rel)
    alert_load_error = None
    try:
        alerts = _load_table(alert_rel, alert_path.stat().st_mtime_ns if alert_path else -1)
    except Exception as exc:  # the Reports diagnostics screen explains the failure
        alerts = None
        alert_load_error = type(exc).__name__
    try:
        features = _load_table(feature_rel, feature_path.stat().st_mtime_ns if feature_path else -1)
    except Exception:
        features = None

    quality_path = base / cfg["paths"]["processed_dir"] / cfg["files"]["quality_report"]
    try:
        quality = json.loads(quality_path.read_text(encoding="utf-8")) if quality_path.exists() else {}
    except (OSError, ValueError):
        quality = {}
    eval_path = _existing(base / cfg["files"]["evaluation_json"])
    eval_payload = {}
    if eval_path:
        try:
            eval_payload = json.loads(eval_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            eval_payload = {}
    loaded_files = [str(path) for path in quality.get("discovered_files", [])]
    if not loaded_files:
        raw_dir = base / cfg["paths"]["raw_dir"]
        expected_path = raw_dir / cfg["files"]["sales"]
        loaded_files = [str(expected_path)] if expected_path.exists() else []

    if alerts is not None:
        alerts = attach_revenue_fields(alerts, cfg)
        if "date" in alerts:
            alerts["date"] = pd.to_datetime(alerts["date"], errors="coerce")
    if features is not None and "date" in features:
        features["date"] = pd.to_datetime(features["date"], errors="coerce")

    source = features if features is not None and not features.empty else alerts
    dates = sorted(source["date"].dropna().dt.date.unique()) if source is not None and "date" in source else []
    store_values = source["store_id"].astype(str).dropna().unique() if source is not None and "store_id" in source else []
    stores = sorted(store_values)

    st.sidebar.title("PhantomGuard")
    page = st.sidebar.radio("Workspace", ["Overview", "Shelf checks", "Reports"], key="workspace_page")
    st.sidebar.divider()
    st.sidebar.caption("A store-manager workspace for checking stock-record concerns.")

    if not dates or not stores:
        st.title("PhantomGuard")
        st.markdown("<div class='pg-subtitle'>Find stock-record problems before they cost sales.</div>", unsafe_allow_html=True)
        if page == "Reports":
            st.subheader("Reports")
            _show_diagnostics(cfg, features, alerts, quality, loaded_files, alert_load_error)
        else:
            _empty_state("Sales or inventory data is unavailable for this selection." if features is not None else "The check list has not been generated. See Diagnostics under Reports.")
        return
    if "selected_store" not in st.session_state or st.session_state.selected_store not in stores:
        st.session_state.selected_store = stores[0]
    if "selected_data_date" not in st.session_state or st.session_state.selected_data_date not in dates:
        st.session_state.selected_data_date = dates[-1]
    if "selected_sku" not in st.session_state:
        st.session_state.selected_sku = None

    st.title("PhantomGuard")
    st.markdown("<div class='pg-subtitle'>Find stock-record problems before they cost sales.</div>", unsafe_allow_html=True)
    if synthetic:
        st.markdown("<span class='pg-badge'>Synthetic demo</span>", unsafe_allow_html=True)

    filter_left, filter_right = st.columns([1.15, 1.0], gap="medium")
    with filter_left:
        selected_store = st.selectbox("Store", stores, key="selected_store")
    with filter_right:
        selected_date = st.selectbox("Data date", dates, index=dates.index(st.session_state.selected_data_date), key="selected_data_date", format_func=lambda value: value.strftime("%d %b %Y"))
    date_caption = "Selected data date" if selected_date != pd.Timestamp.now().date() else "Current data date"
    st.caption(f"{date_caption}: **{selected_date:%d %b %Y}**. Historical records are shown as their actual data date.")

    valid_selection = selection_data_available(features, selected_store, selected_date)
    if alerts is None:
        queue_state = "not_generated"
        day = pd.DataFrame()
    elif not valid_selection:
        queue_state = "data_unavailable"
        day = pd.DataFrame()
    else:
        queue_state = "ready"
        day = alerts.loc[
            alerts["store_id"].astype(str).eq(selected_store)
            & pd.to_datetime(alerts["date"], errors="coerce").dt.date.eq(selected_date)
        ].copy() if not alerts.empty else alerts.copy()
        if "rank" in day:
            day = day.sort_values("rank")
        if len(day) > 20:
            day = day.head(20)

    db_path = base / cfg.get("paths", {}).get("inspection_db", "data/interim/inspection_log.sqlite3")
    try:
        saved = _saved_map(db_path)
    except Exception:
        saved = {}
    done, total = _progress(day, saved)
    all_alerts = alerts if alerts is not None else pd.DataFrame()
    latest_store, latest_date = latest_alert_defaults(all_alerts, stores, dates[-1])
    has_latest_elsewhere = bool(not all_alerts.empty and (selected_store != latest_store or selected_date != latest_date))

    def _choose_latest() -> None:
        st.session_state.selected_store = latest_store
        st.session_state.selected_data_date = latest_date
        st.session_state.selected_sku = None

    def _open_product(sku: str) -> None:
        st.session_state.selected_sku = sku
        st.session_state.workspace_page = "Shelf checks"

    if page == "Overview":
        high_priority_count = int(pd.to_numeric(day.get("rank", pd.Series(dtype=float)), errors="coerce").le(8).sum()) if not day.empty else 0
        impact = aggregate_impact(day, cfg, observed_period_days=1)
        money = impact.get("estimated_daily_revenue_at_risk_sum") if total else None
        completed_value = f"{done} / {total}" if total else "—"
        _overview_hero(selected_store, selected_date.strftime("%d %b %Y"))
        kpis = st.columns(4, gap="medium")
        cards = [
            ("Products to check", f"{total} / 20", "Daily store inspection limit"),
            ("High-priority products", str(high_priority_count), "Critical + high · ranks 1–8"),
            ("Checks completed", completed_value, "Saved physical-check outcomes"),
            ("Estimated sales at risk", format_inr(money) if money is not None else "Not available", "Estimated gross revenue"),
        ]
        for col, (label, value, note) in zip(kpis, cards):
            col.markdown(f"<div class='pg-kpi'><div class='pg-kpi-label'>{html.escape(label)}</div><div class='pg-kpi-value'>{html.escape(value)}</div><div class='pg-kpi-note'>{html.escape(note)}</div></div>", unsafe_allow_html=True)

        queue_col, detail_col = st.columns([1.7, 1.0], gap="large")
        with queue_col:
            st.subheader("Ranked shelf-check queue")
            if queue_state == "not_generated":
                _empty_state("The check list has not been generated. See Diagnostics under Reports.")
            elif queue_state == "data_unavailable":
                _empty_state("Sales or inventory data is unavailable for this selection.")
            elif day.empty:
                _empty_state("No items flagged for this selection.")
            else:
                header = st.columns([0.38, 1.0, 0.7, 0.82, 0.76, 2.3, 1.0, 0.65])
                for col, label in zip(header, ["Rank", "Product", "SKU", "Priority", "Risk score", "Reason", "Sales at risk", ""]):
                    col.markdown(f"<div class='pg-table-head'>{label}</div>", unsafe_allow_html=True)
                for idx, (_, item) in enumerate(day.iterrows()):
                    _queue_row(item, saved, f"overview_open_{selected_store}_{selected_date}_{idx}", _open_product)
        with detail_col:
            st.subheader("Selected product")
            if queue_state != "ready":
                st.markdown("<div class='pg-card'><b>Product details</b><p class='pg-muted'>Details will appear when a check list is available for the selected store and data date.</p></div>", unsafe_allow_html=True)
            elif day.empty:
                st.markdown("<div class='pg-card'><b>No product selected</b><p class='pg-muted'>There are no flagged products for this store and data date.</p></div>", unsafe_allow_html=True)
            else:
                sku_options = day["sku_id"].astype(str).tolist()
                current_sku = st.session_state.selected_sku if st.session_state.selected_sku in sku_options else sku_options[0]
                selected_sku = st.selectbox("Product in queue", sku_options, index=sku_options.index(current_sku), key="overview_sku")
                item = day.loc[day["sku_id"].astype(str).eq(selected_sku)].iloc[0]
                st.markdown(f"### {html.escape(_product_name(item))}")
                st.caption(f"SKU {html.escape(selected_sku)} · Rank {item.get('rank', '—')}")
                st.write(_reason(item))
                st.markdown("**Recommended physical check**")
                st.write("Verify the shelf and backroom quantity, then compare the physical count with the recorded stock.")
                if st.button("Open product details", key="overview_details"):
                    st.session_state.selected_sku = selected_sku
                    st.session_state.workspace_page = "Shelf checks"
                    st.rerun()

        if queue_state == "ready" and day.empty and has_latest_elsewhere:
            latest_label = f"View latest available checks · {latest_store} · {latest_date:%d %b %Y}"
            st.button(latest_label, key="overview_latest", on_click=_choose_latest)

    elif page == "Shelf checks":
        st.subheader("Shelf checks")
        if queue_state == "not_generated":
            _empty_state("The check list has not been generated. See Diagnostics under Reports.")
        elif queue_state == "data_unavailable":
            _empty_state("Sales or inventory data is unavailable for this selection.")
        elif day.empty:
            _empty_state("No items flagged for this selection.")
            st.caption("No rows met the current checks for this store and date. This does not confirm that every shelf is correct.")
            if has_latest_elsewhere:
                st.button(f"View latest available checks · {latest_store} · {latest_date:%d %b %Y}", key="checks_latest", on_click=_choose_latest)
        else:
            progress_label = f"{done} of {total} products checked"
            st.progress(done / total if total else 0, text=progress_label)
            queue_col, detail_col = st.columns([1.35, 1.1], gap="large")
            with queue_col:
                st.markdown(f"**Queue · {total} / 20 checks**")
                header = st.columns([0.45, 1.0, 1.0, .65])
                for col, label in zip(header, ["Rank", "Product", "SKU", "Open"]):
                    col.markdown(f"<div class='pg-table-head'>{label}</div>", unsafe_allow_html=True)
                for idx, (_, item) in enumerate(day.iterrows()):
                    row_cols = st.columns([0.45, 1.0, 1.0, .65], vertical_alignment="center")
                    row_cols[0].write(item.get("rank", "—"))
                    row_cols[1].write(_product_name(item))
                    row_cols[2].write(str(item.get("sku_id", "—")))
                    if row_cols[3].button("Open", key=f"checks_open_{idx}", on_click=_open_product, args=(str(item.get("sku_id", "")),), use_container_width=True):
                        pass
            with detail_col:
                available_skus = day["sku_id"].astype(str).tolist()
                preferred = st.session_state.selected_sku if st.session_state.selected_sku in available_skus else available_skus[0]
                sku = st.selectbox("Selected product", available_skus, index=available_skus.index(preferred), key="checks_sku")
                item = day.loc[day["sku_id"].astype(str).eq(sku)].iloc[0]
                saved_record = saved.get(_inspection_key(item))
                st.markdown(f"### {html.escape(_product_name(item))}")
                st.write(f"**SKU:** {html.escape(sku)}")
                if saved_record and saved_record.outcome != "inspection_incomplete":
                    st.markdown("<span class='pg-complete'>Outcome recorded</span>", unsafe_allow_html=True)
                m1, m2 = st.columns(2)
                stock = item.get("on_hand")
                m1.metric("Recorded stock", f"{stock:g} units" if pd.notna(stock) else "Not available")
                streak = item.get("positive_stock_zero_streak", item.get("zero_sales_streak"))
                m2.metric("Consecutive zero-sales days", f"{int(streak)} days" if pd.notna(streak) else "Not available")
                st.markdown("**What this alert means**")
                sales = item.get("sales")
                if pd.notna(stock) and stock > 0 and pd.notna(sales) and sales == 0:
                    st.write("The system records stock, but no sales were recorded for this period. The product could be missing, misplaced, or the stock record may be wrong.")
                else:
                    st.write(_reason(item))
                st.markdown("**Recommended physical check**")
                st.write("Check the shelf, nearby shelves, and the backroom. Confirm the physical quantity before changing the stock record.")
                history = filter_product_history(features, selected_store, sku, selected_date)
                _chart(history, sku, selected_date.strftime("%d %b %Y"))
                st.markdown("**Record audit outcome**")
                outcomes = [
                    ("Stock found", "found_on_shelf"),
                    ("Stock missing", "not_found_either"),
                    ("Found elsewhere", "found_elsewhere"),
                    ("Unable to verify", "inspection_incomplete"),
                ]
                outcome_cols = st.columns(4)
                for col, (label, outcome) in zip(outcome_cols, outcomes):
                    if col.button(label, key=f"outcome_{sku}_{outcome}", use_container_width=True):
                        try:
                            save_inspection(db_path, selected_date, selected_store, sku, outcome)
                            st.session_state.audit_saved_flash = f"Audit outcome saved: {label}. It is stored separately from evaluation labels."
                            st.rerun()
                        except Exception as exc:
                            st.error(f"We couldn’t save that outcome: {type(exc).__name__}.")
                flash = st.session_state.pop("audit_saved_flash", None)
                if flash:
                    st.success(flash)
                if saved_record:
                    st.caption(f"Latest saved outcome: {OUTCOMES.get(saved_record.outcome, saved_record.outcome)} · {saved_record.inspected_at}")

    else:
        st.subheader("Reports")
        if queue_state == "ready" and not day.empty:
            report_cols = st.columns(3)
            report_cols[0].metric("Products checked", f"{done} / {total}")
            report_cols[1].metric("Queue size", f"{total} / 20")
            report_cols[2].metric("Data date", selected_date.strftime("%d %b %Y"))
        elif queue_state == "ready":
            st.info("No items flagged for this selection. Zero alerts do not prove that stock is correct.")

        st.markdown("### Evaluation")
        evaluation_sources = eval_payload.get("by_source", {})
        evaluated = evaluation_sources.get("model") or evaluation_sources.get("baseline")
        if not evaluated or evaluated.get("error"):
            st.info("Evaluation scores are not available because verified incident labels are missing.")
        else:
            p20 = evaluated.get("precision_at_20", {})
            recall = evaluated.get("recall", {})
            evcols = st.columns(3)
            evcols[0].metric("Precision@5", f"{(evaluated.get('precision_at_budgets', {}).get('precision_at_5', {}).get('macro_average') or 0):.1%}" if evaluated.get("precision_at_budgets", {}).get("precision_at_5", {}).get("macro_average") is not None else "Not available")
            evcols[1].metric("Precision@20", f"{p20['macro_average']:.1%}" if p20.get("macro_average") is not None else "Not available")
            evcols[2].metric("Recall", f"{recall['recall']:.1%}" if recall.get("recall") is not None else "Not available")

        st.markdown("### Estimated financial impact")
        recovery_fraction = st.slider("Assumed recoverable share", 0.0, 1.0, float(cfg.get("ranking", {}).get("recoverable_fraction", 0.5)), 0.05, format="%.0f%%")
        affected_cap = st.number_input("Maximum affected days counted per incident", 1, 30, int(cfg.get("business_impact", {}).get("estimated_affected_days_cap", 7)))
        impact_cfg = {
            **cfg,
            "ranking": {**cfg.get("ranking", {}), "recoverable_fraction": recovery_fraction},
            "business_impact": {**cfg.get("business_impact", {}), "estimated_affected_days_cap": int(affected_cap)},
        }
        store_alerts = all_alerts.loc[all_alerts.get("store_id", pd.Series(dtype=str)).astype(str).eq(selected_store)] if not all_alerts.empty else all_alerts
        store_features = features.loc[features["store_id"].astype(str).eq(selected_store)] if features is not None and not features.empty else pd.DataFrame()
        observed_days = max((pd.to_datetime(store_features["date"]).max() - pd.to_datetime(store_features["date"]).min()).days + 1, 1) if not store_features.empty else 1
        impact = aggregate_impact(store_alerts, impact_cfg, observed_period_days=observed_days)
        st.caption(f"Arithmetic: expected daily units × observed unit price = gross revenue at risk. Potential recovery = capped incident revenue at risk × {recovery_fraction:.0%}. Annualized estimate = period potential recovery × 365 ÷ {observed_days} observed days. These are revenue estimates, not profit; actual recovered money is not measured.")
        if impact.get("prices_available"):
            imcols = st.columns(3)
            imcols[0].metric("Period revenue at risk", format_inr(impact["estimated_period_revenue_at_risk"]))
            imcols[1].metric("Potential recovery estimate", format_inr(impact["estimated_period_potential_recovery"]))
            imcols[2].metric("Annualized estimate", format_inr(impact["estimated_annualized_potential_recovery"]))
        else:
            st.info("No alert-based revenue estimate is available for this store and data period.")
        st.caption("Manager audit outcomes are stored as inspection records. They are not used as hidden evaluation labels or proof of recovered revenue.")

        try:
            audit_history = list_inspections(db_path)
        except Exception:
            audit_history = pd.DataFrame()
        if not audit_history.empty:
            st.download_button("Download inspection history", audit_history.to_csv(index=False).encode("utf-8"), "phantomguard_inspections.csv", "text/csv")

        _show_diagnostics(cfg, features, alerts, quality, loaded_files, alert_load_error)


main()
