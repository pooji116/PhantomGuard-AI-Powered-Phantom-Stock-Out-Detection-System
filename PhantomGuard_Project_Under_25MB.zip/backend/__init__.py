"""FastAPI service layer for the PhantomGuard local demonstration."""
