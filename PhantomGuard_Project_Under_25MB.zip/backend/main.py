"""Enterprise Multi-Tenant Asynchronous API for PhantomGuard.

Provides high-throughput endpoints for:
- Daily ranked shelf-audit queue with mathematical interleaving risk ranking
- Dual-axis historical telemetry (sales bar vs ledger stock line)
- Instant inventory zeroing and warehouse distribution replenishment workflows
- 07:00 AM Cron morning push notification interrupt service
- Redis cache-aside layer with Parquet/PyArrow fallback
"""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta, timezone
from functools import lru_cache
import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional

from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
import numpy as np
import pandas as pd
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import Date, DateTime, Float, Integer, String, Text, select, text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from src.analytics_engine import OperationalLeakClassifier
from src.business_impact import aggregate_impact
from src.config import load_config
from src.queue_data import (
    attach_inventory_verification,
    classify_queue_candidates,
    deduplicate_daily_rows,
    filter_store_day,
    priority_from_evidence,
)
from src.rank_alerts import generate_reason

LOGGER = logging.getLogger(__name__)

ROOT = Path(__file__).resolve().parents[1]
PREDICTIONS = ROOT / "data" / "predictions" / "ranked_alerts.parquet"
FEATURES = ROOT / "data" / "processed" / "dashboard_features.parquet"
FULL_FEATURES = ROOT / "data" / "processed" / "features.parquet"
STORES_MASTER = ROOT / "data" / "hackathon_demo" / "stores.csv"
PRODUCT_CATALOG = ROOT / "data" / "hackathon_demo" / "products.csv"
METRICS = ROOT / "reports" / "evaluation" / "metrics.json"

DATABASE_URL = os.getenv("PHANTOMGUARD_DATABASE_URL", f"sqlite+aiosqlite:///{(ROOT / 'data/interim/saas_audits.db').as_posix()}")
MAX_DAILY_ALERTS = 20
AUDIT_WRITES_ENABLED = os.getenv("PHANTOMGUARD_ALLOW_AUDIT_WRITES", "true").strip().lower() in {"1", "true", "yes", "on"}


class Base(DeclarativeBase):
    pass


class AuditRecord(Base):
    __tablename__ = "audit_records"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(String(80), index=True)
    store_id: Mapped[str] = mapped_column(String(80), index=True)
    sku_id: Mapped[str] = mapped_column(String(120), index=True)
    audit_date: Mapped[date] = mapped_column(Date, index=True)
    outcome: Mapped[str] = mapped_column(String(40))
    notes: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class InventoryOverride(Base):
    __tablename__ = "inventory_overrides"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(String(80), index=True)
    store_id: Mapped[str] = mapped_column(String(80), index=True)
    sku_id: Mapped[str] = mapped_column(String(120), index=True)
    effective_date: Mapped[date] = mapped_column(Date, index=True)
    adjusted_on_hand: Mapped[float] = mapped_column(Float, default=0.0)
    reason: Mapped[str] = mapped_column(String(200), default="Physical audit confirmed stock missing")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ReplenishmentOrder(Base):
    __tablename__ = "replenishment_orders"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(String(80), index=True)
    order_id: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    store_id: Mapped[str] = mapped_column(String(80), index=True)
    sku_id: Mapped[str] = mapped_column(String(120), index=True)
    order_date: Mapped[date] = mapped_column(Date, index=True)
    requested_quantity: Mapped[int] = mapped_column(Integer, default=24)
    priority: Mapped[str] = mapped_column(String(40), default="HIGH_PRIORITY_URGENT")
    destination_warehouse: Mapped[str] = mapped_column(String(80), default="WH-CENTRAL-DC-01")
    status: Mapped[str] = mapped_column(String(60), default="DISPATCHED_TO_DISTRIBUTION_CENTER")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class Alert(BaseModel):
    model_config = ConfigDict(extra="ignore")

    date: date
    store_id: str
    sku_id: str
    product_name: str = ""
    rank: Optional[int] = None
    priority: str = "Medium"
    priority_score: float = Field(default=0.0, ge=0.0)
    predicted_probability: float = Field(default=0.0, ge=0.0, le=1.0)
    confidence_score: float = Field(default=0.0, ge=0.0, le=1.0, description="Legacy alias for the model probability; check evaluation metadata to see whether model scores were calibrated")
    classification: str = "UNKNOWN"
    reason: str = "Review this product's shelf and backroom stock."
    estimated_revenue_at_risk: float = Field(default=0.0, ge=0.0)
    sales: Optional[float] = None
    # `on_hand` remains for existing clients; this explicit alias is the source
    # snapshot. A verified count is separate and only follows physical review.
    on_hand: Optional[float] = None
    system_recorded_on_hand: Optional[float] = None
    verified_on_hand: Optional[float] = None
    verified_outcome: Optional[str] = None
    replenishment_triggered: bool = False


class AuditInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    store_id: str = Field(min_length=1, max_length=80)
    sku_id: str = Field(min_length=1, max_length=120)
    audit_date: date
    outcome: Literal["found_on_shelf", "found_elsewhere", "stock_missing", "not_found", "delisted_confirmed"]
    notes: str = Field(default="", max_length=2000)


class AuditOutput(AuditInput):
    id: int
    created_at: datetime
    inventory_adjusted_to: Optional[float] = None
    replenishment_order_id: Optional[str] = None
    replenishment_status: Optional[str] = None


class NotificationPayload(BaseModel):
    title: str
    body: str
    priority: str
    channel: str
    action_url: str
    timestamp: str


class MorningDispatchResponse(BaseModel):
    status: str
    cron_schedule: str
    scheduled_time_local: str
    store_id: str
    item_count: int
    total_sales_at_risk: float
    formatted_sales_at_risk: str
    notification_payload: NotificationPayload


class ServiceState:
    engine = None
    sessions = None
    redis = None
    redis_status = "disabled"


state = ServiceState()


@asynccontextmanager
async def lifespan(app: FastAPI):
    if DATABASE_URL.startswith("sqlite+"):
        db_path = Path(DATABASE_URL.split("///", 1)[-1])
        db_path.parent.mkdir(parents=True, exist_ok=True)

    state.engine = create_async_engine(DATABASE_URL, pool_pre_ping=True)
    state.sessions = async_sessionmaker(state.engine, expire_on_commit=False)

    async with state.engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        # Inventory overrides are current physical corrections, not an audit
        # history. Keep the latest correction for each business key, and ignore
        # corrections superseded by a later non-missing physical outcome.
        await conn.execute(text("""
            DELETE FROM inventory_overrides
            WHERE id NOT IN (
                SELECT MAX(id)
                FROM inventory_overrides
                GROUP BY tenant_id, store_id, sku_id, effective_date
            )
        """))
        await conn.execute(text("""
            DELETE FROM inventory_overrides
            WHERE NOT EXISTS (
                SELECT 1 FROM audit_records a
                WHERE a.tenant_id = inventory_overrides.tenant_id
                  AND a.store_id = inventory_overrides.store_id
                  AND a.sku_id = inventory_overrides.sku_id
                  AND a.audit_date = inventory_overrides.effective_date
            ) OR EXISTS (
                SELECT 1 FROM audit_records latest
                WHERE latest.tenant_id = inventory_overrides.tenant_id
                  AND latest.store_id = inventory_overrides.store_id
                  AND latest.sku_id = inventory_overrides.sku_id
                  AND latest.audit_date = inventory_overrides.effective_date
                  AND latest.id = (
                      SELECT MAX(a2.id) FROM audit_records a2
                      WHERE a2.tenant_id = latest.tenant_id
                        AND a2.store_id = latest.store_id
                        AND a2.sku_id = latest.sku_id
                        AND a2.audit_date = latest.audit_date
                  )
                  AND latest.outcome <> 'stock_missing'
            )
        """))
        await conn.execute(text("""
            CREATE UNIQUE INDEX IF NOT EXISTS uq_inventory_override_scope
            ON inventory_overrides (tenant_id, store_id, sku_id, effective_date)
        """))

    redis_url = os.getenv("PHANTOMGUARD_REDIS_URL")
    if redis_url:
        try:
            from redis.asyncio import Redis

            state.redis = Redis.from_url(redis_url, decode_responses=True, socket_connect_timeout=0.5)
            await state.redis.ping()
            state.redis_status = "connected"
        except Exception:
            state.redis = None
            state.redis_status = "unavailable; using local reads without cache"

    yield

    if state.redis is not None:
        await state.redis.aclose()
    if state.engine is not None:
        await state.engine.dispose()


app = FastAPI(title="PhantomGuard Enterprise SaaS API", version="2.0.0", lifespan=lifespan)

cors_env = os.getenv("PHANTOMGUARD_CORS_ORIGINS", "*").strip()
if cors_env == "*":
    app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False,
                       allow_methods=["*"], allow_headers=["*"])
else:
    allowed_origins = [origin.strip() for origin in cors_env.split(",") if origin.strip()]
    app.add_middleware(CORSMiddleware, allow_origins=allowed_origins, allow_credentials=False,
                       allow_methods=["GET", "POST"], allow_headers=["Content-Type", "X-Tenant-ID"])


@app.get("/", include_in_schema=False)
async def root():
    return {
        "service": "PhantomGuard Enterprise SaaS API",
        "version": "2.0.0",
        "docs": "/docs",
        "health": "/api/v1/health",
        "morning_cron": "/api/v1/cron/morning-dispatch",
    }


@lru_cache(maxsize=8)
def _read_parquet_cached(path: str, columns: Optional[tuple[str, ...]], modified_ns: int) -> pd.DataFrame:
    return pd.read_parquet(path, columns=list(columns) if columns is not None else None)


def _read_parquet(path: Path, cache_key: str, columns: Optional[List[str]] = None) -> pd.DataFrame:
    if not path.exists():
        raise HTTPException(status_code=503, detail=f"Data artifact is not ready: {path.name}")
    frame = _read_parquet_cached(
        str(path.resolve()),
        tuple(columns) if columns is not None else None,
        path.stat().st_mtime_ns,
    )
    return frame.copy(deep=True)


@lru_cache(maxsize=4)
def _parquet_date_bounds(path: str, modified_ns: int) -> Optional[tuple[date, date]]:
    import pyarrow.parquet as pq

    parquet = pq.ParquetFile(path)
    date_column = parquet.schema_arrow.get_field_index("date")
    if date_column < 0:
        return None
    bounds = [
        parquet.metadata.row_group(index).column(date_column).statistics
        for index in range(parquet.metadata.num_row_groups)
    ]
    bounds = [stat for stat in bounds if stat is not None and stat.has_min_max]
    if not bounds:
        return None
    return (
        min(pd.Timestamp(stat.min).date() for stat in bounds),
        max(pd.Timestamp(stat.max).date() for stat in bounds),
    )


def _history_source(start_date: date, end_date: date) -> Path:
    if FEATURES.exists():
        modified_ns = FEATURES.stat().st_mtime_ns
        bounds = _parquet_date_bounds(str(FEATURES.resolve()), modified_ns)
        if bounds and bounds[0] <= start_date and end_date <= bounds[1]:
            return FEATURES
    return FULL_FEATURES


@lru_cache(maxsize=8)
def _read_alert_history_cached(
    sku_ids: tuple[str, ...], end_date: date, source_path: str, modified_ns: int
) -> pd.DataFrame:
    return pd.read_parquet(
        source_path,
        columns=["date", "store_id", "sku_id", "sales", "on_hand", "unit_price"],
        filters=[
            ("sku_id", "in", list(sku_ids)),
            ("date", ">=", pd.Timestamp(end_date - timedelta(days=55))),
            ("date", "<=", pd.Timestamp(end_date)),
        ],
    )


def _read_alert_history(sku_ids: list[str], end_date: date) -> pd.DataFrame:
    """Read only recent history for queue SKUs, across stores for peer signals."""
    columns = ["date", "store_id", "sku_id", "sales", "on_hand", "unit_price"]
    if not FULL_FEATURES.exists() or not sku_ids:
        return pd.DataFrame(columns=columns)
    source = _history_source(end_date - timedelta(days=55), end_date)
    return _read_alert_history_cached(
        tuple(sorted(set(sku_ids))),
        end_date,
        str(source.resolve()),
        source.stat().st_mtime_ns,
    ).copy(deep=True)


@lru_cache(maxsize=32)
def _read_product_history_cached(
    store_id: str, sku_id: str, end_date: date, days: int, columns: tuple[str, ...], source_path: str, modified_ns: int
) -> pd.DataFrame:
    return pd.read_parquet(
        source_path,
        columns=list(columns),
        filters=[
            ("store_id", "==", store_id),
            ("sku_id", "==", sku_id),
            ("date", ">=", pd.Timestamp(end_date - timedelta(days=days - 1))),
            ("date", "<=", pd.Timestamp(end_date)),
        ],
    )


def _read_product_history(store_id: str, sku_id: str, end_date: date, days: int) -> pd.DataFrame:
    """Read the exact SKU/store/date history window from the canonical feature panel."""
    columns = ["date", "store_id", "sku_id", "sales", "on_hand", "expected_demand", "promo_flag"]
    if not FULL_FEATURES.exists():
        raise HTTPException(status_code=503, detail="Historical feature data is not ready")
    source = _history_source(end_date - timedelta(days=days - 1), end_date)
    return _read_product_history_cached(
        store_id,
        sku_id,
        end_date,
        days,
        tuple(columns),
        str(source.resolve()),
        source.stat().st_mtime_ns,
    ).copy(deep=True)


async def _cached_json(key: str, factory):
    """Redis cache-aside layer with Parquet fallback."""
    if state.redis is not None:
        try:
            cached = await state.redis.get(key)
            if cached:
                return json.loads(cached)
        except Exception:
            pass

    value = await factory()

    if state.redis is not None:
        try:
            await state.redis.set(key, json.dumps(value, default=str), ex=120)
        except Exception:
            pass
    return value


async def _audit_session():
    async with state.sessions() as session:
        yield session


def _tenant_id(x_tenant_id: str = Header(default="demo", alias="X-Tenant-ID")) -> str:
    val = x_tenant_id.strip()
    if not val or len(val) > 80:
        raise HTTPException(status_code=400, detail="X-Tenant-ID must be 1-80 characters")
    return val


def _json_records(df: pd.DataFrame) -> List[Dict[str, Any]]:
    if "date" in df:
        df = df.copy()
        df["date"] = pd.to_datetime(df["date"], errors="coerce").dt.date
    df = df.astype(object).where(pd.notna(df), None)
    return json.loads(pd.DataFrame(df).to_json(orient="records", date_format="iso"))


def _numeric_series(frame: pd.DataFrame, column: str, default: float = 0.0) -> pd.Series:
    """Return a finite numeric series aligned to a frame, including absent columns."""
    if column not in frame.columns:
        return pd.Series(default, index=frame.index, dtype=float)
    return pd.to_numeric(frame[column], errors="coerce").fillna(default)


@app.get("/api/v1/health")
async def health():
    return {
        "status": "ok",
        "version": "2.0.0",
        "data_ready": PREDICTIONS.exists(),
        "redis": state.redis_status,
        "max_alerts_per_store_day": MAX_DAILY_ALERTS,
        "audit_writes_enabled": AUDIT_WRITES_ENABLED,
    }


@app.get("/api/v1/metrics")
async def metrics(tenant_id: str = Depends(_tenant_id)):
    if not METRICS.exists():
        raise HTTPException(status_code=503, detail="Evaluation report is not ready")
    return json.loads(METRICS.read_text(encoding="utf-8"))


@app.get("/api/v1/impact")
async def impact(tenant_id: str = Depends(_tenant_id)):
    """Return a deduplicated, assumption-based annual sales-recovery projection."""
    def calculate():
        ranked = _read_parquet(PREDICTIONS, "ranked-alerts")
        if not ranked.empty and FEATURES.exists():
            dates = _read_parquet(FEATURES, "feature-dates", ["date"])["date"]
            parsed = pd.to_datetime(dates, errors="coerce").dropna()
            period_days = int((parsed.max() - parsed.min()).days) + 1 if len(parsed) else 1
        else:
            period_days = 1
        return aggregate_impact(ranked, observed_period_days=max(period_days, 1))

    return await _cached_json(f"impact:{tenant_id}", lambda: asyncio.to_thread(calculate))


@app.get("/api/v1/stores")
async def stores(tenant_id: str = Depends(_tenant_id)):
    async def load():
        frame = await asyncio.to_thread(_read_parquet, PREDICTIONS, "stores", ["store_id", "date"])
        dates = pd.to_datetime(frame["date"], errors="coerce")
        return {
            "stores": sorted(frame["store_id"].dropna().astype(str).unique().tolist()),
            "latest_date": dates.max().date().isoformat() if dates.notna().any() else None,
            "latest_by_store": (
                frame.assign(_date=dates)
                .dropna(subset=["_date"])
                .groupby("store_id")["_date"]
                .max()
                .dt.date.astype(str)
                .to_dict()
            ),
        }

    return await _cached_json(f"stores:{tenant_id}", load)


@app.get("/api/v1/alerts", response_model=List[Alert])
async def alerts(
    store_id: str = Query(min_length=1),
    alert_date: Optional[date] = Query(default=None, alias="date"),
    tenant_id: str = Depends(_tenant_id),
    session: AsyncSession = Depends(_audit_session),
):
    """Return distinct daily candidates in the same model-risk order used by evaluation."""
    frame = await asyncio.to_thread(_read_parquet, PREDICTIONS, "ranked-alerts")
    frame["date"] = pd.to_datetime(frame["date"], errors="coerce").dt.date

    selected_date = alert_date
    if selected_date is None:
        dates = frame.loc[frame["store_id"].astype(str).eq(store_id), "date"]
        if dates.empty:
            return []
        selected_date = max(dates)

    day = filter_store_day(frame, store_id, selected_date)
    if day.empty:
        return []

    # Collapse any repeated artifact rows before applying the 20-item budget.
    # The latest explicit inventory timestamp wins; otherwise the best model
    # rank is retained. The chosen row keeps its own stock and reason together.
    day = deduplicate_daily_rows(day, ranked=True)

    cfg = load_config()
    share = float(cfg.get("ranking", {}).get("recoverable_fraction", 0.5))

    # Attach verification as a separate fact. Never overwrite the source
    # system-recorded on-hand value used by the alert, explanation, and chart.
    audit_stmt = select(AuditRecord).where(
        AuditRecord.tenant_id == tenant_id,
        AuditRecord.store_id == store_id,
        AuditRecord.audit_date == selected_date,
    ).order_by(AuditRecord.id.desc())
    audit_rows = (await session.scalars(audit_stmt)).all()
    latest_audit_by_sku: dict[str, AuditRecord] = {}
    for audit in audit_rows:
        latest_audit_by_sku.setdefault(audit.sku_id, audit)

    override_stmt = select(InventoryOverride).where(
        InventoryOverride.tenant_id == tenant_id,
        InventoryOverride.store_id == store_id,
        InventoryOverride.effective_date == selected_date,
    ).order_by(InventoryOverride.id.desc())
    overrides = (await session.scalars(override_stmt)).all()
    override_map: dict[str, float] = {}
    for override in overrides:
        latest_audit = latest_audit_by_sku.get(override.sku_id)
        if latest_audit and latest_audit.outcome == "stock_missing":
            override_map.setdefault(override.sku_id, override.adjusted_on_hand)
    day = attach_inventory_verification(
        day,
        override_map,
        {sku: audit.outcome for sku, audit in latest_audit_by_sku.items()},
        key_column="sku_id",
    )

    # Attach Product Catalog names
    if "product_name" not in day and PRODUCT_CATALOG.exists():
        names = await asyncio.to_thread(pd.read_csv, PRODUCT_CATALOG, usecols=["sku_id", "product_name"])
        names = names.dropna().drop_duplicates("sku_id")
        day = day.merge(names, on="sku_id", how="left")
    if "product_name" not in day:
        day["product_name"] = day["sku_id"].astype(str)
    else:
        day["product_name"] = day["product_name"].fillna(day["sku_id"].astype(str))

    # Keep the model's existing output. `confidence_score` remains a legacy API
    # alias; the UI labels the value as a model score because it is uncalibrated.
    day["predicted_probability"] = _numeric_series(day, "predicted_probability").clip(0, 1)
    day["confidence_score"] = day["predicted_probability"]

    if "expected_daily_revenue_loss" not in day:
        demand = _numeric_series(day, "expected_demand").clip(lower=0)
        price = _numeric_series(day, "unit_price").clip(lower=0)
        day["expected_daily_revenue_loss"] = demand * price * share
    else:
        day["expected_daily_revenue_loss"] = pd.to_numeric(
            day["expected_daily_revenue_loss"], errors="coerce"
        ).fillna(0).clip(lower=0)

    if "priority_score" not in day:
        day["priority_score"] = day["predicted_probability"] * day["expected_daily_revenue_loss"]
    else:
        day["priority_score"] = pd.to_numeric(day["priority_score"], errors="coerce").fillna(0).clip(lower=0)

    # Report the existing seven-day gross sales-at-risk estimate. It is separate
    # from the daily recoverable-revenue score used for ranking and priority.
    if "estimated_revenue_at_risk" not in day:
        demand = _numeric_series(day, "expected_demand").clip(lower=0)
        price = _numeric_series(day, "unit_price").clip(lower=0)
        day["estimated_revenue_at_risk"] = demand * price * 7.0
    else:
        day["estimated_revenue_at_risk"] = pd.to_numeric(
            day["estimated_revenue_at_risk"], errors="coerce"
        ).fillna(0).clip(lower=0)

    # The queue's probability is the model output. Priority is a transparent
    # operational tier based on the evaluated model score plus signal duration.
    streak_column = "positive_stock_zero_streak" if "positive_stock_zero_streak" in day else "zero_sales_streak"
    streak = _numeric_series(day, streak_column)
    day["priority"] = [
        priority_from_evidence(score, days, cfg)
        for score, days in zip(day["priority_score"], streak)
    ]

    # Derive only hypotheses supported by the same store/SKU history through
    # this business date. The classifier score is not used as model confidence.
    alert_history = await asyncio.to_thread(_read_alert_history, day["sku_id"].astype(str).tolist(), selected_date)
    store_master = await asyncio.to_thread(pd.read_csv, STORES_MASTER) if STORES_MASTER.exists() else None
    scoring_time = str(cfg.get("features", {}).get("scoring_time", "start_of_day"))
    classifications = classify_queue_candidates(day, alert_history, store_master, selected_date, scoring_time)
    day["classification"] = day["sku_id"].astype(str).map(classifications).fillna("UNSPECIFIED_DISCREPANCY")

    # Refresh the plain-English sentence from the selected source row so the
    # displayed stock and explanation always refer to the same record.
    day["reason"] = day.apply(lambda row: generate_reason(row, scoring_time), axis=1)

    tie_breakers = cfg.get("ranking", {}).get(
        "tie_breakers", ["priority_score", "predicted_probability", "expected_daily_revenue_loss", "sku_id"]
    )
    sort_columns = [column for column in tie_breakers if column in day.columns]
    if "priority_score" not in sort_columns:
        sort_columns.insert(0, "priority_score")
    sort_ascending = [column == "sku_id" for column in sort_columns]
    day = day.sort_values(sort_columns, ascending=sort_ascending, kind="stable").head(MAX_DAILY_ALERTS)

    day["rank"] = range(1, len(day) + 1)

    if "reason" not in day:
        day["reason"] = (
            "System stock and transaction checkout history disagree. Physical verification required."
        )

    # Check for existing replenishment orders
    rep_stmt = select(ReplenishmentOrder.sku_id).where(
        ReplenishmentOrder.tenant_id == tenant_id,
        ReplenishmentOrder.store_id == store_id,
        ReplenishmentOrder.order_date == selected_date,
    )
    rep_skus = set((await session.scalars(rep_stmt)).all())
    day["replenishment_triggered"] = day["sku_id"].isin(rep_skus)

    return [Alert.model_validate(rec).model_dump(mode="json") for rec in _json_records(day)]


@app.get("/api/v1/products/{store_id}/{sku_id}/history")
async def product_history(
    store_id: str,
    sku_id: str,
    end_date: Optional[date] = None,
    days: int = Query(default=56, ge=7, le=180),
    tenant_id: str = Depends(_tenant_id),
    session: AsyncSession = Depends(_audit_session),
):
    """Retrieve daily time-series points formatted for dual-axis hybrid chart visualization."""
    selected_end = end_date or date.today()
    history = await asyncio.to_thread(_read_product_history, store_id, sku_id, selected_end, days)
    history["date"] = pd.to_datetime(history["date"], errors="coerce")
    history = history.sort_values("date").tail(days).copy()
    if history.empty:
        raise HTTPException(status_code=404, detail="No product history exists for this store and SKU")

    # Keep source ledger stock intact; attach manager-confirmed stock separately.
    dates = [timestamp.date() for timestamp in history["date"]]
    audit_stmt = select(AuditRecord).where(
        AuditRecord.tenant_id == tenant_id,
        AuditRecord.store_id == store_id,
        AuditRecord.sku_id == sku_id,
        AuditRecord.audit_date.in_(dates),
    ).order_by(AuditRecord.id.desc())
    audit_rows = (await session.scalars(audit_stmt)).all()
    latest_outcome_by_date: dict[date, str] = {}
    for audit in audit_rows:
        latest_outcome_by_date.setdefault(audit.audit_date, audit.outcome)

    stmt = select(InventoryOverride).where(
        InventoryOverride.tenant_id == tenant_id,
        InventoryOverride.store_id == store_id,
        InventoryOverride.sku_id == sku_id,
        InventoryOverride.effective_date.in_(dates),
    ).order_by(InventoryOverride.id.desc())
    overrides = (await session.scalars(stmt)).all()
    verified_by_date: dict[date, float] = {}
    for override in overrides:
        if latest_outcome_by_date.get(override.effective_date) == "stock_missing":
            verified_by_date.setdefault(override.effective_date, override.adjusted_on_hand)

    history = attach_inventory_verification(
        history, verified_by_date, latest_outcome_by_date, key_column="date"
    )
    fields = [
        c for c in ["date", "sales", "on_hand", "system_recorded_on_hand", "verified_on_hand", "verified_outcome", "expected_demand", "promo_flag"]
        if c in history
    ]
    return {
        "store_id": store_id,
        "sku_id": sku_id,
        "points": _json_records(history[fields]),
    }


@app.get("/api/v1/products/{store_id}/{sku_id}/signal")
async def product_signal(store_id: str, sku_id: str, tenant_id: str = Depends(_tenant_id)):
    """Run real-time vectorized root cause analysis across the 3 signal architectures."""
    def analyze():
        frame = _read_parquet(FEATURES, "features", ["date", "store_id", "sku_id", "sales", "on_hand", "unit_price"])
        frame["date"] = pd.to_datetime(frame["date"], errors="coerce")
        sku = frame.loc[frame["sku_id"].astype(str).eq(sku_id)]
        local = sku.loc[sku["store_id"].astype(str).eq(store_id)].sort_values("date")
        if local.empty:
            raise HTTPException(status_code=404, detail="No product history exists for this store and SKU")

        regional_matrix = None
        if STORES_MASTER.exists():
            stores_frame = pd.read_csv(STORES_MASTER)
            if {"store_id", "city_tier"}.issubset(stores_frame.columns):
                tier = stores_frame.loc[stores_frame["store_id"].astype(str).eq(store_id), "city_tier"]
                peers = stores_frame.loc[stores_frame["city_tier"].eq(tier.iloc[0]), "store_id"].astype(str).tolist() if len(tier) else []
                regional = sku.loc[sku["store_id"].astype(str).isin(peers)].pivot(index="date", columns="store_id", values="sales")
                regional = regional.reindex(local["date"])
                if len(peers) > 0 and set(peers).issubset(regional.columns) and not regional[peers].isna().any().any():
                    regional_matrix = regional[peers].to_numpy(dtype=float)

        price = float(pd.to_numeric(local["unit_price"], errors="coerce").dropna().median()) if local["unit_price"].notna().any() else 0.0

        signal = OperationalLeakClassifier().classify_single_combination(
            local["sales"].to_numpy(dtype=float),
            local["on_hand"].to_numpy(dtype=float),
            sku_id,
            store_id,
            price,
            regional_matrix,
        )
        return signal.model_dump(mode="json")

    return await asyncio.to_thread(analyze)


@app.get("/api/v1/audits", response_model=List[AuditOutput])
async def list_audits(
    store_id: Optional[str] = None,
    audit_date: Optional[date] = Query(default=None, alias="date"),
    tenant_id: str = Depends(_tenant_id),
    session: AsyncSession = Depends(_audit_session),
):
    if not AUDIT_WRITES_ENABLED:
        return []

    query = select(AuditRecord).where(AuditRecord.tenant_id == tenant_id)
    if store_id:
        query = query.where(AuditRecord.store_id == store_id)
    if audit_date:
        query = query.where(AuditRecord.audit_date == audit_date)

    rows = (await session.scalars(query.order_by(AuditRecord.id.desc()).limit(500))).all()
    return [
        AuditOutput(
            id=r.id,
            store_id=r.store_id,
            sku_id=r.sku_id,
            audit_date=r.audit_date,
            outcome=r.outcome,
            notes=r.notes,
            created_at=r.created_at,
        )
        for r in rows
    ]


@app.post("/api/v1/audits", response_model=AuditOutput, status_code=201)
async def create_audit(
    payload: AuditInput,
    tenant_id: str = Depends(_tenant_id),
    session: AsyncSession = Depends(_audit_session),
):
    """Save an authorized physical outcome and maintain its current correction."""
    if not AUDIT_WRITES_ENABLED:
        raise HTTPException(status_code=403, detail="Audit writes are currently disabled in this deployment")

    record = AuditRecord(
        tenant_id=tenant_id,
        store_id=payload.store_id,
        sku_id=payload.sku_id,
        audit_date=payload.audit_date,
        outcome=payload.outcome,
        notes=payload.notes,
    )
    session.add(record)

    adjusted_to = None
    rep_order_id = None
    rep_status = None

    override_stmt = select(InventoryOverride).where(
        InventoryOverride.tenant_id == tenant_id,
        InventoryOverride.store_id == payload.store_id,
        InventoryOverride.sku_id == payload.sku_id,
        InventoryOverride.effective_date == payload.audit_date,
    ).order_by(InventoryOverride.id.desc())
    existing_overrides = (await session.scalars(override_stmt)).all()

    if payload.outcome == "stock_missing":
        # Only physical confirmation adjusts the system quantity. Keep the
        # source snapshot unchanged and store one current correction row.
        if existing_overrides:
            override = existing_overrides[0]
            override.adjusted_on_hand = 0.0
            override.reason = f"Physical verification confirmed stock missing on {payload.audit_date}"
            for duplicate in existing_overrides[1:]:
                await session.delete(duplicate)
        else:
            session.add(InventoryOverride(
                tenant_id=tenant_id,
                store_id=payload.store_id,
                sku_id=payload.sku_id,
                effective_date=payload.audit_date,
                adjusted_on_hand=0.0,
                reason=f"Physical verification confirmed stock missing on {payload.audit_date}",
            ))
        adjusted_to = 0.0

        # Repeated confirmations for this key/date reuse the existing DC order.
        existing_order = await session.scalar(
            select(ReplenishmentOrder)
            .where(
                ReplenishmentOrder.tenant_id == tenant_id,
                ReplenishmentOrder.store_id == payload.store_id,
                ReplenishmentOrder.sku_id == payload.sku_id,
                ReplenishmentOrder.order_date == payload.audit_date,
            )
            .order_by(ReplenishmentOrder.id.desc())
        )
        if existing_order:
            rep_order_id = existing_order.order_id
            rep_status = existing_order.status
        else:
            order_key = f"REP-{payload.store_id}-{payload.sku_id}-{int(datetime.now(timezone.utc).timestamp())}"
            replenishment = ReplenishmentOrder(
                tenant_id=tenant_id,
                order_id=order_key,
                store_id=payload.store_id,
                sku_id=payload.sku_id,
                order_date=payload.audit_date,
                requested_quantity=36,
                priority="HIGH_PRIORITY_URGENT",
                destination_warehouse="WH-DISTRIBUTION-CENTRAL-01",
                status="DISPATCHED_TO_DISTRIBUTION_CENTER",
            )
            session.add(replenishment)
            rep_order_id = order_key
            rep_status = replenishment.status
    else:
        # A later physical result supersedes an old missing-stock correction.
        # Other outcomes do not include a quantity, so no count is invented.
        for stale_override in existing_overrides:
            await session.delete(stale_override)

    await session.commit()
    await session.refresh(record)

    return AuditOutput(
        id=record.id,
        store_id=record.store_id,
        sku_id=record.sku_id,
        audit_date=record.audit_date,
        outcome=record.outcome,
        notes=record.notes,
        created_at=record.created_at,
        inventory_adjusted_to=adjusted_to,
        replenishment_order_id=rep_order_id,
        replenishment_status=rep_status,
    )


# -------------------------------------------------------------------------------------------------
# CRITICAL METRICS NOTIFICATION INTERRUPT: 07:00 AM Cron Service Hook
# -------------------------------------------------------------------------------------------------

@app.post("/api/v1/cron/morning-dispatch", response_model=MorningDispatchResponse)
@app.get("/api/v1/notifications/morning-dispatch", response_model=MorningDispatchResponse)
async def morning_dispatch_cron(
    store_id: str = Query(default="S001"),
    target_date: Optional[date] = Query(default=None, alias="date"),
    tenant_id: str = Depends(_tenant_id),
):
    """Create a notification from the same unique, ranked queue as the dashboard."""
    frame = await asyncio.to_thread(_read_parquet, PREDICTIONS, "ranked-alerts")
    frame["date"] = pd.to_datetime(frame["date"], errors="coerce").dt.date

    selected_date = target_date
    if selected_date is None:
        dates = frame.loc[frame["store_id"].astype(str).eq(store_id), "date"]
        selected_date = max(dates) if not dates.empty else date.today()

    day = filter_store_day(frame, store_id, selected_date)
    day = deduplicate_daily_rows(day, ranked=True)

    # Keep notification totals tied to the selected store/date queue. Never
    # fill an empty queue with an example count or example rupee amount.
    if "estimated_revenue_at_risk" not in day:
        demand = _numeric_series(day, "expected_demand").clip(lower=0)
        price = _numeric_series(day, "unit_price").clip(lower=0)
        day["estimated_revenue_at_risk"] = demand * price * 7.0
    else:
        day["estimated_revenue_at_risk"] = _numeric_series(day, "estimated_revenue_at_risk").clip(lower=0)

    if "priority_score" not in day:
        probability = _numeric_series(day, "predicted_probability").clip(0, 1)
        daily_loss = _numeric_series(day, "expected_daily_revenue_loss").clip(lower=0)
        day["priority_score"] = probability * daily_loss
    else:
        day["priority_score"] = _numeric_series(day, "priority_score").clip(lower=0)
    sort_columns = [column for column in ["priority_score", "predicted_probability", "expected_daily_revenue_loss", "sku_id"] if column in day]
    top_alerts = day.sort_values(
        sort_columns,
        ascending=[column == "sku_id" for column in sort_columns],
        kind="stable",
    ).head(MAX_DAILY_ALERTS) if sort_columns else day.head(MAX_DAILY_ALERTS)
    item_count = len(top_alerts)
    total_sales_at_risk = float(_numeric_series(top_alerts, "estimated_revenue_at_risk").sum())

    formatted_inr = f"₹{int(round(total_sales_at_risk)):,}"

    # Programmatic push notification body matching exact specification string
    push_message = (
        f"Your morning shelf-check queue is ready. {item_count} items identified with {formatted_inr} in estimated sales at risk."
    )

    return MorningDispatchResponse(
        status="DISPATCHED_TO_MOBILE_WORKSPACE",
        cron_schedule="0 7 * * *",
        scheduled_time_local="07:00 AM IST",
        store_id=store_id,
        item_count=item_count,
        total_sales_at_risk=total_sales_at_risk,
        formatted_sales_at_risk=formatted_inr,
        notification_payload=NotificationPayload(
            title="PhantomGuard Morning Shelf-Check Queue",
            body=push_message,
            priority="HIGH_URGENT" if item_count else "NORMAL",
            channel="STORE_MANAGER_MOBILE_PUSH",
            action_url=f"/workspace?store={store_id}&date={selected_date}",
            timestamp=datetime.now(timezone.utc).isoformat(),
        ),
    )
