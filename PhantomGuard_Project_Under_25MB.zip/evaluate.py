"""PhantomGuard Official Evaluator.

Computes the core metrics required by store operations:
1. Precision@20 per store-day (macro and micro average)
2. Recall on hidden ground-truth labels
3. Budget sensitivity (Precision @ 5, 10, 20, 30)
4. Store format breakdown
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.config import load_config
from src.evaluate import run_evaluate
from src.io_utils import configure_logging


def main() -> int:
    parser = argparse.ArgumentParser(description="Evaluate PhantomGuard predictions.")
    parser.add_argument("--config", default=None, help="Path to config.yaml (optional)")
    parser.add_argument("--source", default=None, help="Specific source to evaluate (model or baseline)")
    args = parser.parse_args()

    configure_logging()
    cfg = load_config(args.config)
    is_demo = cfg.get("project", {}).get("synthetic_demo", False)

    try:
        results = run_evaluate(args.config)
    except FileNotFoundError as exc:
        print(f"\n[ERROR] Predictions not found: {exc}")
        print("Please run the pipeline first: python scripts/run_pipeline.py --stage all\n")
        return 1

    by_source = results.get("by_source", {})
    source_key = args.source if args.source in by_source else ("model" if "model" in by_source else next(iter(by_source.keys())))
    metrics = by_source.get(source_key, {})

    p20 = metrics.get("precision_at_20", {})
    rec = metrics.get("recall", {})
    p_budgets = metrics.get("precision_at_budgets", {})
    fmt_breakdown = metrics.get("precision_by_store_format", {})

    macro = p20.get("macro_average")
    micro = p20.get("micro_average")
    recall_val = rec.get("recall")
    positives = rec.get("positives", 0)
    captured = rec.get("captured", 0)
    store_days = p20.get("n_store_days", 0)

    print("\n" + "=" * 65)
    print(" [PHANTOMGUARD] OFFICIAL EVALUATION REPORT")
    print("=" * 65)
    if is_demo:
        print(" [NOTE] Evaluating on synthetic simulation data.")
    print(f" Evaluated Source Model:      {source_key.upper()}")
    print(f" Store-Days Evaluated:        {store_days:,}")
    print(f" Labeled Candidates Evaluated:{metrics.get('n_labeled_rows', 0):,}")
    print("-" * 65)
    print(" KEY METRICS FOR STORE MANAGERS & OPERATIONS:")
    print("-" * 65)
    macro_str = f"{macro:.4f} ({macro*100:.1f}%)" if macro is not None else "N/A"
    micro_str = f"{micro:.4f} ({micro*100:.1f}%)" if micro is not None else "N/A"
    rec_str = f"{recall_val:.4f} ({recall_val*100:.1f}%)" if recall_val is not None else "N/A"

    print(f" [*] Precision@20 (Macro Avg): {macro_str}")
    print("     -> Average accuracy across all store-days within top-20 budget")
    print(f" [*] Precision@20 (Micro Avg): {micro_str}")
    print("     -> Pooled accuracy over all inspected candidate shelves")
    print(f" [*] Recall on Hidden Labels:  {rec_str} ({captured} of {positives} caught)")
    print("     -> Fraction of true phantom stockouts caught by the system")
    print("-" * 65)

    if metrics.get("n_labeled_rows", 0) == 0:
        print(" [INFO] No labeled rows found in the evaluation window.")
        print("        (Real ground-truth labels are held back on ~3% of rows by organizers).")
        print("        To evaluate and benchmark Precision@20 / Recall on simulation labels, run:")
        print("            python scripts/run_pipeline.py --stage all --demo")
        print("        Or place the official organizer labels in data/raw/labels.csv and re-run.")
        print("-" * 65)

    if p_budgets:
        print(" BUDGET SENSITIVITY (Precision @ Daily Shelf Audit Limit):")
        for k in (5, 10, 20, 30):
            k_key = f"precision_at_{k}"
            k_res = p_budgets.get(k_key, {})
            k_macro = k_res.get("macro_average")
            k_str = f"{k_macro*100:.1f}%" if k_macro is not None else "N/A"
            print(f"     - Limit = {k:2d} shelves/day: Precision = {k_str}")
        print("-" * 65)

    if fmt_breakdown:
        print(" ACCURACY BY STORE FORMAT:")
        for fmt, val in fmt_breakdown.items():
            print(f"     - {fmt.title():15s}: {val*100:.1f}%")
        print("-" * 65)

    print(" Reports written to:")
    print(f"  - JSON: {cfg['files']['evaluation_json']}")
    print(f"  - Markdown: {cfg['files']['evaluation_md']}")
    print("=" * 65 + "\n")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
