"use client";

import React, { useEffect, useMemo, useState } from "react";
import {
  Activity,
  ArrowLeft,
  CalendarDays,
  CheckCircle2,
  CircleHelp,
  Clock3,
  Info,
  MapPin,
  PackageCheck,
  RefreshCw,
  ShieldAlert,
} from "lucide-react";
import {
  Bar,
  Brush,
  CartesianGrid,
  ComposedChart,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  AlertItem,
  AuditItem,
  getAlerts,
  getAudits,
  getHealth,
  getHistory,
  HistoryPoint,
  saveAudit,
} from "../../lib/api";
import { Button } from "../../components/ui/button";

const inr = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 });

function formatBusinessDate(value: string | null | undefined, options: Intl.DateTimeFormatOptions) {
  if (!value) return "—";

  // The API may return either YYYY-MM-DD or a full ISO timestamp. Parse the
  // date portion as local calendar fields so timestamps cannot shift a day.
  const dateParts = value.match(/^(\d{4})-(\d{2})-(\d{2})(?:$|T)/);
  const parsed = dateParts
    ? new Date(Number(dateParts[1]), Number(dateParts[2]) - 1, Number(dateParts[3]))
    : new Date(value);

  return Number.isNaN(parsed.getTime()) ? "—" : parsed.toLocaleDateString("en-IN", options);
}

function priorityStyle(priority: string) {
  const value = priority.toLowerCase();
  if (value.includes("critical")) return "border-rose-200 bg-rose-50 text-rose-800";
  if (value.includes("high")) return "border-amber-200 bg-amber-50 text-amber-800";
  return "border-slate-200 bg-slate-100 text-slate-700";
}

function categoryStyle(category: string) {
  const value = category.toLowerCase();
  if (value.includes("phantom")) return "border-rose-200 bg-rose-50 text-rose-800";
  if (value.includes("misplaced")) return "border-sky-200 bg-sky-50 text-sky-800";
  if (value.includes("delist")) return "border-violet-200 bg-violet-50 text-violet-800";
  return "border-slate-200 bg-slate-50 text-slate-700";
}

function classificationLabel(category: string) {
  const labels: Record<string, string> = {
    POSSIBLE_PHANTOM_STOCKOUT: "Possible phantom stock-out",
    POSSIBLE_MISPLACED: "Possible misplacement",
    POSSIBLE_DELISTED: "Possible delisted / dormant",
    NORMAL_SLOW_MOVER: "Possible slow mover",
    UNSPECIFIED_DISCREPANCY: "Unspecified discrepancy",
  };
  return labels[category] ?? category.replaceAll("_", " ").toLowerCase();
}

export default function InvestigatePage() {
  const [item, setItem] = useState<AlertItem | null>(null);
  const [history, setHistory] = useState<HistoryPoint[]>([]);
  const [audits, setAudits] = useState<AuditItem[]>([]);
  const [auditWritesEnabled, setAuditWritesEnabled] = useState(false);
  const [layers, setLayers] = useState({ sales: true, stock: true, demand: false });
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  useEffect(() => {
    const query = new URLSearchParams(window.location.search);
    const store = query.get("store") ?? "";
    const sku = query.get("sku") ?? "";
    const date = query.get("date") ?? "";
    let live = true;

    if (!store || !sku || !date) {
      setError("This investigation link is missing its store, SKU, or business date. Return to the daily queue and open Investigate again.");
      setLoading(false);
      return;
    }

    void Promise.all([
      getAlerts(store, date),
      getHistory(store, sku, date).catch(() => ({ points: [] as HistoryPoint[] })),
      getAudits(store, date),
      getHealth(),
    ]).then(([alerts, historyResult, auditRows, health]) => {
      if (!live) return;
      const found = alerts.find((alert) => alert.sku_id === sku);
      if (!found) setError(`SKU ${sku} is not in the daily check list for ${store} on ${date}.`);
      setItem(found ?? null);
      setHistory(historyResult.points);
      setAudits(auditRows.filter((audit) => audit.sku_id === sku));
      setAuditWritesEnabled(health.audit_writes_enabled);
    }).catch((cause: unknown) => {
      if (live) setError(cause instanceof Error ? cause.message : "Could not load this investigation.");
    }).finally(() => {
      if (live) setLoading(false);
    });

    return () => { live = false; };
  }, []);

  const chartData = useMemo(() => history.map((point) => ({
    ...point,
    dateLabel: formatBusinessDate(point.date, { day: "2-digit", month: "short" }),
    salesValue: point.sales ?? 0,
    stockValue: point.system_recorded_on_hand ?? point.on_hand ?? 0,
    demandValue: point.expected_demand ? Number(Number(point.expected_demand).toFixed(1)) : 0,
  })), [history]);

  const recent = history.slice(-7);
  const averageSales = recent.length ? recent.reduce((total, point) => total + (point.sales ?? 0), 0) / recent.length : 0;
  const zeroSalesStreak = [...history].reverse().reduce((count, point) => count + ((point.sales ?? 0) === 0 ? 1 : 0), 0);
  const latestPoint = history[history.length - 1];
  const latestAudit = audits[0];
  const businessDate = item ? formatBusinessDate(item.date, { day: "2-digit", month: "2-digit", year: "numeric" }) : "—";

  const toggleLayer = (key: keyof typeof layers) => {
    setLayers((current) => {
      const next = { ...current, [key]: !current[key] };
      return Object.values(next).some(Boolean) ? next : current;
    });
  };

  const submitOutcome = async (outcome: AuditItem["outcome"]) => {
    if (!item || !auditWritesEnabled) return;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const saved = await saveAudit({
        store_id: item.store_id,
        sku_id: item.sku_id,
        audit_date: item.date,
        outcome,
        notes: "Physical verification submitted from the product investigation view.",
      });
      setAudits((current) => [saved, ...current.filter((audit) => audit.id !== saved.id)]);
      setItem((current) => current ? {
        ...current,
        verified_on_hand: saved.inventory_adjusted_to ?? null,
        verified_outcome: outcome,
      } : current);
      setHistory((current) => current.map((point) => point.date === item.date
        ? {
            ...point,
            verified_on_hand: saved.inventory_adjusted_to ?? null,
            verified_outcome: outcome,
          }
        : point));
      setNotice(outcome === "stock_missing" ? "Stock shortage recorded. Replenishment details are available in the daily queue." : "Physical verification saved.");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not save the verification outcome.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="min-h-screen bg-[#f3f6f4] px-3 py-5 text-slate-900 sm:px-6 sm:py-8">
      <div className="mx-auto max-w-6xl space-y-4">
        <header className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm sm:px-5">
          <a href="/" className="inline-flex items-center gap-2 text-sm font-semibold text-[#125c43] hover:text-emerald-800"><ArrowLeft size={17} />Back to daily queue</a>
          <span className="inline-flex items-center gap-2 text-xs text-slate-500"><span className="h-2 w-2 rounded-full bg-emerald-500" />PhantomGuard · Product investigation</span>
        </header>

        {error && <div role="alert" className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">{error}</div>}
        {notice && <div role="status" className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">{notice}</div>}

        {loading ? (
          <section className="grid min-h-80 place-items-center rounded-2xl border border-slate-200 bg-white text-sm text-slate-500"><span className="inline-flex items-center gap-2"><RefreshCw size={16} className="animate-spin text-emerald-700" />Loading product evidence…</span></section>
        ) : item ? (
          <>
            <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-6">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`rounded-full border px-2.5 py-1 text-xs font-bold ${priorityStyle(item.priority)}`}>{item.priority}</span>
                    <span className={`rounded-full border px-2.5 py-1 text-xs font-semibold ${categoryStyle(item.classification)}`}>{classificationLabel(item.classification)}</span>
                  </div>
                  <h1 className="mt-2 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">{item.product_name || item.sku_id}</h1>
                  <p className="mt-1 text-sm text-slate-500">SKU: <span className="font-mono text-slate-700">{item.sku_id}</span><span className="mx-2 text-slate-300">|</span><MapPin size={14} className="inline" /> Store: {item.store_id}</p>
                </div>
                <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3">
                  <span className="block text-xs font-medium text-slate-500">Business date</span>
                  <span className="mt-1 flex items-center gap-2 text-sm font-bold text-slate-800"><CalendarDays size={15} className="text-emerald-700" />{businessDate}</span>
                </div>
              </div>
              <section aria-labelledby="flag-reason-title" className="mt-5 rounded-xl border border-amber-200 bg-amber-50 px-4 py-4 sm:px-5">
                <h2 id="flag-reason-title" className="flex items-center gap-2 text-lg font-bold text-amber-950"><Info size={19} className="shrink-0" />Why this was flagged</h2>
                <p className="mt-2 text-sm leading-6 text-slate-800 sm:text-base">{item.reason}</p>
                <div className="mt-3 flex flex-wrap gap-2 text-sm">
                  <span className="rounded-lg border border-amber-100 bg-white/85 px-3 py-2 text-slate-700">Promotion: <b className="text-slate-900">{latestPoint?.promo_flag == null ? "Unknown" : latestPoint.promo_flag > 0 ? "Active" : "None flagged"}</b></span>
                  <span className="rounded-lg border border-amber-100 bg-white/85 px-3 py-2 text-slate-700">Average sales: <b className="text-slate-900">{averageSales.toFixed(1)} units/day</b></span>
                </div>
              </section>
              <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
                <Metric label="System-recorded stock" value={`${item.system_recorded_on_hand ?? item.on_hand ?? 0} units`} />
                <Metric label="Avg. sales / day" value={`${averageSales.toFixed(1)} units`} hint="last 7 days" />
                <Metric label="Zero-sales streak" value={`${zeroSalesStreak} ${zeroSalesStreak === 1 ? "day" : "days"}`} />
                <Metric label="Model score" value={`${Math.round(item.predicted_probability * 100)}%`} />
                {item.verified_on_hand != null && <Metric label="Physically verified count" value={`${item.verified_on_hand} units`} hint={item.verified_outcome?.replaceAll("_", " ")} />}
              </div>
            </section>

            <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
              <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
                <h2 className="flex items-center gap-2 text-lg font-bold text-slate-900"><Activity size={18} className="text-emerald-700" />Evidence &amp; sales vs. stock</h2>
                <div className="flex flex-wrap gap-3 text-xs text-slate-500"><span><i className="mr-1.5 inline-block h-2.5 w-2.5 rounded-sm bg-sky-400" />Daily sales</span><span><i className="mr-1.5 inline-block h-2.5 w-2.5 rounded-full bg-blue-600" />Recorded stock</span></div>
              </div>
              {chartData.length ? (
                <div className="h-[300px] w-full rounded-xl border border-slate-100 bg-slate-50/50 p-2 sm:h-[360px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={chartData} margin={{ top: 12, right: 14, left: -10, bottom: 0 }}>
                      <CartesianGrid stroke="#e2e8f0" strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="dateLabel" tick={{ fontSize: 10, fill: "#64748b" }} tickLine={false} axisLine={false} minTickGap={24} />
                      <YAxis yAxisId="salesAxis" orientation="left" width={42} domain={[0, "auto"]} tick={{ fontSize: 10, fill: "#0284c7" }} tickLine={false} axisLine={false} />
                      <YAxis yAxisId="stockAxis" orientation="right" width={42} domain={[0, "auto"]} tick={{ fontSize: 10, fill: "#2563eb" }} tickLine={false} axisLine={false} />
                      <Tooltip contentStyle={{ borderRadius: 12, backgroundColor: "#fff", borderColor: "#e2e8f0", fontSize: 12, boxShadow: "0 4px 12px rgba(0,0,0,0.06)" }} />
                      {layers.sales && <Bar yAxisId="salesAxis" dataKey="salesValue" name="Daily sales" fill="#38bdf8" barSize={14} radius={[2, 2, 0, 0]} />}
                      {layers.stock && <Line yAxisId="stockAxis" type="monotone" dataKey="stockValue" name="Recorded stock" stroke="#2563eb" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" dot={false} activeDot={{ r: 3.5, fill: "#2563eb", stroke: "#fff", strokeWidth: 2 }} />}
                      {layers.demand && <Line yAxisId="salesAxis" type="monotone" dataKey="demandValue" name="Expected demand" stroke="#f59e0b" strokeWidth={2} strokeDasharray="4 4" dot={false} />}
                      <Brush dataKey="dateLabel" startIndex={Math.max(0, chartData.length - 28)} endIndex={Math.max(0, chartData.length - 1)} height={22} travellerWidth={10} stroke="#125c43" fill="#f8fafc" />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              ) : <div className="grid h-48 place-items-center rounded-xl border border-dashed border-slate-200 bg-slate-50 text-sm text-slate-500">Historical sales and stock data is unavailable for this item.</div>}
              <div aria-label="Chart series controls" className="mt-2 flex min-h-11 flex-wrap items-center justify-center gap-x-7 gap-y-1 rounded-xl px-2 py-2 text-xs">
                <SeriesControl active={layers.sales} color="sky" label="Sales (units)" onClick={() => toggleLayer("sales")} kind="bar" />
                <SeriesControl active={layers.stock} color="blue" label="Retail stock" onClick={() => toggleLayer("stock")} kind="line" />
                <SeriesControl active={layers.demand} color="amber" label="Expected demand" onClick={() => toggleLayer("demand")} kind="dashed" />
              </div>
            </section>

            <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <h2 className="flex items-center gap-2 text-base font-bold text-slate-900"><CircleHelp size={17} className="text-emerald-700" />Model signal</h2>
              <div className={`mt-3 flex flex-wrap items-center justify-between gap-3 rounded-xl border p-4 ${categoryStyle(item.classification)}`}>
                <b>{classificationLabel(item.classification)}</b>
                <span className="text-sm font-bold">Model score: {Math.round(item.predicted_probability * 100)}%</span>
              </div>
              <p className="mt-3 text-xs leading-5 text-slate-500">This is a risk signal for physical verification, not a diagnosis of theft or loss.</p>
            </section>

            <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
              <h2 className="flex items-center gap-2 text-lg font-bold text-slate-900"><PackageCheck size={18} className="text-emerald-700" />Physical verification</h2>
              <ol className="mt-4 grid gap-2 text-sm sm:grid-cols-4">
                {["Check the assigned shelf", "Check nearby aisles", "Check the backroom", "Record the result"].map((step, index) => <li key={step} className="flex items-center gap-2 rounded-xl bg-slate-50 px-3 py-3 text-slate-700"><span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-emerald-100 text-xs font-bold text-emerald-800">{index + 1}</span>{step}</li>)}
              </ol>
              {latestAudit && <p className="mt-4 rounded-xl border border-emerald-100 bg-emerald-50 px-4 py-3 text-sm text-emerald-900">Latest saved result: <b>{latestAudit.outcome.replaceAll("_", " ")}</b></p>}
              <div className="mt-4 grid gap-2 sm:grid-cols-3">
                <Button variant="secondary" size="sm" disabled={busy || !auditWritesEnabled} onClick={() => void submitOutcome("found_elsewhere")} className="min-h-11 border-slate-200">Found elsewhere</Button>
                <Button variant="danger" size="sm" disabled={busy || !auditWritesEnabled} onClick={() => void submitOutcome("stock_missing")} className="min-h-11">Stock missing</Button>
                <Button variant="primary" size="sm" disabled={busy || !auditWritesEnabled} onClick={() => void submitOutcome("found_on_shelf")} className="min-h-11">{latestAudit?.outcome === "found_on_shelf" ? "Found on shelf ✓" : "Found on shelf"}</Button>
              </div>
              {!auditWritesEnabled && <p className="mt-3 text-xs text-slate-500">This deployment is in view-only mode; physical verification results cannot be saved.</p>}
            </section>

            <details className="rounded-2xl border border-slate-200 bg-white shadow-sm">
              <summary className="flex cursor-pointer list-none items-center gap-2 px-5 py-4 text-sm font-semibold text-slate-800"><Clock3 size={17} className="text-slate-500" />History &amp; notes</summary>
              <div className="border-t border-slate-100 px-5 py-4">
                {audits.length ? <ul className="space-y-3">{audits.map((audit) => <li key={audit.id} className="flex flex-wrap justify-between gap-2 text-sm"><span className="font-medium text-slate-700">{audit.outcome.replaceAll("_", " ")}</span><span className="text-xs text-slate-500">{audit.created_at}</span>{audit.notes && <p className="w-full text-xs text-slate-500">{audit.notes}</p>}</li>)}</ul> : <p className="text-sm text-slate-500">No verification notes are saved for this item on this business date.</p>}
              </div>
            </details>
          </>
        ) : !error ? <div className="rounded-2xl border border-slate-200 bg-white p-6 text-sm text-slate-600">No matching daily alert was found.</div> : null}
      </div>
    </main>
  );
}

function Metric({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-3.5 sm:p-4"><span className="text-xs font-medium text-slate-500">{label}</span><strong className="mt-1 block text-lg font-bold text-slate-900 sm:text-xl">{value}</strong>{hint && <span className="text-[11px] text-slate-500">{hint}</span>}</div>;
}

function SeriesControl({ active, color, label, onClick, kind }: { active: boolean; color: "sky" | "blue" | "amber"; label: string; onClick: () => void; kind: "bar" | "line" | "dashed" }) {
  const colorMap = { sky: "bg-sky-500", blue: "bg-blue-600", amber: "bg-amber-500" };
  const textMap = { sky: "text-sky-800", blue: "text-blue-800", amber: "text-amber-800" };
  return <button type="button" aria-pressed={active} onClick={onClick} className={`inline-flex items-center gap-2 rounded px-1 py-1 transition-opacity ${active ? textMap[color] : "text-slate-400 opacity-60 hover:opacity-100"}`}>
    {kind === "bar" ? <span aria-hidden="true" className="flex h-3 items-end gap-0.5"><i className={`h-2 w-1 rounded-t-sm ${colorMap[color]}`} /><i className={`h-3 w-1 rounded-t-sm ${colorMap[color]}`} /><i className={`h-1.5 w-1 rounded-t-sm ${colorMap[color]}`} /></span> : kind === "line" ? <span aria-hidden="true" className="relative block h-0.5 w-5 bg-blue-600"><i className="absolute -top-1 left-2 h-2 w-2 rounded-full border-2 border-white bg-blue-600" /></span> : <span aria-hidden="true" className="block h-0.5 w-5 border-t-2 border-dashed border-amber-500" />}
    <span>{label}</span>
  </button>;
}
