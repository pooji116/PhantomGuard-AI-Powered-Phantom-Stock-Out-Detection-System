import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "PhantomGuard | Store operations", description: "A focused daily shelf-check list for store teams." };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
