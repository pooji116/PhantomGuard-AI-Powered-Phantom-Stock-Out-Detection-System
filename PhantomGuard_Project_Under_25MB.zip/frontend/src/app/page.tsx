"use client";

import { motion, AnimatePresence } from "framer-motion";
import Image from "next/image";
import {
  Activity,
  AlertCircle,
  ArrowUpRight,
  BadgeCheck,
  Bell,
  Boxes,
  Calendar,
  CheckCircle2,
  ChevronUp,
  CircleHelp,
  Clock,
  ChevronDown,
  ExternalLink,
  Flame,
  IndianRupee,
  Layers,
  MapPin,
  PackageCheck,
  PackageSearch,
  RefreshCw,
  Send,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  TrendingDown,
  TrendingUp,
  Truck,
  Zap,
} from "lucide-react";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Bar,
  BarChart,
  Cell,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  AlertItem,
  AuditItem,
  getAlerts,
  getAudits,
  getHealth,
  getImpact,
  getMetrics,
  getMorningDispatch,
  getStores,
  ImpactSummary,
  MorningDispatchResponse,
  saveAudit,
  StoreResponse,
  triggerMorningCron,
} from "../lib/api";
import { buildQueueRiskChartData, queueRiskColors, riskPriorityOrder } from "../lib/risk-chart";
import { Button } from "../components/ui/button";

const inr = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});
const compactInr = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  notation: "compact",
  maximumFractionDigits: 1,
});
function riskClass(priority: string) {
  const p = priority.toLowerCase();
  if (p.includes("critical")) return "bg-rose-100 text-rose-800 border-rose-300 font-bold";
  if (p.includes("high")) return "bg-amber-100 text-amber-800 border-amber-300 font-semibold";
  return "bg-emerald-100 text-emerald-800 border-emerald-300 font-medium";
}

function niceDate(value: string) {
  return new Date(`${value}T00:00:00`).toLocaleDateString("en-IN", {
    weekday: "short",
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function getGreeting(hour: number) {
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  return "Good evening";
}

type EvaluationMetric = {
  macro_average?: number | null;
  n_store_days?: number;
};

type EvaluationReport = {
  by_source?: {
    model?: {
      synthetic_demo?: boolean;
      scores_calibrated?: boolean;
      precision_at_5?: EvaluationMetric;
      precision_at_20?: EvaluationMetric;
      recall?: { recall?: number | null; positives?: number; captured?: number };
    };
  };
};

function formatCrore(value: number | null | undefined) {
  if (value == null || !Number.isFinite(value)) return "—";
  return `₹${(value / 10000000).toLocaleString("en-IN", { maximumFractionDigits: 2 })} Cr`;
}

function productImageFor(productName: string) {
  const name = productName.toLowerCase();
  if (name.includes("dairy")) return "/products/dairy.png";
  if (name.includes("beverage")) return "/products/beverages.png";
  if (name.includes("home care") || name.includes("personal care") || name.includes("baby care")) return "/products/home-care.png";
  if (name.includes("staples")) return "/products/staples.png";
  return "/products/packaged-foods.png";
}

function classificationBadge(cls: string) {
  const c = (cls || "").toUpperCase();
  if (c.includes("PHANTOM")) {
    return {
      label: "Possible Phantom Stock-out",
      bg: "bg-rose-50 text-rose-700 border-rose-200",
      icon: "🏷️",
      tag: "CRITICAL_LEAK",
      desc: "Recent sales stopped while system-recorded stock remains. This is a possible phantom stock-out; physically check the shelf and backroom before changing inventory.",
    };
  }
  if (c.includes("MISPLACED")) {
    return {
      label: "Possible Misplacement",
      bg: "bg-amber-50 text-amber-800 border-amber-200",
      icon: "🔄",
      tag: "DISLOCATED_ITEM",
      desc: "Inventory movement or a sales rebound may indicate that the product was moved. Check nearby aisles and staging areas; sales data cannot confirm its location.",
    };
  }
  if (c.includes("DELIST")) {
    return {
      label: "Possible Delisted / Dormant",
      bg: "bg-purple-50 text-purple-700 border-purple-200",
      icon: "📦",
      tag: "SUPPLY_DISCONNECT",
      desc: "Sales have been quiet across comparable stores. This may reflect a dormant or delisted product rather than a local shelf issue; confirm assortment status before changing stock.",
    };
  }
  if (c.includes("SLOW_MOVER")) {
    return {
      label: "Possible Slow Mover",
      bg: "bg-slate-100 text-slate-700 border-slate-200",
      icon: "ℹ️",
      tag: "LOW_BASELINE_DEMAND",
      desc: "This product has a history of low or intermittent sales. A quiet day alone is weak evidence of a shelf problem; verify before taking action.",
    };
  }
  return {
    label: "Unspecified Discrepancy",
    bg: "bg-slate-100 text-slate-700 border-slate-200",
    icon: "⚠️",
    tag: "IRREGULARITY",
    desc: "The available sales and inventory history does not support a specific cause. Treat this as an alert for physical verification, not a confirmed diagnosis.",
  };
}

export default function WorkspacePage() {
  const [stores, setStores] = useState<string[]>([]);
  const [latestByStore, setLatestByStore] = useState<Record<string, string>>({});
  const [store, setStore] = useState("");
  const [date, setDate] = useState("");
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [selected, setSelected] = useState<AlertItem | null>(null);
  const [audits, setAudits] = useState<AuditItem[]>([]);
  const [metrics, setMetrics] = useState<EvaluationReport | null>(null);
  const [impact, setImpact] = useState<ImpactSummary | null>(null);
  const [morningNotification, setMorningNotification] = useState<MorningDispatchResponse | null>(null);
  const [apiConnected, setApiConnected] = useState(false);
  const [auditWritesEnabled, setAuditWritesEnabled] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [activeTab, setActiveTab] = useState<"queue" | "reports">("queue");
  const [riskChartView, setRiskChartView] = useState<"priority" | "sku">("priority");
  const [sidebarNavigationOpen, setSidebarNavigationOpen] = useState(false);
  const [checkInTime, setCheckInTime] = useState("");
  const [greeting, setGreeting] = useState("Good day");
  const [lastReplenishmentNotice, setLastReplenishmentNotice] = useState<{
    orderId: string;
    sku: string;
    status: string;
  } | null>(null);
  const queueRequestSequence = useRef(0);

  // Initialize workspace clock
  useEffect(() => {
    const now = new Date();
    setGreeting(getGreeting(now.getHours()));
    const formatted = now.toLocaleDateString("en-IN", {
      weekday: "long",
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: true,
    });
    setCheckInTime(formatted);
  }, []);

  // Select an alert to update the inline investigation without changing page position.
  const handleSelectAlert = (item: AlertItem) => {
    setSelected(item);
  };

  const openInvestigation = (item: AlertItem) => {
    const query = new URLSearchParams({ store: item.store_id, sku: item.sku_id, date: item.date });
    window.location.assign(`/investigate?${query.toString()}`);
  };

  const loadQueue = useCallback(async (selectedStore: string, selectedDate?: string) => {
    if (!selectedStore) return;
    const requestId = ++queueRequestSequence.current;
    setBusy(true);
    setError("");
    try {
      const [queue, auditRows, dispatch] = await Promise.all([
        getAlerts(selectedStore, selectedDate),
        getAudits(selectedStore, selectedDate ?? ""),
        getMorningDispatch(selectedStore, selectedDate).catch(() => null),
      ]);
      if (requestId !== queueRequestSequence.current) return;
      setAlerts(queue);
      setAudits(auditRows);
      if (dispatch) setMorningNotification(dispatch);
      if (selectedDate) setDate(selectedDate);
      setSelected(queue[0] ?? null);
    } catch (e) {
      if (requestId === queueRequestSequence.current) {
        setError(e instanceof Error ? e.message : "Could not load store checks");
      }
    } finally {
      if (requestId === queueRequestSequence.current) setBusy(false);
    }
  }, []);

  const refreshAll = useCallback(async () => {
    setBusy(true);
    setError("");
    try {
      const [result, report, impactReport, health] = await Promise.all([
        getStores(),
        getMetrics(),
        getImpact(),
        getHealth(),
      ]);
      const storeData = result as StoreResponse;
      setApiConnected(health.status === "ok" && health.data_ready);
      setAuditWritesEnabled(health.audit_writes_enabled);
      setStores(storeData.stores);
      setLatestByStore(storeData.latest_by_store);
      setMetrics(report as EvaluationReport);
      setImpact(impactReport);

      const activeStore = store || storeData.stores[0] || "";
      const activeDate =
        date || (activeStore ? storeData.latest_by_store[activeStore] ?? storeData.latest_date ?? "" : "");
      if (!store && activeStore) setStore(activeStore);
      if (!date && activeDate) setDate(activeDate);

      if (activeStore) {
        await loadQueue(activeStore, activeDate);
      }
    } catch (e) {
      setApiConnected(false);
      setError(e instanceof Error ? e.message : "PhantomGuard API is unavailable");
    } finally {
      setBusy(false);
    }
  }, [store, date, loadQueue]);

  useEffect(() => {
    void refreshAll();
  }, []);

  useEffect(() => {
    if (store && date) {
      void loadQueue(store, date);
    }
  }, [store, date, loadQueue]);

  // Completed items index
  const completedMap = useMemo(() => {
    const map = new Map<string, AuditItem>();
    for (const a of audits) {
      if (!map.has(a.sku_id)) map.set(a.sku_id, a);
    }
    return map;
  }, [audits]);

  const riskChartData = useMemo(() => buildQueueRiskChartData(alerts), [alerts]);
  const { uniqueItems: uniqueQueueItems, duplicateSkuRows, totalRisk: moneyAtRisk, priorityData: queueRiskByPriority, topSkus: topRiskSkus } = riskChartData;
  const completeCount = uniqueQueueItems.filter((a) => completedMap.has(a.sku_id)).length;
  const dailyQueueCount = Math.min(uniqueQueueItems.length, 20);
  const remainingChecks = Math.max(0, dailyQueueCount - completeCount);
  const modelEvaluation = metrics?.by_source?.model;
  const precisionAt5 = modelEvaluation?.precision_at_5?.macro_average;
  const precisionAt20 = modelEvaluation?.precision_at_20?.macro_average;
  const precisionStoreDays = modelEvaluation?.precision_at_20?.n_store_days;
  const evaluationRecall = modelEvaluation?.recall?.recall;
  const annualRecovery = impact?.estimated_annualized_potential_recovery;
  const periodRecovery = impact?.estimated_period_potential_recovery;
  const impactPeriodDays = impact?.observed_period_days;

  // CRITICAL LEAK WORKFLOW ACTION HANDLER
  const handleAuditOutcome = async (outcome: AuditItem["outcome"]) => {
    if (!selected || !date) return;
    setBusy(true);
    setError("");
    try {
      const saved = await saveAudit({
        store_id: store,
        sku_id: selected.sku_id,
        audit_date: date,
        outcome,
        notes: `Operational shelf verification submitted by floor manager on ${checkInTime}`,
      });

      // Preserve the system ledger value and attach the authorized physical finding separately.
      const verifiedOnHand = saved.inventory_adjusted_to ?? null;
      setSelected((prev) => prev ? { ...prev, verified_on_hand: verifiedOnHand, verified_outcome: outcome } : null);
      setAlerts((prev) => prev.map((alert) => alert.sku_id === selected.sku_id
        ? { ...alert, verified_on_hand: verifiedOnHand, verified_outcome: outcome }
        : alert));

      if (outcome === "stock_missing" && saved.replenishment_order_id) {
        setLastReplenishmentNotice({
          orderId: saved.replenishment_order_id,
          sku: selected.sku_id,
          status: saved.replenishment_status ?? "DISPATCHED_TO_DISTRIBUTION_CENTER",
        });

        setSelected((prev) => (prev ? { ...prev, replenishment_triggered: true } : null));
        setAlerts((prev) => prev.map((a) => (a.sku_id === selected.sku_id ? { ...a, replenishment_triggered: true } : a)));
      }

      setAudits(await getAudits(store, date));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not complete the physical audit transaction");
    } finally {
      setBusy(false);
    }
  };

  const handleSimulateMorningCron = async () => {
    if (!store) return;
    setBusy(true);
    try {
      const res = await triggerMorningCron(store, date);
      setMorningNotification(res);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Morning cron simulation failed");
    } finally {
      setBusy(false);
    }
  };

  const selectedAudit = selected ? completedMap.get(selected.sku_id) : null;
  const isSelectedCompleted = Boolean(selectedAudit);
  return (
    <main className="min-h-screen bg-[#f3f5f2] text-slate-900 pb-16 font-sans">
      <div className="mx-auto flex min-h-screen max-w-[1920px]">
        <aside className={`sticky top-0 hidden h-screen shrink-0 flex-col bg-[#073b32] py-5 text-white transition-[width,padding] duration-300 ease-in-out lg:flex ${sidebarNavigationOpen ? "w-56 px-4 xl:w-64" : "w-16 px-2"}`}>
          <button
            type="button"
            aria-label={sidebarNavigationOpen ? "Close workspace navigation" : "Open workspace navigation"}
            aria-expanded={sidebarNavigationOpen}
            aria-controls={sidebarNavigationOpen ? "primary-navigation" : undefined}
            title={sidebarNavigationOpen ? "Close navigation" : "Open navigation"}
            onClick={() => setSidebarNavigationOpen((open) => !open)}
            className={`flex w-full items-center gap-3 outline-none focus-visible:ring-2 focus-visible:ring-emerald-200 ${sidebarNavigationOpen ? "justify-between border-b border-white/10 px-2 pb-5 text-left" : "justify-center rounded-xl p-1"}`}
          >
            <span className={`flex min-w-0 items-center ${sidebarNavigationOpen ? "gap-3" : "justify-center"}`}>
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-emerald-500/20 text-emerald-100"><ShieldCheck size={22} /></span>
              {sidebarNavigationOpen && <span><span className="block text-sm font-bold">PhantomGuard</span><span className="block text-xs text-emerald-100/70">Enterprise</span></span>}
            </span>
            {sidebarNavigationOpen && <ChevronDown size={16} aria-hidden="true" className="shrink-0 rotate-180 text-emerald-100/70 transition-transform duration-200" />}
          </button>
          <AnimatePresence initial={false}>
            {sidebarNavigationOpen && (
              <motion.nav
                id="primary-navigation"
                aria-label="Primary navigation"
                initial={{ height: 0, opacity: 0, x: -10 }}
                animate={{ height: "auto", opacity: 1, x: 0 }}
                exit={{ height: 0, opacity: 0, x: -10 }}
                transition={{ duration: 0.18, ease: "easeInOut" }}
                className="overflow-hidden"
              >
                <div className="space-y-1.5 pt-4">
                  <button type="button" aria-current={activeTab === "queue" ? "page" : undefined} onClick={() => setActiveTab("queue")} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm transition-colors ${activeTab === "queue" ? "bg-emerald-500/20 font-semibold text-white" : "text-emerald-50/75 hover:bg-white/10 hover:text-white"}`}>
                    <PackageCheck size={18} /> Daily Tasks
                  </button>
                  <button type="button" aria-current={activeTab === "reports" ? "page" : undefined} onClick={() => setActiveTab("reports")} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm transition-colors ${activeTab === "reports" ? "bg-emerald-500/20 font-semibold text-white" : "text-emerald-50/75 hover:bg-white/10 hover:text-white"}`}>
                    <TrendingUp size={18} /> Business Reports
                  </button>
                </div>
              </motion.nav>
            )}
          </AnimatePresence>
          {sidebarNavigationOpen && <div className="mt-auto border-t border-white/10 px-2 pt-4 text-xs text-emerald-50/70">
            <p className="font-semibold text-white">Store operations</p>
            <p className="mt-1">Daily shelf verification</p>
          </div>}
        </aside>
        <div className="min-w-0 flex-1">
      <div className="mx-auto max-w-[1600px] px-4 py-5 sm:px-6 sm:py-7 lg:px-8">
        {/* TOP STATUS BAR */}
        <header className="mb-5 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-slate-200/80 bg-white px-5 py-4 shadow-sm sm:px-6">
          <div className="flex items-center gap-3.5">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-[#125c43] text-white shadow-sm">
              <ShieldCheck size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold tracking-tight text-slate-900 sm:text-xl">PhantomGuard Enterprise</span>
                <span className="rounded-md bg-emerald-100 px-2 py-0.5 text-[10px] font-bold tracking-wide uppercase text-emerald-800">
                  SaaS v2.0
                </span>
              </div>
              <div className="text-xs text-slate-500">Autonomous retail leak detector & shelf-audit operations</div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <div
              className={`flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-semibold ${
                apiConnected ? "bg-emerald-50 text-emerald-800 border border-emerald-200" : "bg-rose-50 text-rose-700 border border-rose-200"
              }`}
            >
              <span className={`h-2 w-2 rounded-full ${apiConnected ? "animate-pulse bg-emerald-500" : "bg-rose-500"}`} />
              {apiConnected ? "Live Cluster Connected" : "API Offline"}
            </div>

            <Button
              variant="secondary"
              size="sm"
              onClick={() => void refreshAll()}
              disabled={busy}
              className="text-xs font-semibold h-9"
            >
              <RefreshCw size={13} className={`mr-1.5 ${busy ? "animate-spin" : ""}`} />
              Sync
            </Button>
          </div>
        </header>

        {/* DYNAMIC WELCOME MESSAGE LAYOUT BANNER */}
        <section className="-mx-1.5 mb-5 overflow-hidden rounded-2xl bg-gradient-to-r from-[#103b2f] via-[#145c43] to-[#1b7957] px-6 py-6 text-white shadow-sm sm:-mx-2 sm:px-8 sm:py-7 lg:-mx-3">
          <div className="flex flex-col justify-between gap-6 md:flex-row md:items-center">
            <div className="max-w-3xl space-y-2.5">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.1em] text-emerald-200">
                <Sparkles size={14} className="text-emerald-300" />
                SHIFT CHECK-IN ACTIVE
              </div>
              <h1 className="max-w-3xl text-3xl font-bold leading-tight tracking-tight sm:text-4xl">
                {greeting}, Store Operations Manager
              </h1>
              <p className="max-w-2xl text-sm leading-6 text-emerald-50/90 sm:text-base">
                Review today&apos;s highest-priority shelf checks. Verify each item on the shelf and in the backroom.
              </p>
              <div className="flex flex-wrap gap-x-5 gap-y-2 border-t border-white/15 pt-3 text-xs font-medium text-emerald-50/90 sm:text-sm">
                <span className="inline-flex items-center gap-1.5"><Clock size={14} />{checkInTime || "Shift time loading"}</span>
                <span className="inline-flex items-center gap-1.5"><MapPin size={14} />Store: {store || "Select a store"}</span>
                <span className="inline-flex items-center gap-1.5"><Calendar size={14} />Date: {date ? new Date(`${date}T00:00:00`).toLocaleDateString("en-IN", { day: "2-digit", month: "2-digit", year: "numeric" }) : "Select a date"}</span>
                <span className="inline-flex items-center gap-1.5"><span className={`h-2 w-2 rounded-full ${apiConnected ? "bg-emerald-300" : "bg-amber-300"}`} />System Sync: {apiConnected ? "Active" : "Waiting"}</span>
              </div>
            </div>

            <div className="flex flex-col gap-2 rounded-xl border border-white/15 bg-black/15 p-3 sm:flex-row sm:items-center sm:gap-3 md:shrink-0">
              <label className="flex items-center justify-between gap-3 text-xs font-medium text-emerald-100 sm:justify-start">
                <span className="flex items-center gap-1.5"><MapPin size={14} /> Store</span>
                <select
                  value={store}
                  onChange={(e) => {
                    const next = e.target.value;
                    setStore(next);
                    setDate(latestByStore[next] ?? date);
                  }}
                  className="min-w-24 rounded-lg border border-emerald-500/50 bg-[#0e3b2e] px-3 py-2 text-sm font-semibold text-white outline-none focus:ring-2 focus:ring-emerald-200"
                >
                  {stores.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </label>

              <label className="flex items-center justify-between gap-3 text-xs font-medium text-emerald-100 sm:justify-start">
                <span className="flex items-center gap-1.5"><Calendar size={14} /> Date</span>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="rounded-lg border border-emerald-500/50 bg-[#0e3b2e] px-3 py-2 text-sm font-medium text-white outline-none focus:ring-2 focus:ring-emerald-200"
                />
              </label>
            </div>
          </div>
        </section>

        <nav aria-label="Workspace views" className="mb-5 flex gap-1 overflow-x-auto rounded-2xl border border-slate-200 bg-white p-1.5 shadow-sm lg:hidden">
          <button
            type="button"
            aria-current={activeTab === "queue" ? "page" : undefined}
            onClick={() => setActiveTab("queue")}
            className={`flex min-h-11 shrink-0 items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm transition-colors sm:flex-1 ${activeTab === "queue" ? "bg-[#125c43] font-bold text-white shadow-sm" : "font-medium text-slate-600 hover:bg-slate-50"}`}
          >
            <span aria-hidden="true">📋</span> Daily Task Queue
          </button>
          <button
            type="button"
            aria-current={activeTab === "reports" ? "page" : undefined}
            onClick={() => setActiveTab("reports")}
            className={`flex min-h-11 shrink-0 items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm transition-colors sm:flex-1 ${activeTab === "reports" ? "bg-[#125c43] font-bold text-white shadow-sm" : "font-medium text-slate-600 hover:bg-slate-50"}`}
          >
            <TrendingUp size={16} /> Business Valuation Reports
          </button>
        </nav>

        {/* CRITICAL METRICS NOTIFICATION INTERRUPT: 07:00 AM Cron Banner */}
        {activeTab === "queue" && <section className="mb-5 rounded-2xl border border-amber-200 bg-amber-50/80 p-4 sm:px-5">
          <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
            <div className="flex min-w-0 items-start gap-3">
              <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-amber-100 text-amber-800">
                <Bell size={16} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="rounded-md bg-amber-100 px-2 py-1 text-[11px] font-bold uppercase tracking-wide text-amber-900">
                    07:00 AM Morning Dispatch Trigger
                  </span>
                  <span className="flex items-center gap-1 text-xs font-medium text-amber-800">
                    <Clock size={11} /> Daily Cron Schedule: 07:00 AM IST
                  </span>
                </div>
                <p className="mt-1 text-sm leading-5 text-slate-700">
                  {morningNotification?.notification_payload?.body ||
                    "Your daily shelf-check queue is ready for verification."}
                </p>
              </div>
            </div>

            <Button
              variant="secondary"
              size="sm"
              onClick={handleSimulateMorningCron}
              disabled={busy}
              className="text-xs font-semibold h-8 border-amber-400 bg-white hover:bg-amber-100 text-amber-900 shrink-0"
            >
              <Zap size={13} className="mr-1 text-amber-600" />
              Simulate 07:00 AM Push Dispatch
            </Button>
          </div>
        </section>}

        {/* ERROR BANNER */}
        {error && (
          <div className="mb-4 flex items-center justify-between rounded-xl border border-rose-200 bg-rose-50 p-3.5 text-xs sm:text-sm text-rose-800">
            <div className="flex items-center gap-2">
              <AlertCircle size={16} className="shrink-0 text-rose-600" />
              <span>{error}</span>
            </div>
            <span className="font-mono text-xs text-rose-700">Ensure FastAPI service is active on port 8000</span>
          </div>
        )}

        {/* CRITICAL REPLENISHMENT DISPATCH TOAST / BANNER */}
        <AnimatePresence>
          {lastReplenishmentNotice && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-emerald-300 bg-emerald-50 px-4 py-3 text-xs sm:text-sm text-emerald-900 shadow-sm"
            >
              <div className="flex items-center gap-2.5">
                <Truck size={18} className="text-emerald-700 animate-bounce" />
                <div>
                  <b className="font-bold">Automated Warehouse Replenishment Triggered:</b> Ledger inventory for{" "}
                  <span className="font-mono font-bold">{lastReplenishmentNotice.sku}</span> decremented to 0 units. Order{" "}
                  <span className="font-mono font-bold text-emerald-950 underline">{lastReplenishmentNotice.orderId}</span>{" "}
                  dispatched to Central Distribution Center.
                </div>
              </div>
              <button
                onClick={() => setLastReplenishmentNotice(null)}
                className="text-xs font-bold text-emerald-800 hover:text-emerald-950 underline"
              >
                Dismiss
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {activeTab === "reports" && (
            <section className="mb-4 overflow-hidden rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <div className="mb-4 flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <div className="grid h-8 w-8 place-items-center rounded-lg bg-emerald-100 text-[#125c43]">
                    <TrendingUp size={16} />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-slate-900">Model Evaluation & Annual INR Recovery</h2>
                    <p className="text-xs text-slate-500">{modelEvaluation?.synthetic_demo ? "Chronological holdout on synthetic demo labels; not organizer-verified results." : "Chronological holdout using the configured evaluation labels."}</p>
                  </div>
                </div>
                <span className="rounded-full bg-emerald-50 border border-emerald-200 px-3 py-1 text-xs font-extrabold text-[#125c43]">
                  Per-store-day Precision@20
                </span>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-3.5">
                  <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Precision@5</span>
                  <div className="text-xl font-bold text-slate-900 mt-1">{precisionAt5 != null ? `${(precisionAt5 * 100).toFixed(1)}%` : "—"}</div>
                  <span className="text-[10px] text-slate-500">Top 5 alerts in the test period</span>
                </div>
                <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-3.5">
                  <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Precision@20</span>
                  <div className="text-xl font-bold text-[#125c43] mt-1">{precisionAt20 != null ? `${(precisionAt20 * 100).toFixed(1)}%` : "—"}</div>
                  <span className="text-[10px] text-slate-500">{precisionStoreDays != null ? `Across ${precisionStoreDays.toLocaleString("en-IN")} store-days` : "No evaluation data available"}</span>
                </div>
                <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-3.5">
                  <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">{modelEvaluation?.synthetic_demo ? "Recall on Demo Labels" : "Recall on Held-out Labels"}</span>
                  <div className="text-xl font-bold text-slate-900 mt-1">{evaluationRecall != null ? `${(evaluationRecall * 100).toFixed(1)}%` : "—"}</div>
                  <span className="text-[10px] text-slate-500">{modelEvaluation?.recall?.captured != null && modelEvaluation.recall.positives != null ? `${modelEvaluation.recall.captured.toLocaleString("en-IN")} of ${modelEvaluation.recall.positives.toLocaleString("en-IN")} positives captured` : "No recall data available"}</span>
                </div>
                <div className="rounded-xl border border-emerald-200 bg-emerald-50/60 p-3.5">
                  <span className="text-[11px] font-semibold text-emerald-800 uppercase tracking-wider">Projected Annual Recovery</span>
                  <div className="text-xl font-extrabold text-[#125c43] mt-1">
                    {annualRecovery != null ? inr.format(annualRecovery) : "—"}
                  </div>
                  <span className="text-[10px] text-emerald-700 font-medium">{formatCrore(annualRecovery)} / year across {stores.length || "—"} stores</span>
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3.5 text-xs text-slate-600 space-y-1">
                <b className="text-slate-800">Clear Arithmetic Methodology:</b>
                <p>
                  1. <b>Daily Revenue at Risk</b> = Expected Daily Demand × Unit Price.
                </p>
                <p>
                  2. <b>Potential Recovery</b> = estimated incident revenue at risk × {impact ? `${(impact.recoverable_fraction * 100).toFixed(0)}%` : "configured recoverable share"} assumption.
                </p>
                <p>
                  3. <b>Deduplication</b> = consecutive alert dates for the same store and SKU are grouped; each incident is counted once.
                </p>
                <p>
                  4. <b>Annualized</b> = Period Recovery ({periodRecovery != null ? inr.format(periodRecovery) : "—"} over {impactPeriodDays ?? "—"} observed days) × (365 ÷ {impactPeriodDays ?? "—"}) = <b>{formatCrore(annualRecovery)} / year</b>.
                </p>
              </div>
            </section>
        )}

        {/* KPI OVERVIEW METRICS */}
        {activeTab === "queue" && <>
        <section className="mb-4 rounded-2xl border border-emerald-200 bg-white p-5 shadow-sm sm:p-6">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.14em] text-[#125c43]">Today&apos;s verification progress</p>
              <h2 className="mt-1 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
                {store || "Select a store"}{date ? ` · ${new Date(`${date}T00:00:00`).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}` : ""}
              </h2>
              <p className="mt-1 text-sm text-slate-500">Verify the shelf, nearby aisles, and backroom before updating stock.</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="text-2xl font-bold leading-none text-[#125c43]">{completeCount}<span className="text-base font-medium text-slate-400"> / {dailyQueueCount}</span></p>
                <p className="mt-1 text-xs font-medium text-slate-500">checks completed</p>
              </div>
              <span className="rounded-full bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-800">{remainingChecks} remaining</span>
            </div>
          </div>
          <div className="mt-5 h-2.5 overflow-hidden rounded-full bg-slate-100" role="progressbar" aria-label="Daily checks completed" aria-valuemin={0} aria-valuemax={Math.max(dailyQueueCount, 1)} aria-valuenow={completeCount}>
            <div className="h-full rounded-full bg-emerald-600 transition-[width] duration-300" style={{ width: `${dailyQueueCount ? Math.min(100, (completeCount / dailyQueueCount) * 100) : 0}%` }} />
          </div>
        </section>

        <section aria-label="Daily check summary" className="mb-5 grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
            <div className="flex items-center justify-between text-sm font-semibold text-slate-600"><span>Today&apos;s check list</span><AlertCircle size={18} className="text-emerald-700" /></div>
            <div className="mt-3 text-3xl font-bold tracking-tight text-slate-900">{dailyQueueCount}<span className="ml-1 text-base font-medium text-slate-400">/ 20</span></div>
            <p className="mt-1 text-xs text-slate-500">Items prioritized · daily limit 20</p>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
            <div className="flex items-center justify-between text-sm font-semibold text-slate-600"><span>Checks completed</span><PackageCheck size={18} className="text-emerald-700" /></div>
            <div className="mt-3 text-3xl font-bold tracking-tight text-slate-900">{completeCount}</div>
            <p className="mt-1 text-xs text-slate-500">Verified out of {dailyQueueCount} assigned</p>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
            <div className="flex items-center justify-between text-sm font-semibold text-slate-600"><span>Checks remaining</span><Clock size={18} className="text-amber-600" /></div>
            <div className="mt-3 text-3xl font-bold tracking-tight text-slate-900">{remainingChecks}</div>
            <p className="mt-1 text-xs text-slate-500">Still to verify from today&apos;s list</p>
          </div>
          <div className="rounded-2xl border border-amber-200 bg-amber-50/60 p-4 shadow-sm sm:p-5">
            <div className="flex items-center justify-between text-sm font-semibold text-amber-900"><span>Estimated sales at risk</span><IndianRupee size={18} className="text-amber-700" /></div>
            <div className="mt-3 text-3xl font-bold tracking-tight text-slate-900">{inr.format(moneyAtRisk)}</div>
            <p className="mt-1 text-xs text-amber-800/80">Potential loss tied to this check list</p>
          </div>
        </section>

        {/* Full-width queue followed by the selected item investigation. */}
        <div className="space-y-5">
          <div className="grid items-start gap-5 xl:grid-cols-[minmax(0,1fr)_320px]">
          {/* LEFT PANEL: ACTIONABLE SHELF-CHECK QUEUE (DYNAMIC INTERLEAVED SORT) */}
          <div className="space-y-3">
            <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
              <div className="mb-5 flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
                <div>
                  <h2 className="flex flex-wrap items-center gap-2 text-xl font-bold tracking-tight text-slate-900 sm:text-2xl">
                    Today&apos;s shelf-check queue
                  </h2>
                  <p className="mt-1 text-sm text-slate-500">Highest-priority items first. Verify each one physically.</p>
                </div>
                <span className="rounded-full bg-emerald-50 px-3 py-1.5 text-sm font-semibold text-[#125c43]">{dailyQueueCount} of 20 checks</span>
              </div>

              {busy && alerts.length === 0 ? (
                <div className="grid min-h-[360px] place-items-center text-xs text-slate-500">
                  <span className="flex items-center gap-2">
                    <RefreshCw size={16} className="animate-spin text-[#125c43]" /> Loading daily store queue…
                  </span>
                </div>
              ) : alerts.length === 0 ? (
                <div className="grid min-h-[360px] place-items-center rounded-xl border border-dashed border-slate-200 bg-slate-50 p-6 text-center text-xs text-slate-500">
                  <div>
                    <BadgeCheck size={32} className="mx-auto text-emerald-600 mb-2" />
                    <b className="text-slate-800 text-sm">No Urgent Anomalies Found</b>
                    <p className="mt-1">All store SKU stock records match checkout demand for this date.</p>
                  </div>
                </div>
              ) : (
                <div className="max-h-[760px] space-y-2.5 overflow-y-auto pr-1">
                  {alerts.map((alert, idx) => {
                    const badge = classificationBadge(alert.classification);
                    const isSelected = selected?.sku_id === alert.sku_id;
                    const isAudited = completedMap.has(alert.sku_id);
                    const auditedRecord = completedMap.get(alert.sku_id);

                    return (
                      <motion.div
                        layout
                        key={`${alert.store_id}-${alert.sku_id}-${alert.date}`}
                        onClick={() => handleSelectAlert(alert)}
                        className={`cursor-pointer rounded-xl border p-3.5 transition-all ${
                          isSelected
                            ? "border-[#125c43] bg-emerald-50/70 shadow-sm ring-1 ring-[#125c43]/30"
                            : "border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/80"
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div
                            className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg text-xs font-bold ${
                              isSelected ? "bg-[#125c43] text-white" : "bg-slate-100 text-slate-600"
                            }`}
                          >
                            {alert.rank ?? idx + 1}
                          </div>
                          <Image
                            src={productImageFor(alert.product_name || alert.sku_id)}
                            alt=""
                            aria-hidden="true"
                            width={80}
                            height={80}
                            className="h-20 w-20 shrink-0 object-contain"
                          />

                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-1.5">
                              <h3 className="min-w-0 truncate font-sans text-base font-bold text-slate-900 sm:text-lg">
                                {alert.product_name || alert.sku_id}
                              </h3>
                              <span
                                className={`rounded px-1.5 py-0.5 text-[10px] border font-bold ${riskClass(
                                  alert.priority
                                )}`}
                              >
                                {alert.priority}
                              </span>
                              <span
                                className={`rounded px-1.5 py-0.5 text-[10px] border font-semibold ${badge.bg}`}
                              >
                                {badge.icon} {badge.label}
                              </span>
                              {isAudited && (
                                <span className="rounded bg-emerald-100 px-1.5 py-0.5 text-[10px] font-bold text-emerald-800 flex items-center gap-0.5">
                                  <CheckCircle2 size={10} /> Verified ({auditedRecord?.outcome.replace("_", " ")})
                                </span>
                              )}
                              {alert.replenishment_triggered && (
                                <span className="rounded bg-blue-100 px-1.5 py-0.5 text-[10px] font-bold text-blue-800 flex items-center gap-0.5">
                                  <Truck size={10} /> DC Order Placed
                                </span>
                              )}
                            </div>

                            <p className="mt-2 line-clamp-2 text-sm leading-6 text-slate-600">{alert.reason}</p>

                            <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1.5 border-t border-slate-100 pt-2.5 text-xs text-slate-500">
                              <span>
                                SKU: <b className="font-mono font-medium tracking-wider text-slate-800">{alert.sku_id}</b>
                              </span>
                              <span>
                                Risk: <b className="text-slate-900">{inr.format(alert.estimated_revenue_at_risk)}</b>
                              </span>
                              <span>
                                {modelEvaluation?.scores_calibrated ? "Confidence (calibrated)" : "Model score"}: <b>{(alert.predicted_probability * 100).toFixed(0)}%</b>
                              </span>
                              <span>
                                System stock: <b className="text-slate-800">{alert.system_recorded_on_hand ?? alert.on_hand ?? 0} units</b>
                              </span>
                              {alert.verified_on_hand != null && <span>Verified count: <b className="text-emerald-800">{alert.verified_on_hand} units</b></span>}
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={(event) => {
                              event.stopPropagation();
                              openInvestigation(alert);
                            }}
                            aria-label={`Investigate ${alert.product_name || alert.sku_id} in a new tab`}
                            className="mt-1 inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-[#087653] px-3 py-2 text-xs font-semibold text-white shadow-sm transition-colors hover:bg-[#066447] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 focus-visible:ring-offset-2"
                          >
                            Investigate <ArrowUpRight size={14} />
                          </button>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </section>
          </div>

          <aside className="space-y-4">
            <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <div className="mb-3 flex items-center gap-2 text-sm font-bold text-slate-800"><TrendingUp size={17} className="text-emerald-700" /> Business Valuation Reports</div>
              <button type="button" onClick={() => setActiveTab("reports")} className="w-full rounded-xl border border-emerald-200 bg-emerald-50/70 p-4 text-left transition-colors hover:bg-emerald-50">
                <span className="text-xs font-semibold uppercase tracking-wide text-emerald-800">Projected annual recovery</span>
                <span className="mt-1 block text-2xl font-bold tracking-tight text-[#125c43]">{impact?.estimated_annualized_potential_recovery != null ? inr.format(impact.estimated_annualized_potential_recovery) : "—"}</span>
                <span className="mt-1 block text-xs text-emerald-800">Open the valuation report for the arithmetic</span>
              </button>
            </section>

            <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <div className="mb-3 flex items-center gap-2 text-sm font-bold text-slate-800"><PackageCheck size={17} className="text-emerald-700" /> Store performance</div>
              <div className="rounded-xl border border-slate-100 bg-slate-50 px-3.5 py-3 text-sm font-semibold text-slate-800">{store || "Select a store"}<span className="ml-2 text-xs font-normal text-slate-500">Current store</span></div>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <div className="rounded-xl border border-slate-100 p-3"><span className="text-xs text-slate-500">Total checks</span><strong className="mt-1 block text-lg text-slate-900">{dailyQueueCount}</strong></div>
                <div className="rounded-xl border border-slate-100 p-3"><span className="text-xs text-slate-500">Completed</span><strong className="mt-1 block text-lg text-emerald-700">{completeCount}</strong></div>
                <div className="rounded-xl border border-slate-100 p-3"><span className="text-xs text-slate-500">Remaining</span><strong className="mt-1 block text-lg text-slate-900">{remainingChecks}</strong></div>
                <div className="rounded-xl border border-amber-100 bg-amber-50/50 p-3"><span className="text-xs text-amber-800">At risk</span><strong className="mt-1 block text-lg text-slate-900">{inr.format(moneyAtRisk)}</strong></div>
              </div>
              <div className="mt-3 rounded-xl border border-slate-100 p-3">
                <div className="flex items-center justify-between text-xs text-slate-500"><span>Today&apos;s progress</span><span>{dailyQueueCount ? Math.round((completeCount / dailyQueueCount) * 100) : 0}%</span></div>
                <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-emerald-500" style={{ width: `${dailyQueueCount ? Math.min(100, (completeCount / dailyQueueCount) * 100) : 0}%` }} /></div>
              </div>
            </section>

            <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <h3 className="mb-3 text-sm font-bold text-slate-800">Quick actions</h3>
              <div className="grid grid-cols-2 gap-2">
                <button type="button" onClick={() => setActiveTab("reports")} className="rounded-xl border border-slate-200 px-3 py-3 text-xs font-semibold text-[#125c43] transition-colors hover:bg-emerald-50"><TrendingUp size={17} className="mx-auto mb-1" />View reports</button>
                <button type="button" onClick={() => void refreshAll()} disabled={busy} className="rounded-xl border border-slate-200 px-3 py-3 text-xs font-semibold text-[#125c43] transition-colors hover:bg-emerald-50 disabled:opacity-50"><RefreshCw size={17} className={`mx-auto mb-1 ${busy ? "animate-spin" : ""}`} />Sync data</button>
              </div>
            </section>
          </aside>
          </div>

          <section aria-labelledby="queue-risk-chart-title" className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
            <div className="mb-4 flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <h2 id="queue-risk-chart-title" className="flex items-center gap-2 text-lg font-bold text-slate-900">
                  <IndianRupee size={18} className="text-amber-600" /> Estimated sales at risk
                </h2>
                <p className="mt-1 text-sm text-slate-500">{store || "Selected store"} · {date ? niceDate(date) : "Selected date"} · current daily check list</p>
                <p className="mt-1 text-xs text-slate-400">Risk estimate only; this is not confirmed financial loss.</p>
              </div>
              <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-2.5">
                <span className="block text-[11px] font-semibold uppercase tracking-wide text-amber-800">Queue total</span>
                <strong className="mt-0.5 block text-xl font-extrabold text-slate-900">{inr.format(moneyAtRisk)}</strong>
              </div>
            </div>

            <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
              <div role="group" aria-label="Risk chart view" className="inline-flex rounded-xl border border-slate-200 bg-slate-50 p-1">
                <button
                  type="button"
                  aria-pressed={riskChartView === "priority"}
                  onClick={() => setRiskChartView("priority")}
                  className={`min-h-10 rounded-lg px-3 py-2 text-sm font-semibold transition-colors ${riskChartView === "priority" ? "bg-[#125c43] text-white shadow-sm" : "text-slate-600 hover:bg-white hover:text-slate-900"}`}
                >
                  Risk by Priority
                </button>
                <button
                  type="button"
                  aria-pressed={riskChartView === "sku"}
                  onClick={() => setRiskChartView("sku")}
                  className={`min-h-10 rounded-lg px-3 py-2 text-sm font-semibold transition-colors ${riskChartView === "sku" ? "bg-[#125c43] text-white shadow-sm" : "text-slate-600 hover:bg-white hover:text-slate-900"}`}
                >
                  Top 20 SKUs by Risk
                </button>
              </div>
              <div aria-label="Priority colors" className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-600">
                <span className="font-semibold text-slate-500">Priority:</span>
                {[...riskPriorityOrder, ...(queueRiskByPriority.some((item) => item.priority === "Other") ? ["Other"] : [])].map((priority) => (
                  <span key={priority} className="inline-flex items-center gap-1.5">
                    <i aria-hidden="true" className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: queueRiskColors[priority] }} />
                    {priority}
                  </span>
                ))}
              </div>
            </div>

            {!uniqueQueueItems.length ? (
              <div className="grid h-48 place-items-center rounded-xl border border-dashed border-slate-200 bg-slate-50 px-4 text-center text-sm text-slate-500">
                No risk data is available for this store and business date.
              </div>
            ) : riskChartView === "priority" ? (
              <div className="h-[280px] w-full" key="priority-chart">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={queueRiskByPriority} margin={{ top: 12, right: 18, left: 12, bottom: 8 }}>
                    <CartesianGrid stroke="#e2e8f0" strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="priority" tick={{ fontSize: 12, fill: "#334155" }} tickLine={false} axisLine={false} />
                    <YAxis tickFormatter={(value) => compactInr.format(Number(value))} width={76} tick={{ fontSize: 11, fill: "#475569" }} tickLine={false} axisLine={false} />
                    <Tooltip
                      cursor={{ fill: "#f8fafc" }}
                      content={({ active, payload }) => {
                        const point = payload?.[0]?.payload as (typeof queueRiskByPriority)[number] | undefined;
                        if (!active || !point) return null;
                        return (
                          <div className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-xs shadow-lg">
                            <p className="font-bold text-slate-900">{point.priority} priority</p>
                            <p className="mt-1 text-slate-600">{point.skuCount} {point.skuCount === 1 ? "SKU" : "SKUs"}</p>
                            <p className="mt-1 font-bold text-[#125c43]">{inr.format(point.estimatedRisk)}</p>
                          </div>
                        );
                      }}
                    />
                    <Bar dataKey="estimatedRisk" name="Estimated sales at risk" radius={[8, 8, 0, 0]} maxBarSize={88} isAnimationActive animationDuration={400}>
                      {queueRiskByPriority.map((entry) => <Cell key={entry.priority} fill={entry.color} />)}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="w-full overflow-x-auto">
                <div className="min-w-[1320px] h-[380px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={topRiskSkus} margin={{ top: 16, right: 22, left: 8, bottom: 8 }}>
                      <CartesianGrid stroke="#e2e8f0" strokeDasharray="3 3" vertical={false} />
                      <XAxis type="category" dataKey="skuId" interval={0} height={38} tick={{ fontSize: 11, fill: "#334155" }} tickLine={false} axisLine={false} />
                      <YAxis type="number" tickFormatter={(value) => compactInr.format(Number(value))} width={78} tick={{ fontSize: 11, fill: "#475569" }} tickLine={false} axisLine={false} />
                      <Tooltip
                        cursor={{ fill: "#f8fafc" }}
                        content={({ active, payload }) => {
                          const point = payload?.[0]?.payload as (typeof topRiskSkus)[number] | undefined;
                          if (!active || !point) return null;
                          return (
                            <div className="max-w-sm rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-xs shadow-lg">
                              <p className="font-bold text-slate-900">{point.productName}</p>
                              <p className="mt-1 text-slate-600">SKU: <b className="font-mono text-slate-800">{point.skuId}</b></p>
                              <p className="mt-1 text-slate-600">Priority: <b style={{ color: point.color }}>{point.priority}</b></p>
                              <p className="mt-1 font-bold text-[#125c43]">Estimated risk: {inr.format(point.estimatedRisk)}</p>
                            </div>
                          );
                        }}
                      />
                      <Bar dataKey="estimatedRisk" name="Estimated sales at risk" radius={[8, 8, 0, 0]} maxBarSize={56} isAnimationActive animationDuration={400}>
                        {topRiskSkus.map((entry) => <Cell key={entry.skuId} fill={entry.color} />)}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}
            <p className="mt-3 text-xs text-slate-400">
              Each SKU is counted once; highest-risk row is retained for duplicate SKU entries.
              {duplicateSkuRows > 0 && ` ${duplicateSkuRows} duplicate ${duplicateSkuRows === 1 ? "row was" : "rows were"} excluded from the total.`}
            </p>
          </section>

          {/* Selected-item verification actions; product history lives in Investigations. */}
          <div className="space-y-4">
            <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
              {!selected ? (
                <div className="grid min-h-[480px] place-items-center text-center text-xs text-slate-500">
                  <div>
                    <PackageSearch size={36} className="mx-auto text-slate-300 mb-2" />
                    <b className="text-sm text-slate-800">Select a Product from the Left Queue</b>
                    <p className="mt-1">Open an item investigation for its sales and stock history, or select a queue item here to record a physical check.</p>
                  </div>
                </div>
              ) : (
                <>
                  {/* TELEMETRY HEADER */}
                  <div className="mb-4 flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-[#125c43]">
                          Product Verification & Root-Cause Summary
                        </span>
                        <span className="rounded bg-slate-100 px-2 py-1 font-mono text-[11px] font-medium tracking-wider text-slate-700">
                          {selected.sku_id}
                        </span>
                      </div>
                      <h2 className="mt-0.5 font-sans text-xl font-bold text-slate-900 sm:text-2xl">
                        {selected.product_name || selected.sku_id}
                      </h2>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <span className={`rounded-lg px-2.5 py-1 text-xs border font-bold ${riskClass(selected.priority)}`}>
                        {selected.priority} Priority
                      </span>
                      <span
                        className={`rounded-lg px-2.5 py-1 text-xs border font-bold ${
                          classificationBadge(selected.classification).bg
                        }`}
                      >
                        {classificationBadge(selected.classification).icon}{" "}
                        {classificationBadge(selected.classification).label}
                      </span>
                    </div>
                  </div>

                  {/* ANOMALY DIAGNOSIS CARD */}
                  <div className="mb-4 space-y-2 rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm leading-6 text-slate-700">
                    <div className="flex items-center gap-2 text-base font-bold text-slate-900">
                      <Sparkles size={14} className="text-[#125c43]" />
                      Possible cause (hypothesis):
                    </div>
                    <p>{classificationBadge(selected.classification).desc}</p>
                    <div className="flex flex-wrap items-center gap-x-5 gap-y-1 pt-1 text-xs font-medium text-slate-500 sm:text-sm">
                      <span>
                        System-recorded stock: <b className="text-slate-800">{selected.system_recorded_on_hand ?? selected.on_hand ?? 0} units</b>
                      </span>
                      <span>
                        {modelEvaluation?.scores_calibrated ? "Confidence (calibrated)" : "Model score"}: <b>{(selected.predicted_probability * 100).toFixed(0)}%</b>
                      </span>
                      {selected.verified_on_hand != null && <span>Physically verified count: <b className="text-emerald-800">{selected.verified_on_hand} units</b></span>}
                      <span>
                        Revenue at Risk: <b className="text-slate-800">{inr.format(selected.estimated_revenue_at_risk)}</b>
                      </span>
                    </div>
                  </div>

                  {/* CRITICAL LEAK WORKFLOW LOGIC: ACTION EXECUTION */}
                  <div className="rounded-xl border border-slate-200 bg-white p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                        <PackageCheck size={14} className="text-[#125c43]" />
                        Execute Physical Audit Finding
                      </div>
                      {isSelectedCompleted && (
                        <span className="rounded bg-emerald-100 px-2 py-0.5 text-xs font-bold text-emerald-800">
                          Audit Logged: {selectedAudit?.outcome}
                        </span>
                      )}
                    </div>

                    <p className="mb-4 text-sm leading-6 text-slate-600">
                      Verify physical shelf facings and backroom overflow. Selecting <b>Stock Missing</b> records a verified count
                      of zero and dispatches a replenishment request; the original system-recorded inventory snapshot remains available for audit.
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      <Button
                        variant="secondary"
                        size="sm"
                        disabled={busy || !auditWritesEnabled}
                        onClick={() => handleAuditOutcome("found_elsewhere")}
                        className="h-10 text-xs font-semibold border-amber-300 text-amber-900 hover:bg-amber-50"
                      >
                        <MapPin size={13} className="mr-1.5 text-amber-600" />
                        Found Elsewhere
                      </Button>

                      <Button
                        variant="danger"
                        size="sm"
                        disabled={busy || !auditWritesEnabled}
                        onClick={() => handleAuditOutcome("stock_missing")}
                        className="h-10 text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white shadow-xs"
                      >
                        <ShieldAlert size={14} className="mr-1.5" />
                        Stock Missing &amp; Replenish
                      </Button>

                      <Button
                        variant="primary"
                        size="sm"
                        disabled={busy || !auditWritesEnabled}
                        onClick={() => handleAuditOutcome("found_on_shelf")}
                        className="h-10 text-xs font-bold bg-[#125c43] hover:bg-[#0f4e39] text-white shadow-xs"
                      >
                        <CheckCircle2 size={14} className="mr-1.5" />
                        {isSelectedCompleted ? "Checked on Shelf ✓" : "Confirm on Shelf"}
                      </Button>
                    </div>

                    {!auditWritesEnabled && (
                      <p className="mt-2.5 text-[11px] text-slate-400 italic">
                        Demo deployment operates in view-only mode; audit writes are locked.
                      </p>
                    )}
                  </div>
                </>
              )}
            </section>
          </div>
        </div>

        </>}

        {/* WORKSPACE FOOTER */}
        <footer className="mt-8 flex flex-wrap items-center justify-between gap-3 border-t border-slate-200/80 pt-4 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-600">PhantomGuard Enterprise SaaS</span>
            <span>•</span>
            <span>20-Item Daily Store Manager Workflow</span>
          </div>
          <div className="flex items-center gap-1.5 text-[11px]">
            <CircleHelp size={13} />
            Daily audit budget enforced strictly at 20 items per store-day to respect floor operational bandwidth.
          </div>
        </footer>
      </div>
        </div>
      </div>
    </main>
  );
}
