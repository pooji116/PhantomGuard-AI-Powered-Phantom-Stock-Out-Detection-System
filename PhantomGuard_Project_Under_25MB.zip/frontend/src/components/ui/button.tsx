import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../../lib/utils";
const buttonStyles = cva("inline-flex items-center justify-center gap-2 rounded-xl text-sm font-semibold transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-forest disabled:pointer-events-none disabled:opacity-50", {
  variants: {
    variant: { primary: "bg-forest text-white hover:bg-[#0d4b36]", secondary: "border border-line bg-white text-ink hover:bg-paper", ghost: "text-ink hover:bg-mint", danger: "bg-rose-50 text-rose-700 hover:bg-rose-100" },
    size: { sm: "h-9 px-3", md: "h-11 px-4", lg: "h-12 px-5" },
  }, defaultVariants: { variant: "primary", size: "md" },
});
export type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof buttonStyles>;
export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(({ className, variant, size, ...props }, ref) =>
  <button ref={ref} className={cn(buttonStyles({ variant, size }), className)} {...props} />
);
Button.displayName = "Button";
