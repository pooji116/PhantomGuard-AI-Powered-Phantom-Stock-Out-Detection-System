export type AlertItem = {
  date: string;
  store_id: string;
  sku_id: string;
  product_name: string;
  rank: number | null;
  priority: string;
  priority_score: number;
  predicted_probability: number;
  confidence_score: number;
  composite_rank_weight?: number;
  classification: string;
  reason: string;
  estimated_revenue_at_risk: number;
  sales: number | null;
  on_hand: number | null;
  system_recorded_on_hand?: number | null;
  verified_on_hand?: number | null;
  verified_outcome?: string | null;
  replenishment_triggered?: boolean;
};

export type HistoryPoint = {
  date: string;
  sales?: number | null;
  on_hand?: number | null;
  system_recorded_on_hand?: number | null;
  verified_on_hand?: number | null;
  verified_outcome?: string | null;
  expected_demand?: number | null;
  promo_flag?: number | null;
};

export type AuditItem = {
  id: number;
  store_id: string;
  sku_id: string;
  audit_date: string;
  outcome: string;
  notes: string;
  created_at: string;
  inventory_adjusted_to?: number | null;
  replenishment_order_id?: string | null;
  replenishment_status?: string | null;
};

export type StoreResponse = {
  stores: string[];
  latest_date: string | null;
  latest_by_store: Record<string, string>;
};

export type ImpactSummary = {
  estimated_annualized_potential_recovery: number | null;
  estimated_period_potential_recovery: number | null;
  estimated_period_revenue_at_risk: number | null;
  observed_period_days: number;
  recoverable_fraction: number;
  actually_recovered_revenue: number | null;
  synthetic_demo: boolean;
};

export type ApiHealth = {
  status: string;
  version: string;
  data_ready: boolean;
  audit_writes_enabled: boolean;
  max_alerts_per_store_day: number;
};

export type NotificationPayload = {
  title: string;
  body: string;
  priority: string;
  channel: string;
  action_url: string;
  timestamp: string;
};

export type MorningDispatchResponse = {
  status: string;
  cron_schedule: string;
  scheduled_time_local: string;
  store_id: string;
  item_count: number;
  total_sales_at_risk: number;
  formatted_sales_at_risk: string;
  notification_payload: NotificationPayload;
};

const API_BASE = process.env.NEXT_PUBLIC_API_BASE ?? "/api/v1";

async function get<T>(path: string): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    cache: "no-store",
    headers: { "X-Tenant-ID": "demo" },
  });
  if (!response.ok) throw new Error(`PhantomGuard API returned ${response.status}`);
  return response.json() as Promise<T>;
}

export const getStores = () => get<StoreResponse>("/stores");
export const getAlerts = (store: string, date?: string) =>
  get<AlertItem[]>(`/alerts?store_id=${encodeURIComponent(store)}${date ? `&date=${date}` : ""}`);
export const getHistory = (store: string, sku: string, date: string) =>
  get<{ points: HistoryPoint[] }>(
    `/products/${encodeURIComponent(store)}/${encodeURIComponent(sku)}/history?end_date=${date}&days=56`
  );
export const getAudits = (store: string, date: string) =>
  get<AuditItem[]>(`/audits?store_id=${encodeURIComponent(store)}&date=${date}`);
export const getMetrics = () => get<Record<string, unknown>>("/metrics");
export const getImpact = () => get<ImpactSummary>("/impact");
export const getHealth = () => get<ApiHealth>("/health");

export const getMorningDispatch = (store: string, date?: string) =>
  get<MorningDispatchResponse>(
    `/notifications/morning-dispatch?store_id=${encodeURIComponent(store)}${date ? `&date=${date}` : ""}`
  );

export async function triggerMorningCron(store: string, date?: string) {
  const response = await fetch(
    `${API_BASE}/cron/morning-dispatch?store_id=${encodeURIComponent(store)}${date ? `&date=${date}` : ""}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Tenant-ID": "demo" },
    }
  );
  if (!response.ok) throw new Error(`Morning cron trigger failed (${response.status})`);
  return response.json() as Promise<MorningDispatchResponse>;
}

export async function saveAudit(body: Omit<AuditItem, "id" | "created_at">) {
  const response = await fetch(`${API_BASE}/audits`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Tenant-ID": "demo" },
    body: JSON.stringify(body),
  });
  if (!response.ok) throw new Error(`Could not save check (${response.status})`);
  return response.json() as Promise<AuditItem>;
}
