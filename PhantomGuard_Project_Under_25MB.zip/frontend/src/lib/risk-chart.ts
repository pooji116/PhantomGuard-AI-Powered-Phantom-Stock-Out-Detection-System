export interface QueueRiskItem {
  sku_id: string;
  product_name: string;
  priority: string;
  estimated_revenue_at_risk: number;
}

export const riskPriorityOrder = ["Critical", "High", "Medium", "Low"] as const;

export const queueRiskColors: Record<string, string> = {
  Critical: "#b4233a",
  High: "#9a5b00",
  Medium: "#075985",
  Low: "#166534",
  Other: "#475569",
};

export function riskPriority(priority: string) {
  return riskPriorityOrder.find((value) => priority.toLowerCase().includes(value.toLowerCase())) ?? "Other";
}

export function estimatedRisk(item: QueueRiskItem) {
  return Math.max(0, Number(item.estimated_revenue_at_risk) || 0);
}

export function buildQueueRiskChartData<T extends QueueRiskItem>(alerts: readonly T[]) {
  const bySku = new Map<string, T>();
  alerts.forEach((alert, index) => {
    const key = alert.sku_id.trim().toUpperCase() || `missing-sku-${index}`;
    const current = bySku.get(key);
    if (!current || estimatedRisk(alert) > estimatedRisk(current)) bySku.set(key, alert);
  });
  const uniqueItems = [...bySku.values()];

  const totals: Record<string, { skuCount: number; estimatedRisk: number }> = {};
  for (const priority of riskPriorityOrder) totals[priority] = { skuCount: 0, estimatedRisk: 0 };
  for (const item of uniqueItems) {
    const priority = riskPriority(item.priority);
    const group = totals[priority] ??= { skuCount: 0, estimatedRisk: 0 };
    group.skuCount += 1;
    group.estimatedRisk += estimatedRisk(item);
  }

  const priorities = [...riskPriorityOrder, ...(totals.Other?.skuCount ? ["Other"] : [])];
  const priorityData = priorities.map((priority) => ({
    priority,
    skuCount: totals[priority].skuCount,
    estimatedRisk: totals[priority].estimatedRisk,
    color: queueRiskColors[priority],
  }));

  const topSkus = uniqueItems
    .map((item) => {
      const productName = item.product_name?.trim() || item.sku_id;
      const shortName = productName.length > 25 ? `${productName.slice(0, 24)}…` : productName;
      const priority = riskPriority(item.priority);
      return {
        productName,
        skuId: item.sku_id,
        priority,
        estimatedRisk: estimatedRisk(item),
        chartLabel: `${shortName} · ${item.sku_id}`,
        color: queueRiskColors[priority],
      };
    })
    .sort((a, b) => b.estimatedRisk - a.estimatedRisk || a.skuId.localeCompare(b.skuId))
    .slice(0, 20);

  return {
    uniqueItems,
    duplicateSkuRows: alerts.length - uniqueItems.length,
    totalRisk: uniqueItems.reduce((total, item) => total + estimatedRisk(item), 0),
    priorityData,
    topSkus,
  };
}
