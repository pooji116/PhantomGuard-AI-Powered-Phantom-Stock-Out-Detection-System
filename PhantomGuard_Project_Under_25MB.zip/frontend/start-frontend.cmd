@echo off
setlocal
set "ROOT=%~dp0.."
set "RUNTIME=%~dp0.tools\node-v24.21.0-win-x64"
set "PATH=%RUNTIME%;%PATH%"

echo ===================================================
echo [PhantomGuard] Store Operations Workspace Launcher
echo ===================================================

:: Check if Python API backend is already running on port 8000
netstat -ano | findstr ":8000 " >nul 2>&1
if %errorlevel% neq 0 (
    echo [*] Starting PhantomGuard FastAPI backend on http://0.0.0.0:8000 ...
    start "PhantomGuard API Backend (Port 8000)" /min cmd /c "cd /d "%ROOT%" && python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000"
    timeout /t 2 /nobreak >nul
) else (
    echo [*] Backend API is already running on port 8000.
)

if not exist "%RUNTIME%\node.exe" (
  echo Local Node.js runtime was not found at "%RUNTIME%".
  exit /b 1
)
if not exist "%RUNTIME%\npm.cmd" (
  echo Local npm launcher was not found at "%RUNTIME%\npm.cmd".
  exit /b 1
)
if not exist "%~dp0node_modules\next\package.json" (
  echo [*] Installing dependencies...
  call "%RUNTIME%\npm.cmd" install
  if errorlevel 1 exit /b %errorlevel%
)

echo [*] Starting Next.js frontend on http://localhost:3000 ...
echo [*] Open your browser at http://localhost:3000
call "%RUNTIME%\npm.cmd" run dev
exit /b %errorlevel%
