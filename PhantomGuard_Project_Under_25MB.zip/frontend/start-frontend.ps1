$ErrorActionPreference = "Stop"

$root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$runtime = Join-Path $PSScriptRoot ".tools\node-v24.21.0-win-x64"
$node = Join-Path $runtime "node.exe"
$npm = Join-Path $runtime "npm.cmd"

Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "[PhantomGuard] Store Operations Workspace Launcher" -ForegroundColor Cyan
Write-Host "===================================================" -ForegroundColor Cyan

# Check if backend on port 8000 is running
$backendRunning = $false
try {
    $tcp = Test-NetConnection -ComputerName "127.0.0.1" -Port 8000 -WarningAction SilentlyContinue
    $backendRunning = $tcp.TcpTestSucceeded
} catch {
    $backendRunning = $false
}

if (-not $backendRunning) {
    Write-Host "[*] Starting FastAPI Backend on http://0.0.0.0:8000..." -ForegroundColor Yellow
    Start-Process -FilePath "python" -ArgumentList "-m uvicorn backend.main:app --host 0.0.0.0 --port 8000" -WorkingDirectory $root -WindowStyle Minimized
    Start-Sleep -Seconds 2
} else {
    Write-Host "[*] FastAPI Backend is already running on port 8000." -ForegroundColor Green
}

if (-not (Test-Path -LiteralPath $node) -or -not (Test-Path -LiteralPath $npm)) {
    throw "The local Node.js runtime is missing. Install Node.js LTS, or restore frontend/.tools/node-v24.21.0-win-x64."
}

$env:Path = "$runtime;$env:Path"
if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot "node_modules\next\package.json"))) {
    Push-Location $PSScriptRoot
    try {
        & $npm install
        if ($LASTEXITCODE -ne 0) { throw "npm install failed with exit code $LASTEXITCODE" }
    }
    finally { Pop-Location }
}

Write-Host "[*] Starting Next.js frontend on http://localhost:3000..." -ForegroundColor Green
Push-Location $PSScriptRoot
try {
    & $npm run dev
    if ($LASTEXITCODE -ne 0) { throw "Next.js exited with code $LASTEXITCODE" }
}
finally { Pop-Location }
