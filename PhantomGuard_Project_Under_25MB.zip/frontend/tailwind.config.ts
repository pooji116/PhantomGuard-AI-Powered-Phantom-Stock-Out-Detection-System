import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: { ink: "#17251f", forest: "#125c43", mint: "#e8f5ed", paper: "#f6f8f5", line: "#e6ebe7" },
      boxShadow: { soft: "0 12px 36px rgba(25,52,39,.08)" },
    },
  },
  plugins: [],
};

export default config;
