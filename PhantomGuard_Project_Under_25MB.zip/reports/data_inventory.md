# Data inventory

Audited on 2026-10-13. The original `C:/Users/Poojitha/Downloads/sales_data.csv` was copied without modification to `data/raw/sales_data.csv`; the source remains in Downloads.

## Supplied combined panel

| Source header | PhantomGuard field | Use |
|---|---|---|
| `Date` | `date` | Daily observation date |
| `Store ID` | `store_id` | Store key |
| `Product ID` | `sku_id` | Product key |
| `Units Sold` | `sales` | Daily observed unit sales |
| `Inventory Level` | `on_hand` | Recorded stock snapshot |
| `Price` | `unit_price` | Observed unit selling price for revenue estimates |
| `Promotion` | `promo_flag` | Daily promotion context |

The source also contains `Category`, `Region`, `Units Ordered`, `Discount`, `Weather Condition`, `Competitor Pricing`, `Seasonality`, `Epidemic`, and `Demand`. They are retained in the prepared panel when read, but are not used as model features. In particular, `Demand` is not used because its meaning/provenance is not documented and it could act as a target proxy. `Units Ordered` is not treated as verified shelf replenishment.

## Validation results

- 76,000 rows; 5 stores; 20 products; 100 store-product series.
- Dates: 2022-01-01 through 2024-01-30 (760 distinct, consecutive dates per series).
- No missing source values, invalid dates, or duplicate `date + store + product` keys.
- No negative sales or inventory. Sales range 0–426; inventory range 0–2,267; price range ₹4.74–₹228.03.
- 406 rows have zero sales; all 406 also have zero on-hand. There are zero rows with zero sales and positive inventory and zero runs of 3+ consecutive zero-sales days with positive stock.
- The daily store-product key is complete for all 100 series. No calendar gaps were filled or inferred.
- No hidden incident labels, shelf counts, backroom counts, or official evaluator were supplied. The `data/raw/` directory now contains only this source panel (plus `.gitkeep`); previous synthetic files remain separated under `data/sample/`.

## Detection support and limits

The core PhantomGuard signal—recorded positive inventory combined with sustained zero sales despite prior demand—is absent in this panel. The pipeline runs and correctly emits no eligible alerts under the configured positive-stock/zero-sales rule. This is not evidence that stores have no phantom stock; it means this dataset cannot substantiate or evaluate such incidents. `Region` is not treated as city tier, and categories/weather/seasonality may be useful as future context but do not substitute for anomaly labels. There is no cost/margin field, so only gross revenue-at-risk scenarios can be shown, not profit.

## Reproducible synthetic fixtures

The synthetic generator writes only to `data/sample/`. The explicit pipeline `--demo` flag uses a generated configuration pointing to that folder. Synthetic labels remain available for tests/demo model fitting but are blocked from the feature allowlist and never mixed into the real raw panel.
