# Feature dictionary

All historical aggregations are shifted so they use only information available
before the current observation, except streak features which follow `scoring_time`.

| Feature | Group | Description |
|---|---|---|
| `sales_lag_1` | demand | Sales on the previous observed day for the SKU-store. |
| `sales_lag_7` | demand | Sales 7 observations earlier (panel lag, not calendar fill). |
| `sales_lag_14` | demand | Sales 14 observations earlier. |
| `sales_mean_7` | demand | Mean of prior 7 sales observations (shifted). |
| `sales_median_7` | demand | Median of prior 7 sales observations (shifted). |
| `sales_mean_28` | demand | Mean of prior 28 sales observations (shifted). |
| `sales_median_28` | demand | Median of prior 28 sales observations (shifted). |
| `sales_std_28` | demand | Std of prior 28 sales observations (shifted). |
| `positive_sales_days_28` | demand | Count of prior 28 days with sales > 0. |
| `sales_velocity` | demand | Prior 28-day mean sales (historical velocity). |
| `demand_trend` | demand | Recent 7-day mean minus prior 28-day mean. |
| `weekday_baseline` | demand | Historical mean sales for the same weekday (expanding, shifted). |
| `on_hand` | inventory | System-recorded on-hand quantity at scoring time. |
| `positive_stock` | inventory | 1 if recorded on-hand > 0. |
| `zero_sales_streak` | inventory | Consecutive zero-sales observations through scoring-time sales. |
| `positive_stock_zero_streak` | inventory | Zero-sales streak while recorded inventory stayed positive. |
| `demand_deviation` | inventory | Today or lagged sales minus expected demand, depending on scoring_time. |
| `recent_sales_decline` | inventory | Prior 7-day mean relative to prior 28-day mean, inverted if declining. |
| `stock_to_demand_ratio` | inventory | on_hand / expected demand; large when stock sits without movement. |
| `zero_sales_frequency_28` | inventory | Fraction of prior 28 days with zero sales. |
| `demand_variability` | inventory | Coefficient of variation of prior 28-day sales. |
| `expected_demand` | inventory | Leakage-safe expected daily units from history. |
| `insufficient_history` | inventory | 1 if fewer than min_history_days of prior observations. |
| `dow` | context | Day of week (0=Monday). |
| `is_weekend` | context | Weekend indicator. |
| `month` | context | Calendar month. |
| `promo_flag` | context | Promotion indicator if supplied. |
| `holiday_flag` | context | Holiday indicator if supplied. |
| `promo_x_expected_demand` | context | Promotion flag times expected demand. |
| `cross_store_sku_demand_lag1` | cross_store | Previous-day mean sales of the SKU across stores. |
