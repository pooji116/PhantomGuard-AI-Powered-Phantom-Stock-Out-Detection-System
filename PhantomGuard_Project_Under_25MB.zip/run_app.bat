@echo off
setlocal
set "ROOT=%~dp0"
cd /d "%ROOT%"

echo =========================================================
echo [PhantomGuard] Launching Full System (Backend + Frontend)
echo =========================================================

:: Check if Python API backend is already running on port 8000
netstat -ano | findstr ":8000 " >nul 2>&1
if %errorlevel% neq 0 (
    echo [*] Starting PhantomGuard FastAPI backend on http://0.0.0.0:8000 ...
    start "PhantomGuard API Backend (Port 8000)" /min cmd /c "cd /d "%ROOT%" && python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000"
    timeout /t 2 /nobreak >nul
) else (
    echo [*] Backend API is already running on port 8000.
)

:: Start the frontend
cd "%ROOT%frontend"
call "%ROOT%frontend\start-frontend.cmd"
