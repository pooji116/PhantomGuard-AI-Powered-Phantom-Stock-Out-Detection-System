"""Generate a reproducible hackathon-scale PhantomGuard demonstration panel.

The generated labels are synthetic evaluation ground truth. They are stored in
their own table and excluded from model feature selection.
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.config import load_config, project_root  # noqa: E402
from src.io_utils import configure_logging  # noqa: E402

LOGGER = logging.getLogger(__name__)

MARKER = (
    "SYNTHETIC DEMONSTRATION DATA\n"
    "Generated reproducibly for PhantomGuard product demonstration.\n"
    "Labels are simulated, kept in a separate table, and are not organizer ground truth.\n"
)

CATEGORIES = (
    "Staples", "Dairy", "Beverages", "Personal Care", "Home Care",
    "Snacks", "Packaged Foods", "Baby Care", "Pet Care", "Frozen Foods",
)
ANOMALY_TYPES = ("none", "phantom_stockout", "misplaced_shelf", "delisted_item")


def _put_event(mask: np.ndarray, types: np.ndarray, start: int, length: int, code: int) -> None:
    end = min(start + length, len(mask))
    mask[start:end] = True
    types[start:end] = code


def generate_demo(
    n_stores: int = 25,
    n_skus: int = 800,
    n_days: int = 548,
    seed: int = 42,
) -> dict[str, pd.DataFrame]:
    """Create daily retail data with demand patterns and hidden incident labels.

    The default is 25 stores × 800 SKUs × 548 days (18 months including the
    2024 leap day). Roughly 3% of panel rows receive a positive synthetic label.
    """
    if min(n_stores, n_skus, n_days) < 1:
        raise ValueError("stores, SKUs, and days must all be positive")
    rng = np.random.default_rng(seed)
    dates = pd.date_range("2024-01-01", periods=n_days, freq="D")
    store_ids = [f"S{i + 1:03d}" for i in range(n_stores)]
    sku_ids = [f"SKU{i + 1:04d}" for i in range(n_skus)]
    n_series = n_stores * n_skus
    n_rows = n_series * n_days

    formats = np.array(["convenience", "supermarket", "hypermarket", "express"])
    tiers = np.array(["Tier 1", "Tier 2", "Tier 3"])
    stores = pd.DataFrame({
        "store_id": store_ids,
        "store_size": rng.integers(700, 5200, n_stores, dtype=np.int32),
        "format": formats[np.arange(n_stores) % len(formats)],
        "city_tier": tiers[np.arange(n_stores) % len(tiers)],
    })
    store_multiplier = rng.uniform(0.72, 1.42, n_stores)

    # A long-tailed velocity distribution creates legitimate slow movers.
    velocity_levels = np.array([0.12, 0.22, 0.38, 0.65, 1.0, 1.6, 2.5, 4.0])
    velocity_probs = np.array([0.08, 0.11, 0.16, 0.20, 0.18, 0.14, 0.09, 0.04])
    velocity = rng.choice(velocity_levels, n_skus, p=velocity_probs).astype(np.float32)
    prices = rng.choice([19, 29, 45, 59, 79, 99, 149, 199, 299, 499], n_skus).astype(np.float32)
    category_idx = np.arange(n_skus) % len(CATEGORIES)
    product_names = np.array([f"{CATEGORIES[c]} item {i + 1:04d}" for i, c in enumerate(category_idx)])
    products = pd.DataFrame({
        "sku_id": sku_ids,
        "product_name": product_names,
        "category": [CATEGORIES[index % len(CATEGORIES)] for index in range(n_skus)],
        "unit_price": prices,
        "average_daily_demand": velocity,
    })

    # Four short promotional windows per SKU. The calendar is separately kept
    # as start/end windows and is independently joined by the pipeline.
    promo_rows: list[dict[str, str]] = []
    promo_by_sku = np.zeros((n_skus, n_days), dtype=np.uint8)
    if n_days >= 30:
        for sku_i, sku in enumerate(sku_ids):
            for quarter in range(4):
                center = int((quarter + 0.45) * n_days / 4)
                start = int(np.clip(center + rng.integers(-12, 13), 2, n_days - 10))
                length = int(rng.integers(4, 9))
                end = min(start + length - 1, n_days - 1)
                promo_by_sku[sku_i, start:end + 1] = 1
                promo_rows.append({
                    "sku_id": sku,
                    "start_date": dates[start].date().isoformat(),
                    "end_date": dates[end].date().isoformat(),
                    "promo_type": "weekly price promotion",
                })
    promotions = pd.DataFrame(promo_rows, columns=["sku_id", "start_date", "end_date", "promo_type"])

    dow_multiplier = np.array([0.88, 0.91, 0.94, 0.97, 1.04, 1.22, 1.18], dtype=np.float32)
    day_index = np.arange(n_days)
    day_of_week = dates.dayofweek.to_numpy()
    seasonal = (1.0 + 0.16 * np.sin(2 * np.pi * (dates.dayofyear.to_numpy() - 20) / 365.25)).astype(np.float32)
    holiday_dates = {
        (1, 1), (1, 14), (3, 25), (8, 15), (10, 31), (11, 1), (12, 25),
    }
    holiday = np.array([(d.month, d.day) in holiday_dates for d in dates], dtype=np.uint8)
    holiday_boost = np.where(holiday > 0, 1.18, 1.0).astype(np.float32)

    # Compact numeric arrays keep the full panel practical to generate.
    sales = np.empty(n_rows, dtype=np.int16)
    inventory = np.empty(n_rows, dtype=np.int16)
    labels = np.zeros(n_rows, dtype=np.uint8)
    anomaly_type = np.zeros(n_rows, dtype=np.uint8)
    base_demand_by_store_sku = np.empty(n_series, dtype=np.float32)
    order_every = np.empty(n_series, dtype=np.int16)
    date_template = dates.to_numpy(dtype="datetime64[ns]")

    long_panel = n_days >= 120
    for store_i in range(n_stores):
        for sku_i in range(n_skus):
            series_i = store_i * n_skus + sku_i
            offset = series_i * n_days
            avg_demand = float(velocity[sku_i] * store_multiplier[store_i])
            base_demand_by_store_sku[series_i] = avg_demand
            promo = promo_by_sku[sku_i]
            lam = avg_demand * dow_multiplier[day_of_week] * seasonal * holiday_boost
            lam *= np.where(promo > 0, 1.48, 1.0)
            demand = rng.poisson(np.maximum(lam, 0.03)).astype(np.int16)

            incident_mask = np.zeros(n_days, dtype=bool)
            incident_types = np.zeros(n_days, dtype=np.uint8)
            # Slow movers are deliberately not all labeled as anomalies.
            eligible_incident = avg_demand >= 0.52
            if eligible_incident and n_days >= 24:
                if long_panel:
                    first_len, second_len = 9, 5
                    first_start = int(rng.integers(32, max(33, n_days - 112)))
                    second_low = max(first_start + first_len + 18, int(n_days * 0.38))
                    second_high = max(second_low + 1, n_days - 62)
                    second_start = int(rng.integers(second_low, second_high)) if second_low < second_high else second_low
                    _put_event(incident_mask, incident_types, first_start, first_len, 1)
                    _put_event(incident_mask, incident_types, second_start, second_len, 2)
                    # A smaller share has a long terminal zero-sales pattern,
                    # represented as a delisting hypothesis for the stretch.
                    if rng.random() < 0.205:
                        tail = min(44, max(10, n_days // 10))
                        _put_event(incident_mask, incident_types, n_days - tail, tail, 3)
                else:
                    lengths = [min(5, max(2, n_days // 8)), min(4, max(2, n_days // 10))]
                    first = int(rng.integers(max(0, min(14, n_days - lengths[0])), max(1, n_days - lengths[0])))
                    second = min(first + lengths[0] + 2, max(0, n_days - lengths[1]))
                    _put_event(incident_mask, incident_types, first, lengths[0], 1)
                    _put_event(incident_mask, incident_types, second, lengths[1], 2)
                demand[incident_mask] = 0

            # Replenish toward a target as stock gets low. During a labeled
            # event the system record stays positive while sales stop.
            target = max(10, int(round(avg_demand * 13 + 8)))
            reorder_point = max(2, int(round(avg_demand * 3)))
            order_quantity = max(10, int(round(avg_demand * 12)))
            stock = target
            for day_i in range(n_days):
                if incident_mask[day_i]:
                    stock = max(stock, 6, target // 2)
                    inventory[offset + day_i] = stock
                    sales[offset + day_i] = 0
                    labels[offset + day_i] = 1
                    anomaly_type[offset + day_i] = incident_types[day_i]
                else:
                    if stock <= reorder_point:
                        stock += order_quantity
                    inventory[offset + day_i] = stock
                    sold = min(int(demand[day_i]), stock)
                    sales[offset + day_i] = sold
                    stock -= sold

    store_codes = np.repeat(np.arange(n_stores, dtype=np.int16), n_skus * n_days)
    sku_codes = np.tile(np.repeat(np.arange(n_skus, dtype=np.int32), n_days), n_stores)
    date_values = np.tile(date_template, n_series)
    store_cat = pd.Categorical.from_codes(store_codes, categories=store_ids)
    sku_cat = pd.Categorical.from_codes(sku_codes, categories=sku_ids)
    store_ids_for_rows = pd.Series(store_cat, name="store_id")
    sku_ids_for_rows = pd.Series(sku_cat, name="sku_id")
    dates_for_rows = pd.Series(date_values, name="date")
    promo_values = np.tile(promo_by_sku, (n_stores, 1)).reshape(-1)
    product_names_for_rows = pd.Categorical.from_codes(sku_codes, categories=product_names)

    sales_frame = pd.DataFrame({
        "date": dates_for_rows,
        "store_id": store_ids_for_rows,
        "sku_id": sku_ids_for_rows,
        "units_sold": sales,
        "unit_price": prices[sku_codes],
        "promo_flag": promo_values,
        "holiday_flag": np.tile(holiday, n_series),
        "product_name": product_names_for_rows,
    })
    inventory_frame = pd.DataFrame({
        "date": dates_for_rows,
        "store_id": store_ids_for_rows,
        "sku_id": sku_ids_for_rows,
        "on_hand": inventory,
    })
    type_categories = list(ANOMALY_TYPES)
    labels_frame = pd.DataFrame({
        "date": dates_for_rows,
        "store_id": store_ids_for_rows,
        "sku_id": sku_ids_for_rows,
        "is_phantom": labels,
        "anomaly_type": pd.Categorical.from_codes(anomaly_type, categories=type_categories),
    })

    rate = float(labels.mean())
    LOGGER.info(
        "Generated synthetic panel: %s rows, %s stores, %s SKUs, %s days, positive labels=%.3f",
        n_rows, n_stores, n_skus, n_days, rate,
    )
    return {
        "sales": sales_frame,
        "inventory": inventory_frame,
        "promotions": promotions,
        "stores": stores,
        "products": products,
        "labels": labels_frame,
    }


def write_demo(output_dir: Path, tables: dict[str, pd.DataFrame]) -> dict[str, Path]:
    """Write large tables as compressed Parquet and small fixtures as CSV."""
    output_dir.mkdir(parents=True, exist_ok=True)
    written: dict[str, Path] = {}
    large = len(tables.get("sales", ())) >= 1_000_000
    for name, frame in tables.items():
        suffix = ".parquet" if large and name in {"sales", "inventory", "labels"} else ".csv"
        path = output_dir / f"{name}{suffix}"
        if suffix == ".parquet":
            frame.to_parquet(path, index=False, compression="zstd")
        else:
            frame.to_csv(path, index=False)
        LOGGER.info("Wrote %s", path)
        written[name] = path
    (output_dir / "SYNTHETIC.txt").write_text(MARKER, encoding="utf-8")
    return written


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate PhantomGuard synthetic hackathon-scale CSV/Parquet data.")
    parser.add_argument("--stores", type=int, default=25)
    parser.add_argument("--skus", type=int, default=800)
    parser.add_argument("--days", type=int, default=548)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", type=Path, default=None)
    args = parser.parse_args()
    configure_logging()
    cfg = load_config()
    seed = int(cfg.get("project", {}).get("random_seed", args.seed)) if args.seed == 42 else args.seed
    tables = generate_demo(args.stores, args.skus, args.days, seed)
    output = args.output or (project_root() / cfg["paths"]["sample_dir"])
    write_demo(output, tables)
    rows = len(tables["sales"])
    positives = int(tables["labels"]["is_phantom"].sum())
    del tables
    print(f"Synthetic demonstration data written to {output} ({rows:,} rows; {positives:,} positive labels).")
    print("These labels and metrics are simulated and are not official competition results.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
