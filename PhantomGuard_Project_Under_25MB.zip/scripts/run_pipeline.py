"""Orchestrate PhantomGuard stages from the project root."""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.baseline import run_baseline  # noqa: E402
from src.config import load_config  # noqa: E402
from src.evaluate import run_evaluate  # noqa: E402
from src.features import run_features  # noqa: E402
from src.io_utils import configure_logging  # noqa: E402
from src.model import run_train  # noqa: E402
from src.prepare_data import run_prepare  # noqa: E402
from src.rank_alerts import run_rank  # noqa: E402

LOGGER = logging.getLogger("pipeline")

STAGES = ("prepare", "features", "baseline", "train", "rank", "evaluate", "all")


def run_stage(stage: str, config_path: str | None) -> None:
    if stage == "prepare":
        run_prepare(config_path)
    elif stage == "features":
        run_features(config_path)
    elif stage == "baseline":
        run_baseline(config_path)
    elif stage == "train":
        run_train(config_path)
    elif stage == "rank":
        run_rank(config_path)
    elif stage == "evaluate":
        run_evaluate(config_path)
    elif stage == "all":
        run_prepare(config_path)
        run_features(config_path)
        run_baseline(config_path)
        trained = False
        try:
            run_train(config_path)
            trained = True
        except Exception as exc:
            LOGGER.warning("Supervised training unavailable (%s). Continuing with baseline ranking.", exc)
            # Do not let predictions from an earlier dataset masquerade as
            # current results after training is unavailable (for example,
            # when the supplied panel has no ground-truth labels).
            from src.config import project_root

            cfg = load_config(config_path)
            stale = project_root() / cfg["paths"]["predictions_dir"] / cfg["files"]["model_predictions"]
            for candidate in (stale, stale.with_suffix(".csv")):
                if candidate.exists():
                    candidate.unlink()
            artifact_path = project_root() / cfg["files"]["model_artifact"]
            if artifact_path.exists():
                artifact_path.unlink()
        run_rank(config_path, use_baseline=not trained)
        try:
            run_evaluate(config_path)
        except Exception as exc:
            LOGGER.error("Evaluation skipped: %s", exc)
    else:
        raise ValueError(f"Unknown stage {stage}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Run PhantomGuard pipeline stages.")
    parser.add_argument("--stage", choices=STAGES, default="all")
    parser.add_argument("--config", default=None, help="Optional path to config.yaml")
    parser.add_argument("--demo", action="store_true", help="Generate synthetic data before running.")
    args = parser.parse_args()
    configure_logging()
    cfg = load_config(args.config)
    LOGGER.info("PhantomGuard pipeline starting (synthetic_demo=%s)", cfg.get("project", {}).get("synthetic_demo"))
    config_for_run = args.config
    if args.demo:
        from scripts.generate_demo_data import generate_demo, write_demo
        from src.config import project_root

        tables = generate_demo(seed=int(cfg.get("project", {}).get("random_seed", 42)))
        generated_files = write_demo(project_root() / cfg["paths"]["sample_dir"], tables)
        demo_cfg = dict(cfg)
        demo_cfg["project"] = {**cfg.get("project", {}), "synthetic_demo": True}
        demo_cfg["paths"] = {**cfg.get("paths", {}), "raw_dir": cfg["paths"]["sample_dir"]}
        demo_cfg["files"] = {
            **cfg.get("files", {}),
            "sales": generated_files["sales"].name,
            "inventory": generated_files["inventory"].name,
            "labels": generated_files["labels"].name,
            "promotions": generated_files["promotions"].name,
            "stores": generated_files["stores"].name,
        }
        demo_cfg["columns"] = {
            **cfg.get("columns", {}),
            "date": "date", "store_id": "store_id", "sku_id": "sku_id",
            "sales": "units_sold", "on_hand": "on_hand", "unit_price": "unit_price",
            "promo_flag": "promo_flag", "store_size": "store_size", "store_format": "format",
            "city_tier": "city_tier", "holiday_flag": "holiday_flag", "margin": "margin",
        }
        demo_cfg_path = project_root() / cfg["paths"]["interim_dir"] / "synthetic_demo_config.yaml"
        demo_cfg_path.parent.mkdir(parents=True, exist_ok=True)
        demo_cfg_path.write_text(yaml.safe_dump(demo_cfg, sort_keys=False), encoding="utf-8")
        config_for_run = str(demo_cfg_path)
    try:
        run_stage(args.stage, config_for_run)
    except Exception:
        LOGGER.exception("Pipeline stage '%s' failed", args.stage)
        return 1
    LOGGER.info("Pipeline stage '%s' completed", args.stage)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
