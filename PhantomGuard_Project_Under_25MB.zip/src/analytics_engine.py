"""Vectorized, explanation-first retail leak signal classification.

Classifies retail SKU-store time series into three distinct anomaly architectures:
1. Signal Type A: "PHANTOM_STOCKOUT"
   System inventory positive and static for N>=3 consecutive days while real transactions flatline to zero.
2. Signal Type B: "MISPLACED"
   Multi-day sales pause with inventory variance, or sudden velocity rebound without inbound replenishment.
3. Signal Type C: "DELISTED"
   Synchronous sales collapse across peer stores in the same geographical city tier.
"""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Tuple
import numpy as np
import pandas as pd
from pydantic import BaseModel, ConfigDict, Field


class SignalMetrics(BaseModel):
    model_config = ConfigDict(extra="ignore")

    sku: str = Field(..., description="Unique Stock Keeping Unit Identifier")
    store_id: str = Field(..., description="Unique Store Location Identifier")
    confidence_score: float = Field(..., ge=0.0, le=1.0, description="Calculated probability of an inventory leak [0.0 - 1.0]")
    classification: str = Field(..., description="Categorized anomaly root cause: PHANTOM_STOCKOUT, MISPLACED, or DELISTED")
    plain_english_reason: str = Field(..., description="Natural language human-scannable context explanation for floor managers")
    estimated_revenue_at_risk: float = Field(..., ge=0.0, description="Calculated immediate financial loss window")
    priority_level: str = Field(..., description="Calculated priority tier driven by risk metric distribution math")


class OperationalLeakClassifier:
    """Classifies retail inventory leaks and ranks daily actionable check queues."""

    def __init__(self, confidence_threshold: float = 0.50, zero_days: int = 3, history_days: int = 28):
        if not 0.0 <= confidence_threshold <= 1.0:
            raise ValueError("confidence_threshold must be between 0.0 and 1.0")
        self.confidence_threshold = float(confidence_threshold)
        self.zero_days = int(zero_days)
        self.history_days = int(history_days)

    @staticmethod
    def calculate_rolling_metrics(sales_series: np.ndarray, window: int = 14) -> tuple[np.ndarray, np.ndarray]:
        sales = np.asarray(sales_series, dtype=float)
        if sales.ndim != 1 or window < 1:
            raise ValueError("sales_series must be one-dimensional and window must be positive")
        series = pd.Series(sales)
        mean = series.rolling(window=window, min_periods=1).mean().to_numpy()
        std = series.rolling(window=window, min_periods=2).std(ddof=0).fillna(0).to_numpy()
        return mean, std

    def classify_single_combination(
        self,
        sales_history: np.ndarray,
        inventory_history: np.ndarray,
        sku: str,
        store_id: str,
        unit_price: float,
        regional_sales_matrix: np.ndarray | None = None,
    ) -> SignalMetrics:
        """Classify a single SKU-store series with vectorized rules and risk weighting."""
        assert len(sales_history) == len(inventory_history), "Time series inputs must possess exact alignment lengths"
        total_periods = len(sales_history)
        if total_periods < 7:
            return SignalMetrics(
                sku=sku,
                store_id=store_id,
                confidence_score=0.0,
                classification="UNKNOWN",
                plain_english_reason="Insufficient historical depth to securely compute moving windows.",
                estimated_revenue_at_risk=0.0,
                priority_level="Low",
            )

        sales = np.asarray(sales_history, dtype=float)
        stock = np.asarray(inventory_history, dtype=float)

        historical_sales = sales[:-7]
        recent_sales = sales[-7:]
        recent_inventory = stock[-7:]

        historical_mean = float(np.mean(historical_sales)) if len(historical_sales) > 0 else float(np.mean(sales))
        historical_std = float(np.std(historical_sales)) if len(historical_sales) > 0 else float(np.std(sales))
        if historical_std == 0:
            historical_std = 1e-6

        consecutive_zeros = 0
        for val in reversed(sales):
            if val == 0:
                consecutive_zeros += 1
            else:
                break

        current_inventory = float(stock[-1])
        inventory_variance = float(np.var(recent_inventory))

        # Check slow movers
        if historical_mean < 0.25 and consecutive_zeros < 14:
            return SignalMetrics(
                sku=sku,
                store_id=store_id,
                confidence_score=0.0,
                classification="NORMAL_SLOW_MOVER",
                plain_english_reason="Product naturally exhibits long gaps between transactions.",
                estimated_revenue_at_risk=0.0,
                priority_level="Low",
            )

        # Mathematical mapping rules targeting interleaved sort logic requirements
        rev_at_risk = float(historical_mean * min(max(consecutive_zeros, 1), 7) * unit_price)

        # Rule 3: Delisted Item / Regional Supply Disconnection Detection
        if regional_sales_matrix is not None:
            regional = np.asarray(regional_sales_matrix, dtype=float)
            if regional.ndim == 2 and regional.shape[0] == len(sales) and regional.shape[1] > 1:
                recent_regional = regional[-min(7, len(regional)):]
                regional_zero_share = float(np.mean(np.all(recent_regional == 0, axis=0)))
                if consecutive_zeros >= 5 and regional_zero_share > 0.75 and historical_mean >= 0.25:
                    base_confidence = min(0.92, 0.60 + (consecutive_zeros * 0.04) * regional_zero_share)
                    priority = "Medium"
                    return SignalMetrics(
                        sku=sku,
                        store_id=store_id,
                        confidence_score=float(base_confidence),
                        classification="DELISTED",
                        plain_english_reason=f"Sales ceased across {int(regional_zero_share * 100)}% of peer stores in this city tier. Suspected regional catalog phase-out.",
                        estimated_revenue_at_risk=float(rev_at_risk),
                        priority_level=priority,
                    )

        # Rule 1: Phantom Stockout Detection
        if current_inventory > 0 and consecutive_zeros >= 3 and inventory_variance == 0.0:
            base_confidence = min(0.99, 0.40 + (consecutive_zeros * 0.08) + (historical_mean * 0.05))
            priority = "Critical" if rev_at_risk > 800 or base_confidence > 0.85 else ("High" if rev_at_risk > 300 else "Medium")
            return SignalMetrics(
                sku=sku,
                store_id=store_id,
                confidence_score=float(base_confidence),
                classification="PHANTOM_STOCKOUT",
                plain_english_reason=f"The system shows {int(current_inventory)} units in stock, but zero sales were recorded for {consecutive_zeros} days. Velocity average should be {historical_mean:.1f} units/day.",
                estimated_revenue_at_risk=float(rev_at_risk),
                priority_level=priority,
            )

        # Rule 2: Misplaced on Wrong Shelf Detection
        if consecutive_zeros >= 2 and inventory_variance > 0.0:
            recent_stock_drops = np.diff(recent_inventory)
            unaccounted_variance = float(np.sum(np.abs(recent_stock_drops)))
            base_confidence = min(0.88, 0.45 + (consecutive_zeros * 0.06) + (unaccounted_variance * 0.02))
            priority = "High" if rev_at_risk > 400 or base_confidence > 0.75 else "Medium"
            return SignalMetrics(
                sku=sku,
                store_id=store_id,
                confidence_score=float(base_confidence),
                classification="MISPLACED",
                plain_english_reason=f"System inventory fluctuated (variance={inventory_variance:.1f}) without regular checkout sales for {consecutive_zeros} days. Likely misplaced in adjacent aisle or staging.",
                estimated_revenue_at_risk=float(rev_at_risk),
                priority_level=priority,
            )

        # Rule 2b: Sales Rebound Pattern (Item returned to shelf after days of zero)
        if len(sales) > 2 and sales[-1] > 0 and sales[-2] == 0:
            run = 0
            for val in sales[-2::-1]:
                if val == 0:
                    run += 1
                else:
                    break
            if run >= 2 and current_inventory > 0 and historical_mean >= 0.25:
                base_confidence = min(0.85, 0.50 + 0.05 * run)
                priority = "High" if rev_at_risk > 350 else "Medium"
                return SignalMetrics(
                    sku=sku,
                    store_id=store_id,
                    confidence_score=float(base_confidence),
                    classification="MISPLACED",
                    plain_english_reason=f"Sales suddenly resumed after a {run}-day blackout without inventory receipt. Product was likely temporarily misplaced on shelf.",
                    estimated_revenue_at_risk=float(rev_at_risk),
                    priority_level=priority,
                )

        # Fallback / Default
        if current_inventory > 0 and consecutive_zeros >= 2 and historical_mean >= 0.3:
            conf = min(0.70, 0.35 + consecutive_zeros * 0.07)
            priority = "High" if rev_at_risk > 500 else "Medium"
            return SignalMetrics(
                sku=sku,
                store_id=store_id,
                confidence_score=float(conf),
                classification="PHANTOM_STOCKOUT",
                plain_english_reason=f"Recorded on-hand stock ({int(current_inventory)}) conflicts with {consecutive_zeros} days of zero sales.",
                estimated_revenue_at_risk=float(rev_at_risk),
                priority_level=priority,
            )

        return SignalMetrics(
            sku=sku,
            store_id=store_id,
            confidence_score=0.0,
            classification="UNKNOWN",
            plain_english_reason="Sales and recorded stock are within acceptable operational limits.",
            estimated_revenue_at_risk=0.0,
            priority_level="Low",
        )

    def classify_panel(self, panel: pd.DataFrame, stores: pd.DataFrame | None = None) -> pd.DataFrame:
        """Vectorized classification across the full panel without lookahead leakage."""
        required = {"date", "store_id", "sku_id", "sales", "on_hand"}
        missing = sorted(required.difference(panel.columns))
        if missing:
            raise ValueError(f"panel is missing required columns: {missing}")

        df = panel.copy()
        df["date"] = pd.to_datetime(df["date"], errors="coerce")
        if df["date"].isna().any():
            raise ValueError("panel contains invalid dates")

        df["sales"] = pd.to_numeric(df["sales"], errors="coerce").fillna(0).clip(lower=0)
        df["on_hand"] = pd.to_numeric(df["on_hand"], errors="coerce").fillna(0).clip(lower=0)

        df = df.sort_values(["store_id", "sku_id", "date"], kind="stable").reset_index(drop=True)
        group = df.groupby(["store_id", "sku_id"], sort=False, observed=True)

        df["historical_mean"] = group["sales"].transform(
            lambda s: s.shift(1).rolling(self.history_days, min_periods=min(7, self.history_days)).mean()
        ).fillna(0)

        df["zero_streak"] = group["sales"].transform(
            lambda s: s.eq(0).astype("int16").groupby(s.ne(0).cumsum()).cumsum()
        ).fillna(0)

        df["recent_stock_min"] = group["on_hand"].transform(
            lambda s: s.rolling(self.zero_days, min_periods=self.zero_days).min()
        )
        df["recent_stock_max"] = group["on_hand"].transform(
            lambda s: s.rolling(self.zero_days, min_periods=self.zero_days).max()
        )
        df["inventory_flat"] = df["recent_stock_min"].eq(df["recent_stock_max"])
        df["inventory_positive"] = df["on_hand"].gt(0)

        df["price"] = pd.to_numeric(df.get("unit_price", pd.Series(0.0, index=df.index)), errors="coerce").fillna(0).clip(lower=0)
        df["expected_daily_revenue_loss"] = df["historical_mean"] * df["price"]

        # Regional synchronization
        df["regional_zero_share"] = 0.0
        if stores is not None and {"store_id", "city_tier"}.issubset(stores.columns):
            df = df.merge(stores[["store_id", "city_tier"]].drop_duplicates("store_id"), on="store_id", how="left")
            regional = df.groupby(["date", "sku_id", "city_tier"], dropna=False, observed=True)["sales"].transform(
                lambda s: s.eq(0).mean()
            )
            df["regional_zero_share"] = regional.fillna(0)

        sufficient = df["historical_mean"].ge(0.25)
        anomaly_eligible = sufficient | df["zero_streak"].ge(14)
        phantom = (df["inventory_positive"] & df["inventory_flat"] & df["sales"].eq(0)
                   & df["zero_streak"].ge(self.zero_days) & anomaly_eligible)

        previous_streak = group["zero_streak"].shift(1).fillna(0)
        misplaced = (~phantom & df["sales"].gt(0) & previous_streak.ge(2)
                     & df["inventory_positive"] & sufficient)
        delisted = (df["sales"].eq(0) & df["zero_streak"].ge(5)
                    & df["regional_zero_share"].gt(0.75) & anomaly_eligible)
        slow = ~anomaly_eligible & df["sales"].eq(0) & ~delisted

        df["classification"] = np.select(
            [delisted, phantom, misplaced, slow],
            ["DELISTED", "PHANTOM_STOCKOUT", "MISPLACED", "NORMAL_SLOW_MOVER"],
            default="UNKNOWN",
        )

        df["confidence_score"] = np.select(
            [delisted, phantom, misplaced],
            [
                np.minimum(0.92, 0.60 + 0.04 * df["zero_streak"] * df["regional_zero_share"]),
                np.minimum(0.99, 0.40 + 0.08 * df["zero_streak"] + 0.05 * df["historical_mean"]),
                np.minimum(0.85, 0.50 + 0.05 * previous_streak),
            ],
            default=0.0,
        ).astype(float)

        df["estimated_revenue_at_risk"] = np.where(
            df["confidence_score"].ge(self.confidence_threshold),
            df["expected_daily_revenue_loss"] * np.minimum(df["zero_streak"].clip(lower=1), 7),
            0.0,
        )

        # Dynamic priority level calculation based on risk and confidence math
        df["priority_level"] = np.select(
            [
                (df["estimated_revenue_at_risk"] > 800) | (df["confidence_score"] > 0.85),
                (df["estimated_revenue_at_risk"] > 300) | (df["confidence_score"] > 0.65),
            ],
            ["Critical", "High"],
            default="Medium",
        )

        # Numeric Composite Rank Weight for dynamic interleaved sorting
        # W = (confidence^1.2) * (revenue_at_risk + 50)
        # This mathematically interleaves high-risk medium-priority items above low-risk high-priority items
        df["composite_rank_weight"] = (
            np.power(df["confidence_score"], 1.2) * np.sqrt(df["estimated_revenue_at_risk"] + 50.0)
        )

        df["plain_english_reason"] = np.select(
            [delisted, phantom, misplaced, slow],
            [
                "Sales paused across most peer stores in this city tier. Suspected regional catalog phase-out; confirm status before shelf check.",
                "System shows stock on hand, but zero sales were recorded for multiple days despite healthy customer demand velocity.",
                "Sales resumed after an unexplained blackout without inbound stock logged. Likely misplaced on an adjacent shelf or aisle.",
                "Naturally slow-moving SKU; zero sales are expected and within normal velocity bounds.",
            ],
            default="Recorded on-hand stock conflicts with the observed transaction pattern; physical audit recommended.",
        )

        return df

    def ranked_daily_queue(self, classified: pd.DataFrame, date: str | pd.Timestamp | None = None, limit: int = 20) -> pd.DataFrame:
        """Return at most ``limit`` actionable signals per store, strictly sorted by numeric composite risk weight."""
        if not 1 <= limit <= 20:
            raise ValueError("limit must be in [1, 20]")

        df = classified.copy()
        if date is not None:
            target = pd.Timestamp(date)
            df = df.loc[pd.to_datetime(df["date"]).eq(target)]

        df = df.loc[
            df["confidence_score"].ge(self.confidence_threshold)
            & df["classification"].isin(["PHANTOM_STOCKOUT", "MISPLACED", "DELISTED"])
        ]

        if "composite_rank_weight" not in df.columns:
            df["composite_rank_weight"] = (
                np.power(df["confidence_score"], 1.2) * np.sqrt(df["estimated_revenue_at_risk"] + 50.0)
            )

        # Dynamic interleaved sort order: composite_rank_weight descending, then sku_id ascending for deterministic ties
        return (
            df.sort_values(
                ["store_id", "composite_rank_weight", "estimated_revenue_at_risk", "sku_id"],
                ascending=[True, False, False, True],
                kind="stable",
            )
            .groupby("store_id", sort=False, group_keys=False)
            .head(limit)
            .reset_index(drop=True)
        )
