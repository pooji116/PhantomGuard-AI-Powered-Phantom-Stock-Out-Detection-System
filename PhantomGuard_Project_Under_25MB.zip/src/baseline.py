"""Explainable rule-based phantom-inventory baseline."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from src.config import load_config, project_root
from src.features import load_features
from src.io_utils import write_table

LOGGER = logging.getLogger(__name__)


def _clip01(x: pd.Series) -> pd.Series:
    return x.clip(lower=0.0, upper=1.0)


def generate_baseline_reason(row: pd.Series) -> str:
    stock = row.get("on_hand", np.nan)
    streak = int(row.get("positive_stock_zero_streak", row.get("zero_sales_streak", 0)) or 0)
    expected = row.get("expected_demand", np.nan)
    promo = int(row.get("promo_flag", 0) or 0)
    hist = int(row.get("insufficient_history", 0) or 0)
    parts = [
        f"Recorded stock is {stock:.0f}" if pd.notna(stock) else "Recorded stock is unknown",
        f"sales have been at zero for {streak} consecutive completed day(s)",
        (
            f"while expected daily demand is {expected:.2f} units"
            if pd.notna(expected)
            else "while expected demand is uncertain"
        ),
    ]
    if promo:
        parts.append("a promotion is active")
    if hist:
        parts.append("history is still short so the signal is weaker")
    text = ", ".join(parts) + ". Verify the shelf and backroom inventory; this is a risk estimate, not proof of a physical stockout."
    return text[0].upper() + text[1:]


def score_baseline(df: pd.DataFrame, cfg: dict[str, Any] | None = None) -> pd.DataFrame:
    """Assign a transparent 0-1 risk score and a deterministic reason."""
    cfg = cfg or load_config()
    rules = cfg.get("baseline", {})
    min_streak = int(rules.get("min_zero_streak", 3))
    min_demand = float(rules.get("min_expected_demand", 0.3))
    min_on_hand = float(rules.get("min_on_hand", 1.0))
    min_history = int(rules.get("min_history_days", 14))
    min_pos = float(rules.get("min_positive_sales_days_28", 3))
    ratio_min = float(rules.get("stock_to_demand_ratio_min", 2.0))
    demand_scale = max(float(rules.get("expected_demand_scale", 1.0)), 1e-6)

    out = df.copy()
    on_hand = out.get("on_hand", pd.Series(np.nan, index=out.index))
    streak = out.get("positive_stock_zero_streak", out.get("zero_sales_streak", 0)).fillna(0)
    expected = out.get("expected_demand", pd.Series(0.0, index=out.index)).fillna(0)
    history_days = out.get("history_days", pd.Series(0, index=out.index)).fillna(0)
    pos_days = out.get("positive_sales_days_28", pd.Series(0, index=out.index)).fillna(0)
    ratio = out.get("stock_to_demand_ratio", pd.Series(0.0, index=out.index)).fillna(0)
    sales = out.get("sales", pd.Series(np.nan, index=out.index))
    scoring = str(cfg.get("features", {}).get("scoring_time", "start_of_day"))
    sales_zero = (
        (sales == 0) & sales.notna()
        if scoring == "end_of_day"
        else (
            (out.get("sales_lag_1", pd.Series(np.nan, index=out.index)) == 0)
            & out.get("sales_lag_1", pd.Series(np.nan, index=out.index)).notna()
            & pd.to_numeric(out.get("days_since_previous_observation", pd.Series(np.nan, index=out.index)), errors="coerce").eq(1)
        )
    )

    eligible = (
        (on_hand >= min_on_hand)
        & sales_zero
        & (history_days >= min_history)
        & (expected >= min_demand)
        & (pos_days >= min_pos)
    )
    streak_component = _clip01((streak - min_streak + 1) / 10.0)
    # Use a configured constant instead of a panel-wide quantile so holdout
    # dates cannot influence baseline normalization.
    demand_component = _clip01(expected / (expected + demand_scale))
    ratio_component = _clip01((ratio - ratio_min) / 20.0)
    promo_boost = np.where(out.get("promo_flag", 0).fillna(0) > 0, 0.08, 0.0)

    raw = 0.45 * streak_component + 0.35 * demand_component + 0.20 * ratio_component + promo_boost
    out["baseline_score"] = np.where(eligible, _clip01(pd.Series(raw, index=out.index)), 0.0)
    out["baseline_eligible"] = eligible.astype(int)
    reasons = np.array(["Not a baseline candidate under current rules."] * len(out), dtype=object)
    if eligible.any():
        reasons[eligible.to_numpy()] = out.loc[eligible].apply(generate_baseline_reason, axis=1).to_numpy()
    out["baseline_reason"] = reasons
    return out


def run_baseline(config_path: str | Path | None = None) -> Path:
    cfg = load_config(config_path)
    feats = load_features(cfg)
    scored = score_baseline(feats, cfg)
    keep = [
        c
        for c in scored.columns
        if c
        in {
            "date",
            "store_id",
            "sku_id",
            "sales",
            "sales_lag_1",
            "days_since_previous_observation",
            "on_hand",
            "expected_demand",
            "zero_sales_streak",
            "positive_stock_zero_streak",
            "unit_price",
            "baseline_score",
            "baseline_eligible",
            "baseline_reason",
            "promo_flag",
            "insufficient_history",
            "Category",
            "category",
            "product_name",
            "Product Name",
        }
        or c == cfg.get("label", {}).get("column")
    ]
    out = write_table(
        scored[keep],
        project_root() / cfg["paths"]["predictions_dir"] / cfg["files"]["baseline_predictions"],
    )
    LOGGER.info("Wrote baseline predictions to %s", out)
    return out


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run_baseline()
