"""Transparent potential-revenue estimates. These are not confirmed recoveries."""

from __future__ import annotations

import logging
from typing import Any

import numpy as np
import pandas as pd

from src.config import load_config

LOGGER = logging.getLogger(__name__)


def format_inr(value: float | None) -> str:
    if value is None or (isinstance(value, float) and (np.isnan(value) or np.isinf(value))):
        return "n/a"
    return f"₹{value:,.0f}"



def attach_revenue_fields(
    df: pd.DataFrame,
    cfg: dict[str, Any] | None = None,
) -> pd.DataFrame:
    cfg = cfg or load_config()
    recoverable = float(cfg.get("ranking", {}).get("recoverable_fraction", 0.5))
    cap = int(cfg.get("business_impact", {}).get("estimated_affected_days_cap", 7))

    out = df.copy()

    price = out["unit_price"] if "unit_price" in out.columns else None

    if "expected_demand" in out.columns:
        demand = pd.to_numeric(
            out["expected_demand"], errors="coerce"
        ).fillna(0)
    else:
        demand = pd.Series(0.0, index=out.index)

    if price is None:
        at_risk = pd.Series(np.nan, index=out.index)
        ok = False
    else:
        price_values = pd.to_numeric(price, errors="coerce")
        ok = bool(price_values.notna().any())
        at_risk = (demand * price_values).where(price_values.notna())
    out["estimated_daily_revenue_at_risk"] = at_risk
    out["estimated_daily_potential_recovery"] = at_risk * recoverable

    if "positive_stock_zero_streak" in out.columns:
        streak_source = out["positive_stock_zero_streak"]
    elif "zero_sales_streak" in out.columns:
        streak_source = out["zero_sales_streak"]
    else:
        streak_source = pd.Series(1.0, index=out.index)

    streak = pd.to_numeric(streak_source, errors="coerce").fillna(1).clip(lower=1)
    out["estimated_affected_days"] = streak.clip(upper=cap)
    out["estimated_incident_revenue_at_risk"] = at_risk * out["estimated_affected_days"]
    out["estimated_incident_potential_recovery"] = (
        out["estimated_daily_potential_recovery"] * out["estimated_affected_days"]
    )
    out["revenue_is_estimate"] = True
    out["prices_available"] = bool(ok)

    if "margin" in out.columns and ok:
        margin = pd.to_numeric(out["margin"], errors="coerce")
        out["estimated_daily_gross_margin_at_risk"] = demand * margin

    return out



def collapse_incidents(alerts: pd.DataFrame) -> pd.DataFrame:
    """Collapse consecutive store-SKU alert days so overlapping days are not double-counted."""
    if alerts.empty:
        return alerts
    work = alerts.sort_values(["store_id", "sku_id", "date"]).copy()
    work["date"] = pd.to_datetime(work["date"])
    gap = work.groupby(["store_id", "sku_id"], sort=False)["date"].diff().dt.days.fillna(1)
    work["incident_id"] = ((gap > 1) | (work["sku_id"] != work["sku_id"].shift(1)) | (work["store_id"] != work["store_id"].shift(1))).cumsum()
    agg = {
        "date": ["min", "max", "count"],
        "estimated_daily_revenue_at_risk": "mean",
        "estimated_incident_revenue_at_risk": "max",
        "estimated_daily_potential_recovery": "mean",
        "estimated_incident_potential_recovery": "max",
        "predicted_probability": "max",
        "priority_score": "max",
    }
    present = {k: v for k, v in agg.items() if k in work.columns}
    grouped = work.groupby(["store_id", "sku_id", "incident_id"], sort=False).agg(present)
    grouped.columns = ["_".join(col).strip("_") for col in grouped.columns.to_flat_index()]
    grouped = grouped.reset_index()
    return grouped


def aggregate_impact(
    alerts: pd.DataFrame,
    cfg: dict[str, Any] | None = None,
    observed_period_days: int | None = None,
) -> dict[str, Any]:
    cfg = cfg or load_config()
    annualize = bool(cfg.get("business_impact", {}).get("annualization_enabled", True))
    recoverable = float(cfg.get("ranking", {}).get("recoverable_fraction", 0.5))
    framed = attach_revenue_fields(alerts, cfg)
    prices_ok = bool(framed.get("prices_available", pd.Series([False])).iloc[0]) if len(framed) else False
    incidents = collapse_incidents(framed) if len(framed) else framed

    period_days = max(int(observed_period_days), 1) if observed_period_days is not None else 1
    if observed_period_days is None and "date" in framed.columns and len(framed):
        dates = pd.to_datetime(framed["date"])
        period_days = max(int((dates.max() - dates.min()).days) + 1, 1)

    daily_at_risk = float(framed["estimated_daily_revenue_at_risk"].sum()) if prices_ok else None
    # Within each incident, use its maximum streak-based estimate once; never sum overlapping alert days.
    if prices_ok and len(incidents) and "estimated_incident_potential_recovery_max" in incidents.columns:
        period_at_risk = float(incidents["estimated_incident_revenue_at_risk_max"].fillna(0).sum())
        period_recovery = float(incidents["estimated_incident_potential_recovery_max"].fillna(0).sum())
    elif prices_ok:
        period_at_risk = float(framed["estimated_incident_revenue_at_risk"].sum())
        period_recovery = float(framed["estimated_incident_potential_recovery"].sum())
    else:
        period_at_risk = None
        period_recovery = None

    annual = None
    if annualize and period_recovery is not None:
        annual = period_recovery * 365.0 / period_days

    return {
        "currency": cfg.get("project", {}).get("currency", "INR"),
        "n_alerts": int(len(framed)),
        "n_incidents_deduped": int(len(incidents)) if len(framed) else 0,
        "prices_available": prices_ok,
        "recoverable_fraction": recoverable,
        "observed_period_days": period_days,
        "estimated_daily_revenue_at_risk_sum": daily_at_risk,
        "estimated_period_revenue_at_risk": period_at_risk,
        "estimated_period_potential_recovery": period_recovery,
        "estimated_annualized_potential_recovery": annual,
        "actually_recovered_revenue": None,
        "synthetic_demo": bool(cfg.get("project", {}).get("synthetic_demo", False)),
        "caveats": [
            "Revenue at risk uses expected daily demand × unit price before any recovery assumption.",
            f"Potential recovery applies the assumed {recoverable:.0%} recoverable fraction to revenue at risk.",
            "Actually recovered revenue is not measured; inspection outcomes alone do not establish recovered sales.",
            "They use expected historical demand, not the zero sales of the current day.",
            "Consecutive store-SKU alert dates are grouped; each incident contributes its highest capped streak estimate once.",
            "Annualization is a linear projection and is unreliable if the window is seasonal or short.",
            "Gross revenue is not gross margin unless a margin column is supplied.",
            "Hidden ground-truth labels are never used to compute these amounts.",
            "Synthetic demonstration data does not represent competition or live-store results.",
        ],
    }


def impact_assumptions_text(summary: dict[str, Any]) -> str:
    lines = [
        f"Currency: {summary.get('currency', 'INR')}",
        f"Recoverable fraction assumption: {summary.get('recoverable_fraction')}",
        f"Prices available: {summary.get('prices_available')}",
        f"Deduped incidents: {summary.get('n_incidents_deduped')}",
    ]
    lines.extend(f"- {c}" for c in summary.get("caveats", []))
    return "\n".join(lines)
