"""Configuration loading and project path helpers."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import yaml

LOGGER = logging.getLogger(__name__)

STANDARD_COLUMNS = (
    "date",
    "store_id",
    "sku_id",
    "sales",
    "on_hand",
    "unit_price",
    "promo_flag",
    "label",
    "store_size",
    "store_format",
    "city_tier",
    "holiday_flag",
    "margin",
)


def project_root() -> Path:
    """Return the repository root (parent of ``src`` / ``config``)."""
    return Path(__file__).resolve().parents[1]


def load_config(config_path: str | Path | None = None) -> dict[str, Any]:
    """Load YAML configuration from the project config directory."""
    path = Path(config_path) if config_path else project_root() / "config" / "config.yaml"
    if not path.exists():
        raise FileNotFoundError(f"Configuration file not found: {path}")
    with path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    LOGGER.debug("Loaded config from %s", path)
    return data


def resolve_path(cfg: dict[str, Any], *parts: str) -> Path:
    """Resolve a path relative to the project root."""
    return project_root().joinpath(*parts)


def get_column_map(cfg: dict[str, Any]) -> dict[str, str]:
    """Map canonical names to configured source column names."""
    raw = cfg.get("columns", {})
    return {key: str(raw.get(key, key)) for key in STANDARD_COLUMNS}


def label_column(cfg: dict[str, Any]) -> str:
    return str(cfg.get("label", {}).get("column", "is_phantom"))


def positive_label_value(cfg: dict[str, Any]) -> int:
    return int(cfg.get("label", {}).get("positive_value", 1))
