"""Small, testable transformations used by the Streamlit manager dashboard."""

from __future__ import annotations

from typing import Any
from datetime import date

import pandas as pd


def has_ranked_alerts(df: pd.DataFrame | None) -> bool:
    """Return whether the dashboard has rows to show without assuming artifacts exist."""
    return df is not None and not df.empty


def filter_store_day_alerts(df: pd.DataFrame, date: Any, store_id: str) -> pd.DataFrame:
    """Safely filter alerts to a store-day, including empty/missing-data cases."""
    required = {"date", "store_id"}
    if df.empty or not required.issubset(df.columns):
        return df.iloc[0:0].copy()
    dates = pd.to_datetime(df["date"], errors="coerce").dt.date
    selected_date = pd.Timestamp(date).date()
    mask = dates.eq(selected_date) & df["store_id"].astype(str).eq(str(store_id))
    return df.loc[mask].copy()


def latest_alert_defaults(alerts: pd.DataFrame, stores: list[str], fallback_date: date) -> tuple[str, date]:
    """Choose the store/date with the newest alert; fall back to recent data."""
    if alerts.empty or not {"date", "store_id"}.issubset(alerts.columns):
        return (stores[0], fallback_date) if stores else ("", fallback_date)
    data = alerts.copy()
    data["date"] = pd.to_datetime(data["date"], errors="coerce")
    data = data.dropna(subset=["date"])
    if data.empty:
        return (stores[0], fallback_date) if stores else ("", fallback_date)
    newest = data["date"].max()
    newest_stores = sorted(data.loc[data["date"].eq(newest), "store_id"].astype(str).unique())
    return newest_stores[0], newest.date()


def filter_product_history(features: pd.DataFrame | None, store_id: str, sku_id: str, date: Any) -> pd.DataFrame:
    """Return one store/SKU's observations up to the selected data date."""
    required = {"date", "store_id", "sku_id"}
    if features is None or features.empty or not required.issubset(features.columns):
        return pd.DataFrame()
    dates = pd.to_datetime(features["date"], errors="coerce").dt.date
    selected_date = pd.Timestamp(date).date()
    mask = (
        features["store_id"].astype(str).eq(str(store_id))
        & features["sku_id"].astype(str).eq(str(sku_id))
        & dates.le(selected_date)
    )
    return features.loc[mask].sort_values("date").copy()


def selection_data_available(features: pd.DataFrame | None, store_id: str, date: Any) -> bool:
    """True when sales and stock observations exist for this store/date."""
    required = {"date", "store_id", "sales", "on_hand"}
    if features is None or features.empty or not required.issubset(features.columns):
        return False
    dates = pd.to_datetime(features["date"], errors="coerce").dt.date
    selected = features.loc[features["store_id"].astype(str).eq(str(store_id)) & dates.eq(pd.Timestamp(date).date())]
    return bool(not selected.empty and selected["sales"].notna().any() and selected["on_hand"].notna().any())

