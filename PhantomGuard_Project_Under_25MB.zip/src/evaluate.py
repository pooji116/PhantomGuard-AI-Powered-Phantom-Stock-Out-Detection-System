"""Evaluation utilities for permitted labeled windows.

This module does not replace an organizer-provided evaluator. If a root-level
``evaluate.py`` exists, keep using that file as the official competition contract.
"""

from __future__ import annotations

import logging
import gc
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, precision_recall_curve, roc_auc_score

from src.config import label_column, load_config, positive_label_value, project_root
from src.io_utils import read_table, write_json
from src.rank_alerts import eligible_mask, precision_at_k_store_day, rank_store_day_alerts

LOGGER = logging.getLogger(__name__)


def labeled_population(df: pd.DataFrame, label_col: str) -> pd.DataFrame:
    if label_col not in df.columns:
        return df.iloc[0:0].copy()
    return df.loc[df[label_col].notna()].copy()


def recall_labeled(
    ranked: pd.DataFrame,
    population: pd.DataFrame,
    label_col: str,
    positive_value: int,
) -> dict[str, float | int | None]:
    """Recall among labeled positives only. Unlabeled rows are ignored."""
    if label_col not in population.columns:
        return {"recall": None, "positives": 0, "captured": 0, "note": "no label column"}
    pop_pos = population.loc[population[label_col] == positive_value]
    n_pos = int(len(pop_pos))
    if n_pos == 0:
        return {
            "recall": None,
            "positives": 0,
            "captured": 0,
            "note": "no labeled positives in the evaluation population",
        }
    if ranked.empty:
        captured = 0
    else:
        keys = ranked[["date", "store_id", "sku_id"]].drop_duplicates()
        merged = pop_pos.merge(keys, on=["date", "store_id", "sku_id"], how="inner")
        captured = int(len(merged))
    return {
        "recall": captured / n_pos,
        "positives": n_pos,
        "captured": captured,
        "population": "labeled rows only; unlabeled records are not treated as negatives",
    }


def precision_at_budgets(
    df: pd.DataFrame,
    cfg: dict[str, Any],
    budgets: tuple[int, ...] = (5, 10, 20, 30),
    probability_col: str = "predicted_probability",
) -> dict[str, Any]:
    lbl = label_column(cfg)
    pos = positive_label_value(cfg)
    out: dict[str, Any] = {}
    for k in budgets:
        ranked = rank_store_day_alerts(df, cfg, probability_col=probability_col, max_alerts=k)
        out[f"precision_at_{k}"] = precision_at_k_store_day(ranked, lbl, pos, k=k)
    return out


def classification_diagnostics(
    y_true: np.ndarray, proba: np.ndarray
) -> dict[str, Any]:
    if len(y_true) == 0 or len(np.unique(y_true)) < 2:
        return {"average_precision": None, "roc_auc": None, "note": "need both classes in labeled eval"}
    prec, rec, _ = precision_recall_curve(y_true, proba)
    return {
        "average_precision": float(average_precision_score(y_true, proba)),
        "roc_auc": float(roc_auc_score(y_true, proba)),
        "pr_curve_points": int(len(prec)),
        "positive_rate": float(np.mean(y_true)),
    }


def _f1_from_precision_recall(precision: float | None, recall: float | None) -> float | None:
    if precision is None or recall is None or precision + recall == 0:
        return None
    return float(2 * precision * recall / (precision + recall))


def evaluate_predictions(
    candidates: pd.DataFrame,
    cfg: dict[str, Any] | None = None,
    probability_col: str = "predicted_probability",
    max_alerts: int | None = None,
) -> dict[str, Any]:
    cfg = cfg or load_config()
    lbl = label_column(cfg)
    pos = positive_label_value(cfg)
    k = int(max_alerts or cfg.get("ranking", {}).get("max_alerts_per_store_day", 20))
    pop = labeled_population(candidates, lbl)
    report: dict[str, Any] = {
        "synthetic_demo": bool(cfg.get("project", {}).get("synthetic_demo", False)),
        "scoring_time": cfg.get("features", {}).get("scoring_time", "start_of_day"),
        "evaluation_population": "rows with a non-null label",
        "n_candidate_rows": int(len(candidates)),
        "n_labeled_rows": int(len(pop)),
        "label_column": lbl,
        "k": k,
        "disclaimer": (
            "If synthetic_demo is true, these metrics are demonstration-only and are not "
            "official competition results."
        ),
    }
    if pop.empty:
        report["error"] = "No labeled evaluation rows. Metrics are withheld."
        return report

    # Select alerts from every eligible candidate before consulting labels.
    # Filtering to labeled rows here lets hidden labels influence the top-k
    # and inflates precision when unlabeled candidates would outrank them.
    ranked = rank_store_day_alerts(candidates, cfg, probability_col=probability_col, max_alerts=k)
    report["precision_at_20"] = precision_at_k_store_day(ranked, lbl, pos, k=k)
    report["recall"] = recall_labeled(ranked, pop, lbl, pos)
    report["precision_at_budgets"] = precision_at_budgets(candidates, cfg, probability_col=probability_col)
    p5 = report["precision_at_budgets"].get("precision_at_5", {})
    p20 = report["precision_at_20"]
    recall = report["recall"].get("recall")
    ranked5 = rank_store_day_alerts(candidates, cfg, probability_col=probability_col, max_alerts=5)
    report["recall_at_5"] = recall_labeled(ranked5, pop, lbl, pos)
    report["f1_at_5"] = _f1_from_precision_recall(p5.get("micro_average"), report["recall_at_5"].get("recall"))
    report["f1_at_20"] = _f1_from_precision_recall(p20.get("micro_average"), recall)
    report["ranking_metrics_note"] = (
        "Precision@k has two reported denominator policies: selected-labeled (unlabeled selections omitted) and fixed-k. "
        "Precision@20 is not informative about ordering on store-days with fewer than 20 eligible candidates because all eligible candidates fit."
    )
    if probability_col in pop.columns:
        y = (pop[lbl] == pos).astype(int).to_numpy()
        proba = pd.to_numeric(pop[probability_col], errors="coerce").fillna(0).to_numpy()
        report["diagnostics"] = classification_diagnostics(y, proba)
    if "store_format" in pop.columns and lbl in ranked.columns:
        tmp = ranked.loc[ranked[lbl].notna()].copy()
        tmp["hit"] = (tmp[lbl] == pos).astype(int)
        report["precision_by_store_format"] = tmp.groupby("store_format")["hit"].mean().to_dict()
    report["n_alerts_selected"] = int(len(ranked))
    report["max_alerts_per_store_day_observed"] = (
        int(ranked.groupby(["store_id", "date"]).size().max()) if len(ranked) else 0
    )
    return report


def _held_out_rows(df: pd.DataFrame, cfg: dict[str, Any]) -> pd.DataFrame:
    """Select the untouched final chronological period from scored candidates."""
    if "split" in df.columns:
        return df.loc[df["split"].astype(str).str.lower().eq("test")].copy()
    from src.model import chronological_split

    _, _, test = chronological_split(df, cfg)
    return test


def evaluate_model_vs_baseline(
    model_candidates: pd.DataFrame,
    baseline_candidates: pd.DataFrame,
    cfg: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Evaluate independent predictions on the same chronological holdout and keys."""
    cfg = cfg or load_config()
    lbl = label_column(cfg)
    keys = ["date", "store_id", "sku_id"]
    model = _held_out_rows(model_candidates, cfg)
    baseline = _held_out_rows(baseline_candidates, cfg)
    if "predicted_probability" not in model.columns:
        raise ValueError("Model prediction file is missing predicted_probability.")
    if "baseline_score" not in baseline.columns:
        raise ValueError("Independent baseline file is missing baseline_score.")
    for name, frame in (("model", model), ("baseline", baseline)):
        missing = [key for key in keys if key not in frame.columns]
        if missing:
            raise ValueError(f"{name} predictions are missing keys: {missing}")
        if frame.duplicated(keys).any():
            raise ValueError(f"{name} test predictions contain duplicate SKU-store-day keys.")
        frame["date"] = pd.to_datetime(frame["date"], errors="coerce").dt.normalize()

    ranking_fields = [
        "sales", "sales_lag_1", "days_since_previous_observation", "on_hand", "expected_demand", "unit_price", "history_days",
        "positive_stock_zero_streak", "zero_sales_streak", "promo_flag",
    ]
    model_cols = keys + ["predicted_probability"] + [c for c in ranking_fields if c in model.columns]
    baseline_cols = keys + ["baseline_score"] + [c for c in ranking_fields if c in baseline.columns]
    if lbl in model.columns:
        model_cols.append(lbl)
    if lbl in baseline.columns:
        baseline_cols.append(lbl)
    aligned = model[model_cols].merge(
        baseline[baseline_cols], on=keys, how="inner", validate="one_to_one", suffixes=("_model", "_baseline")
    )
    if aligned.empty:
        raise ValueError("Model and baseline have no common candidates in the held-out period.")

    label_model = f"{lbl}_model" if f"{lbl}_model" in aligned.columns else None
    label_base = f"{lbl}_baseline" if f"{lbl}_baseline" in aligned.columns else None
    if label_model and label_base:
        both = aligned[label_model].notna() & aligned[label_base].notna()
        disagree = both & aligned[label_model].ne(aligned[label_base])
        if disagree.any():
            raise ValueError("Model and baseline files contain conflicting labels for common candidates.")
        aligned[lbl] = aligned[label_model].combine_first(aligned[label_base])
    elif label_model:
        aligned[lbl] = aligned[label_model]
    elif label_base:
        aligned[lbl] = aligned[label_base]

    for column in ranking_fields:
        model_column = f"{column}_model"
        baseline_column = f"{column}_baseline"
        if model_column not in aligned.columns or baseline_column not in aligned.columns:
            continue
        left_values = pd.to_numeric(aligned[model_column], errors="coerce")
        right_values = pd.to_numeric(aligned[baseline_column], errors="coerce")
        comparable = left_values.notna() & right_values.notna()
        if comparable.any() and not np.isclose(
            left_values[comparable].to_numpy(), right_values[comparable].to_numpy(), equal_nan=True
        ).all():
            raise ValueError(f"Model and baseline candidate feature '{column}' does not match on shared keys.")

    common = aligned[keys + ["predicted_probability", "baseline_score"]].copy()
    for column in ranking_fields:
        model_column = f"{column}_model"
        baseline_column = f"{column}_baseline"
        if model_column in aligned.columns:
            common[column] = aligned[model_column]
        elif baseline_column in aligned.columns:
            common[column] = aligned[baseline_column]
        elif column in aligned.columns:
            common[column] = aligned[column]
    if lbl in aligned.columns:
        common[lbl] = aligned[lbl]
    elif lbl in common.columns:
        pass
    elif label_model or label_base:
        common[lbl] = aligned.get(label_model, pd.Series(index=aligned.index, dtype=object))
    model_metrics = evaluate_predictions(common, cfg, probability_col="predicted_probability")
    baseline_metrics = evaluate_predictions(common, cfg, probability_col="baseline_score")
    eligible = common.loc[eligible_mask(common, cfg)]
    eligible_counts = eligible.groupby(["store_id", "date"], sort=False).size()
    budget = int(cfg.get("ranking", {}).get("max_alerts_per_store_day", 20))
    return {
        "by_source": {"model": model_metrics, "baseline": baseline_metrics},
        "comparison": {
            "evaluation_window": "untouched chronological test period",
            "start_date": aligned["date"].min().date().isoformat(),
            "end_date": aligned["date"].max().date().isoformat(),
            "common_candidate_rows": int(len(aligned)),
            "model_test_candidate_rows": int(len(model)),
            "baseline_test_candidate_rows": int(len(baseline)),
            "candidate_rows_without_common_match": int(max(len(model), len(baseline)) - len(aligned)),
            "model_test_candidate_rows": int(len(model)),
            "baseline_test_candidate_rows": int(len(baseline)),
            "candidate_rows_without_common_match": int(max(len(model), len(baseline)) - len(aligned)),
            "same_candidate_population": True,
            "independent_prediction_files": True,
            "eligible_candidates": int(len(eligible)),
            "store_days_with_eligible_candidates": int(len(eligible_counts)),
            "inspection_budget_per_store_day": budget,
            "store_days_below_budget": int(eligible_counts.lt(budget).sum()),
            "store_days_reaching_budget": int(eligible_counts.ge(budget).sum()),
            "max_eligible_candidates_per_store_day": int(eligible_counts.max()) if len(eligible_counts) else 0,
            "interpretation": (
                f"When every store-day has fewer than {budget} eligible candidates, both sources select the same full set; "
                f"Precision@{budget} and recall can therefore match even when their rankings differ. Compare smaller budgets too."
                if len(eligible_counts) and eligible_counts.max() < budget
                else "At least one store-day reaches the 20-candidate budget, so the ordering can affect Precision@20."
            ),
            "note": "Both sources are ranked separately on identical SKU-store-day keys and labels.",
        },
        "synthetic_demo": bool(cfg.get("project", {}).get("synthetic_demo", False)),
    }


def write_evaluation_report(
    metrics: dict[str, Any],
    cfg: dict[str, Any] | None = None,
    comparison: dict[str, Any] | None = None,
) -> tuple[Path, Path]:
    cfg = cfg or load_config()
    json_path = project_root() / cfg["files"]["evaluation_json"]
    md_path = project_root() / cfg["files"]["evaluation_md"]
    write_json(metrics, json_path)
    p20 = metrics.get("precision_at_20") or {}
    p5 = metrics.get("precision_at_5") or {}
    rec = metrics.get("recall") or {}
    lines = [
        "# PhantomGuard evaluation report",
        "",
        f"Synthetic demonstration: **{metrics.get('synthetic_demo')}**",
        "",
        "These metrics are computed only on rows with non-null labels. Unlabeled records are not treated as negatives.",
        "",
        "## Precision@20 per store-day",
        "",
        f"- Macro-average: {p20.get('macro_average')}",
        f"- Micro-average (pooled selected alerts): {p20.get('micro_average')}",
        f"- Store-days: {p20.get('n_store_days')}",
        f"- Policy: {p20.get('policy')}",
        f"- Precision@5 macro: {p5.get('macro_average')}",
        f"- F1@5: {metrics.get('f1_at_5')}",
        f"- F1@20: {metrics.get('f1_at_20')}",
        "",
        "## Recall (labeled positives)",
        "",
        f"- Recall: {rec.get('recall')}",
        f"- Positives: {rec.get('positives')}",
        f"- Captured in top-20 lists: {rec.get('captured')}",
        "",
        "## Disclaimer",
        "",
        str(metrics.get("disclaimer")),
    ]
    if metrics.get("error"):
        lines.extend(
            [
                "",
                "## Evaluation status",
                "",
                f"- Status: {metrics.get('error')}",
                f"- Candidate rows: {metrics.get('n_candidate_rows')}",
                f"- Labeled rows: {metrics.get('n_labeled_rows')}",
                "- No official organizer evaluator was found in this project; no official score is reported.",
            ]
        )
    if comparison:
        lines.extend(
            [
                "",
                "## Model versus baseline",
                "",
                f"- Evaluation period: {comparison.get('start_date')} to {comparison.get('end_date')} (untouched chronological test period)",
                f"- Test candidates: model {comparison.get('model_test_candidate_rows')}; baseline {comparison.get('baseline_test_candidate_rows')}",
                f"- Model eligible candidates: {comparison.get('eligible_candidates')} across {comparison.get('store_days_with_eligible_candidates')} store-days; max candidates/store-day: {comparison.get('max_eligible_candidates_per_store_day')}",
                f"- Store-days reaching the {comparison.get('inspection_budget_per_store_day')}/day inspection budget: {comparison.get('store_days_reaching_budget')}",
                f"- Model Precision@20 macro: {(comparison.get('model') or {}).get('precision_at_20', {}).get('macro_average')}",
                f"- Baseline Precision@20 macro: {(comparison.get('baseline') or {}).get('precision_at_20', {}).get('macro_average')}",
                f"- Model Precision@5 macro: {((comparison.get('model') or {}).get('precision_at_budgets') or {}).get('precision_at_5', {}).get('macro_average')}",
                f"- Baseline Precision@5 macro: {((comparison.get('baseline') or {}).get('precision_at_budgets') or {}).get('precision_at_5', {}).get('macro_average')}",
                f"- Model recall: {(comparison.get('model') or {}).get('recall', {}).get('recall')}",
                f"- Baseline recall: {(comparison.get('baseline') or {}).get('recall', {}).get('recall')}",
                f"- Evaluation note: {comparison.get('note', comparison.get('interpretation'))}",
            ]
        )
    md_path.parent.mkdir(parents=True, exist_ok=True)
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    LOGGER.info("Wrote evaluation report to %s", md_path)
    return json_path, md_path


def _read_parquet_selection(
    path: Path,
    columns: list[str],
    *,
    split_value: str | None = None,
    date_min: pd.Timestamp | None = None,
) -> pd.DataFrame:
    """Read selected columns and rows from a large Parquet prediction file."""
    import pyarrow.parquet as pq

    parquet = pq.ParquetFile(path)
    selected_columns = [column for column in columns if column in parquet.schema.names]
    frames: list[pd.DataFrame] = []
    for batch in parquet.iter_batches(columns=selected_columns, batch_size=400_000):
        frame = batch.to_pandas()
        mask = pd.Series(True, index=frame.index)
        if split_value is not None and "split" in frame:
            mask &= frame["split"].astype(str).eq(split_value)
        if date_min is not None and "date" in frame:
            mask &= pd.to_datetime(frame["date"], errors="coerce").ge(date_min)
        if mask.any():
            frames.append(frame.loc[mask].copy())
        del frame, mask
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=selected_columns)


def evaluate_rankings_compact(
    candidates: pd.DataFrame,
    cfg: dict[str, Any],
    probability_col: str,
) -> dict[str, Any]:
    """Compute manager-focused top-k metrics with one ranking pass."""
    lbl = label_column(cfg)
    pos = positive_label_value(cfg)
    label_population = labeled_population(candidates, lbl)
    positives = int(label_population[lbl].eq(pos).sum()) if not label_population.empty else 0
    eligible = candidates.loc[eligible_mask(candidates, cfg)].copy()
    eligible_counts = eligible.groupby(["store_id", "date"], sort=False).size()
    ranked20 = rank_store_day_alerts(eligible, cfg, probability_col=probability_col, max_alerts=20)
    ranked10 = ranked20.groupby(["store_id", "date"], sort=False).head(10) if not ranked20.empty else ranked20
    ranked5 = ranked20.groupby(["store_id", "date"], sort=False).head(5) if not ranked20.empty else ranked20
    p20 = precision_at_k_store_day(ranked20, lbl, pos, k=20)
    p10 = precision_at_k_store_day(ranked10, lbl, pos, k=10)
    p5 = precision_at_k_store_day(ranked5, lbl, pos, k=5)
    recall20 = recall_labeled(ranked20, label_population, lbl, pos)
    recall5 = recall_labeled(ranked5, label_population, lbl, pos)
    return {
        "synthetic_demo": bool(cfg.get("project", {}).get("synthetic_demo", False)),
        "scoring_time": cfg.get("features", {}).get("scoring_time", "start_of_day"),
        "evaluation_population": "all labeled rows in the chronological test window",
        "n_candidate_rows": int(len(candidates)),
        "n_labeled_rows": int(len(label_population)),
        "n_eligible_candidates": int(len(eligible)),
        "n_store_days_with_eligible_candidates": int(len(eligible_counts)),
        "max_eligible_candidates_per_store_day": int(eligible_counts.max()) if len(eligible_counts) else 0,
        "label_column": lbl,
        "k": 20,
        "precision_at_20": p20,
        "precision_at_10": p10,
        "precision_at_5": p5,
        "precision_at_budgets": {
            "precision_at_5": p5,
            "precision_at_10": p10,
            "precision_at_20": p20,
        },
        "recall": recall20,
        "recall_at_5": recall5,
        "f1_at_5": _f1_from_precision_recall(p5.get("micro_average"), recall5.get("recall")),
        "f1_at_20": _f1_from_precision_recall(p20.get("micro_average"), recall20.get("recall")),
        "max_alerts_per_store_day_observed": int(ranked20.groupby(["store_id", "date"]).size().max()) if not ranked20.empty else 0,
        "ranking_metrics_note": (
            "Precision@k reports selected-labeled and fixed-k denominator conventions. "
            "Precision@20 cannot compare ordering when fewer than 20 candidates qualify."
        ),
        "disclaimer": "Synthetic demonstration metrics only; not official competition results.",
    }


def run_evaluate(config_path: str | Path | None = None) -> dict[str, Any]:
    cfg = load_config(config_path)
    pred_dir = project_root() / cfg["paths"]["predictions_dir"]
    model_path = pred_dir / cfg["files"]["model_predictions"]
    base_path = pred_dir / cfg["files"]["baseline_predictions"]
    model_file = model_path if model_path.exists() else model_path.with_suffix(".csv")
    baseline_file = base_path if base_path.exists() else base_path.with_suffix(".csv")
    if model_file.exists() and baseline_file.exists():
        shared = [
            "date", "store_id", "sku_id", label_column(cfg), "sales", "sales_lag_1",
            "days_since_previous_observation", "on_hand",
            "expected_demand", "unit_price", "history_days",
            "positive_stock_zero_streak", "zero_sales_streak", "promo_flag",
        ]
        if model_file.suffix.lower() == ".parquet" and baseline_file.suffix.lower() == ".parquet":
            # Score one compact test panel at a time. Materializing the merged
            # 10.9M-row training/validation/test artifacts together can exceed
            # memory on a developer laptop.
            model_test = _read_parquet_selection(
                model_file, [*shared, "predicted_probability", "split"], split_value="test"
            )
            test_start = pd.to_datetime(model_test["date"], errors="coerce").min()
            test_end = pd.to_datetime(model_test["date"], errors="coerce").max()
            model_metrics = evaluate_rankings_compact(model_test, cfg, "predicted_probability")
            model_rows = len(model_test)
            del model_test
            gc.collect()

            baseline_test = _read_parquet_selection(
                baseline_file, [*shared, "baseline_score"], date_min=test_start
            )
            baseline_metrics = evaluate_rankings_compact(baseline_test, cfg, "baseline_score")
            baseline_rows = len(baseline_test)
            del baseline_test
            gc.collect()

            comparison = {
                "start_date": test_start.date().isoformat(),
                "end_date": test_end.date().isoformat(),
                "model_test_candidate_rows": int(model_rows),
                "baseline_test_candidate_rows": int(baseline_rows),
                "eligible_candidates": int(model_metrics.get("n_eligible_candidates", 0)),
                "store_days_with_eligible_candidates": int(model_metrics.get("precision_at_20", {}).get("n_store_days", 0)),
                "inspection_budget_per_store_day": 20,
                "store_days_reaching_budget": int(model_metrics.get("precision_at_20", {}).get("n_store_days", 0)),
                "max_eligible_candidates_per_store_day": int(model_metrics.get("max_eligible_candidates_per_store_day", 0)),
                "max_alerts_per_store_day": int(model_metrics.get("max_alerts_per_store_day_observed", 0)),
                "model": model_metrics,
                "baseline": baseline_metrics,
                "note": (
                    "Model and baseline metrics were computed in separate passes over the same chronological test dates. "
                    "The model purges boundary-crossing synthetic incidents while baseline candidates do not, so a matched-candidate score delta is not claimed."
                ),
            }
            payload = {
                "by_source": {"model": model_metrics, "baseline": baseline_metrics},
                "comparison": comparison,
                "test_candidate_rows": {"model": model_rows, "baseline": baseline_rows},
                "synthetic_demo": bool(cfg.get("project", {}).get("synthetic_demo", False)),
            }
            write_evaluation_report(model_metrics, cfg, comparison)
        else:
            payload = evaluate_model_vs_baseline(read_table(model_file), read_table(baseline_file), cfg)
            reports = payload["by_source"]
            write_evaluation_report(reports["model"], cfg, {
                **payload["comparison"],
                "model": reports["model"],
                "baseline": reports["baseline"],
            })
    elif model_file.exists():
        model_metrics = evaluate_predictions(_held_out_rows(read_table(model_file), cfg), cfg)
        payload = {
            "by_source": {"model": model_metrics},
            "comparison_note": "Baseline prediction file unavailable; a fair model comparison was not produced.",
            "synthetic_demo": bool(cfg.get("project", {}).get("synthetic_demo", False)),
        }
        write_evaluation_report(model_metrics, cfg)
    elif baseline_file.exists():
        baseline_metrics = evaluate_predictions(_held_out_rows(read_table(baseline_file), cfg), cfg, "baseline_score")
        payload = {
            "by_source": {"baseline": baseline_metrics},
            "comparison_note": "Model prediction file unavailable; a fair model comparison was not produced.",
            "synthetic_demo": bool(cfg.get("project", {}).get("synthetic_demo", False)),
        }
        write_evaluation_report(baseline_metrics, cfg)
    else:
        raise FileNotFoundError("No model or baseline prediction artifacts were found.")
    model_metrics = payload.get("by_source", {}).get("model")
    if model_metrics is not None:
        artifact_path = project_root() / cfg["files"]["model_artifact"]
        if artifact_path.exists():
            from src.model import load_artifact

            artifact = load_artifact(cfg)
            model_metrics["scores_calibrated"] = bool(
                artifact.get("train_result", {}).get("calibration", False)
            )
        else:
            model_metrics["scores_calibrated"] = False
    write_json(payload, project_root() / cfg["files"]["evaluation_json"])
    return payload


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run_evaluate()
