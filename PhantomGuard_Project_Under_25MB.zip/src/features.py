"""Leakage-safe, time-aware feature engineering."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from src.config import label_column, load_config, project_root
from src.io_utils import write_table
from src.prepare_data import load_master

LOGGER = logging.getLogger(__name__)

FEATURE_DICTIONARY: list[dict[str, str]] = [
    {"name": "sales_lag_1", "group": "demand", "description": "Sales on the previous observed day for the SKU-store."},
    {"name": "sales_lag_7", "group": "demand", "description": "Sales 7 observations earlier (panel lag, not calendar fill)."},
    {"name": "sales_lag_14", "group": "demand", "description": "Sales 14 observations earlier."},
    {"name": "sales_mean_7", "group": "demand", "description": "Mean of prior 7 sales observations (shifted)."},
    {"name": "sales_median_7", "group": "demand", "description": "Median of prior 7 sales observations (shifted)."},
    {"name": "sales_mean_28", "group": "demand", "description": "Mean of prior 28 sales observations (shifted)."},
    {"name": "sales_median_28", "group": "demand", "description": "Median of prior 28 sales observations (shifted)."},
    {"name": "sales_std_28", "group": "demand", "description": "Std of prior 28 sales observations (shifted)."},
    {"name": "positive_sales_days_28", "group": "demand", "description": "Count of prior 28 days with sales > 0."},
    {"name": "sales_velocity", "group": "demand", "description": "Prior 28-day mean sales (historical velocity)."},
    {"name": "demand_trend", "group": "demand", "description": "Recent 7-day mean minus prior 28-day mean."},
    {"name": "weekday_baseline", "group": "demand", "description": "Historical mean sales for the same weekday (expanding, shifted)."},
    {"name": "on_hand", "group": "inventory", "description": "System-recorded on-hand quantity at scoring time."},
    {"name": "positive_stock", "group": "inventory", "description": "1 if recorded on-hand > 0."},
    {"name": "zero_sales_streak", "group": "inventory", "description": "Consecutive zero-sales observations through scoring-time sales."},
    {"name": "positive_stock_zero_streak", "group": "inventory", "description": "Zero-sales streak while recorded inventory stayed positive."},
    {"name": "demand_deviation", "group": "inventory", "description": "Today or lagged sales minus expected demand, depending on scoring_time."},
    {"name": "recent_sales_decline", "group": "inventory", "description": "Prior 7-day mean relative to prior 28-day mean, inverted if declining."},
    {"name": "stock_to_demand_ratio", "group": "inventory", "description": "on_hand / expected demand; large when stock sits without movement."},
    {"name": "zero_sales_frequency_28", "group": "inventory", "description": "Fraction of prior 28 days with zero sales."},
    {"name": "demand_variability", "group": "inventory", "description": "Coefficient of variation of prior 28-day sales."},
    {"name": "expected_demand", "group": "inventory", "description": "Leakage-safe expected daily units from history."},
    {"name": "insufficient_history", "group": "inventory", "description": "1 if fewer than min_history_days of prior observations."},
    {"name": "dow", "group": "context", "description": "Day of week (0=Monday)."},
    {"name": "is_weekend", "group": "context", "description": "Weekend indicator."},
    {"name": "month", "group": "context", "description": "Calendar month."},
    {"name": "promo_flag", "group": "context", "description": "Promotion indicator if supplied."},
    {"name": "holiday_flag", "group": "context", "description": "Holiday indicator if supplied."},
    {"name": "promo_x_expected_demand", "group": "context", "description": "Promotion flag times expected demand."},
    {"name": "cross_store_sku_demand_lag1", "group": "cross_store", "description": "Previous-day mean sales of the SKU across stores."},
]


LABEL_LIKE = {
    "is_phantom",
    "label",
    "target",
    "y",
    "ground_truth",
    "hidden_label",
}


def feature_columns(df: pd.DataFrame, cfg: dict[str, Any] | None = None) -> list[str]:
    """Allowlist of model features; never includes identifiers or labels."""
    cfg = cfg or load_config()
    lbl = label_column(cfg)
    blocked = {
        "date",
        "store_id",
        "sku_id",
        "days_since_previous_observation",
        lbl,
        *LABEL_LIKE,
        "split",
        "reason",
        "recommended_action",
        "priority_score",
        "predicted_probability",
        "baseline_score",
        "baseline_reason",
        "model_name",
        "expected_daily_revenue_loss",
        "estimated_incident_revenue",
    }
    numeric_ok = []
    for col in df.columns:
        if col in blocked:
            continue
        if col in FEATURE_DICTIONARY_NAMES or col in {
            "store_size",
            "store_format_code",
            "city_tier_code",
            "history_days",
            "sales_used_for_streak",
        }:
            numeric_ok.append(col)
            continue
        if col.startswith("enc_"):
            numeric_ok.append(col)
    # Keep stable order.
    preferred = [row["name"] for row in FEATURE_DICTIONARY]
    ordered = [c for c in preferred if c in df.columns]
    extra = [c for c in numeric_ok if c not in ordered]
    return ordered + extra


FEATURE_DICTIONARY_NAMES = {row["name"] for row in FEATURE_DICTIONARY}


def _rolling_shifted(series: pd.Series, window: int, min_periods: int, func: str) -> pd.Series:
    shifted = series.shift(1)
    roll = shifted.rolling(window=window, min_periods=min_periods)
    return getattr(roll, func)()


def _streak_vectorized(flag: pd.Series, group_ids: pd.Series, dates: pd.Series | None = None) -> pd.Series:
    """Run length of True flags on consecutive calendar days within each SKU-store group."""
    reset = (~flag.fillna(False)) | (group_ids != group_ids.shift(1))
    if dates is not None:
        calendar_gap = dates.groupby(group_ids, sort=False).diff().dt.days
        reset |= calendar_gap.ne(1)
    grp = reset.cumsum()
    streak = flag.fillna(False).astype(int).groupby(grp).cumsum()
    streak = streak.where(flag.fillna(False), 0)
    return streak.astype(int)


def add_time_features(df: pd.DataFrame, scoring_time: str, min_history: int) -> pd.DataFrame:
    df = df.sort_values(["store_id", "sku_id", "date"]).copy()
    g = df.groupby(["store_id", "sku_id"], sort=False)
    sales = df["sales"]

    df["sales_lag_1"] = g["sales"].shift(1)
    df["days_since_previous_observation"] = g["date"].diff().dt.days
    df["sales_lag_7"] = g["sales"].shift(7)
    df["sales_lag_14"] = g["sales"].shift(14)
    df["sales_mean_7"] = g["sales"].transform(lambda s: _rolling_shifted(s, 7, 3, "mean"))
    df["sales_median_7"] = g["sales"].transform(lambda s: _rolling_shifted(s, 7, 3, "median"))
    df["sales_mean_28"] = g["sales"].transform(lambda s: _rolling_shifted(s, 28, 7, "mean"))
    df["sales_median_28"] = g["sales"].transform(lambda s: _rolling_shifted(s, 28, 7, "median"))
    df["sales_std_28"] = g["sales"].transform(lambda s: _rolling_shifted(s, 28, 7, "std"))
    pos = (df["sales"] > 0).astype(float)
    df["positive_sales_days_28"] = (
        pd.Series(pos, index=df.index).groupby([df["store_id"], df["sku_id"]]).transform(
            lambda s: s.shift(1).rolling(28, min_periods=7).sum()
        )
    )
    zero = (df["sales"] == 0) & df["sales"].notna()
    df["zero_sales_frequency_28"] = (
        pd.Series(zero.astype(float), index=df.index)
        .groupby([df["store_id"], df["sku_id"]])
        .transform(lambda s: s.shift(1).rolling(28, min_periods=7).mean())
    )
    df["sales_velocity"] = df["sales_mean_28"]
    df["demand_trend"] = df["sales_mean_7"] - df["sales_mean_28"]
    df["recent_sales_decline"] = np.where(
        df["sales_mean_28"].fillna(0) > 0,
        1.0 - (df["sales_mean_7"] / df["sales_mean_28"].replace(0, np.nan)),
        0.0,
    )

    df["history_days"] = g.cumcount()
    df["insufficient_history"] = (df["history_days"] < min_history).astype(int)

    df["dow"] = df["date"].dt.dayofweek
    df["is_weekend"] = (df["dow"] >= 5).astype(int)
    df["month"] = df["date"].dt.month

    # Expanding same-weekday baseline using only prior same weekdays.
    df["weekday_baseline"] = (
        df.groupby(["store_id", "sku_id", "dow"], sort=False)["sales"]
        .transform(lambda s: s.shift(1).expanding(min_periods=1).mean())
    )

    expected = df["sales_mean_28"].copy()
    expected = expected.fillna(df["sales_mean_7"])
    expected = expected.fillna(df["weekday_baseline"])
    df["expected_demand"] = expected.clip(lower=0)

    group_ids = df["store_id"].astype(str) + "||" + df["sku_id"].astype(str)
    if scoring_time == "start_of_day":
        sales_for_streak = g["sales"].shift(1)
        sales_for_streak = sales_for_streak.where(df["days_since_previous_observation"].eq(1))
        df["sales_used_for_streak"] = sales_for_streak
        zero_flag = (sales_for_streak == 0) & sales_for_streak.notna()
        df["demand_deviation"] = df["sales_lag_1"] - df["expected_demand"]
    else:
        df["sales_used_for_streak"] = df["sales"]
        zero_flag = (df["sales"] == 0) & df["sales"].notna()
        df["demand_deviation"] = df["sales"] - df["expected_demand"]

    df["zero_sales_streak"] = _streak_vectorized(zero_flag, group_ids, df["date"])
    pos_stock = (df["on_hand"] > 0) & df["on_hand"].notna()
    phantom_like = zero_flag & pos_stock
    df["positive_stock_zero_streak"] = _streak_vectorized(phantom_like, group_ids, df["date"])
    df["positive_stock"] = pos_stock.astype(int)

    denom = df["expected_demand"].replace(0, np.nan)
    df["stock_to_demand_ratio"] = df["on_hand"] / denom
    df["demand_variability"] = df["sales_std_28"] / denom
    df["promo_x_expected_demand"] = df.get("promo_flag", 0) * df["expected_demand"]

    sku_date = df.groupby(["sku_id", "date"], sort=False)["sales"].mean().rename("sku_cross_mean")
    sku_date = sku_date.reset_index().sort_values(["sku_id", "date"])
    sku_date["cross_store_sku_demand_lag1"] = sku_date.groupby("sku_id")["sku_cross_mean"].shift(1)
    df = df.merge(sku_date[["sku_id", "date", "cross_store_sku_demand_lag1"]], on=["sku_id", "date"], how="left")
    return df


def encode_categoricals(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for col, out in (("store_format", "store_format_code"), ("city_tier", "city_tier_code")):
        if col in df.columns:
            df[out] = pd.Categorical(df[col].astype(str)).codes
    return df


def build_features(df: pd.DataFrame, cfg: dict[str, Any] | None = None) -> pd.DataFrame:
    cfg = cfg or load_config()
    scoring_time = str(cfg.get("features", {}).get("scoring_time", "start_of_day"))
    min_history = int(cfg.get("features", {}).get("min_history_days", 14))
    LOGGER.info("Building features with scoring_time=%s min_history=%s", scoring_time, min_history)
    if scoring_time not in {"end_of_day", "start_of_day"}:
        raise ValueError("features.scoring_time must be 'end_of_day' or 'start_of_day'")
    out = add_time_features(df, scoring_time=scoring_time, min_history=min_history)
    out = encode_categoricals(out)
    return out


def save_feature_dictionary(path: Path | None = None) -> Path:
    root = project_root()
    path = path or (root / "reports" / "feature_dictionary.md")
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# Feature dictionary",
        "",
        "All historical aggregations are shifted so they use only information available",
        "before the current observation, except streak features which follow `scoring_time`.",
        "",
        "| Feature | Group | Description |",
        "|---|---|---|",
    ]
    for row in FEATURE_DICTIONARY:
        lines.append(f"| `{row['name']}` | {row['group']} | {row['description']} |")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def run_features(config_path: str | Path | None = None) -> Path:
    cfg = load_config(config_path)
    master = load_master(cfg)
    feats = build_features(master, cfg)
    out = write_table(feats, project_root() / cfg["paths"]["processed_dir"] / cfg["files"]["features"])
    # Streamlit needs a compact recent history for filters and charts; keeping
    # this separate avoids loading a multi-million-row feature matrix in the UI.
    dashboard_name = cfg.get("files", {}).get("dashboard_features")
    if dashboard_name:
        latest = pd.to_datetime(feats["date"]).max()
        recent = feats.loc[pd.to_datetime(feats["date"]) >= latest - pd.Timedelta(days=89)]
        display_columns = [
            "date", "store_id", "sku_id", "sales", "on_hand", "unit_price",
            "expected_demand", "sales_mean_7", "positive_stock_zero_streak",
            "zero_sales_streak", "history_days", "positive_sales_days_28",
            "promo_flag", "insufficient_history", "product_name", "Product Name", "Category",
        ]
        recent = recent[[c for c in display_columns if c in recent.columns]].copy()
        dashboard_out = write_table(
            recent,
            project_root() / cfg["paths"]["processed_dir"] / dashboard_name,
        )
        LOGGER.info("Wrote compact dashboard history (%s recent rows) to %s", len(recent), dashboard_out)
    save_feature_dictionary()
    LOGGER.info("Wrote features to %s", out)
    return out


def load_features(cfg: dict[str, Any] | None = None) -> pd.DataFrame:
    cfg = cfg or load_config()
    path = project_root() / cfg["paths"]["processed_dir"] / cfg["files"]["features"]
    csv_fallback = path.with_suffix(".csv")
    from src.io_utils import read_table

    if path.exists():
        return read_table(path)
    if csv_fallback.exists():
        return read_table(csv_fallback)
    raise FileNotFoundError("Features file not found. Run the features stage first.")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run_features()
