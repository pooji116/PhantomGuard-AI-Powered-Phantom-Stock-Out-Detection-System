"""Persistent store-manager inspection records for PhantomGuard alerts."""

from __future__ import annotations

import sqlite3
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

OUTCOMES = {
    "found_on_shelf": "Found on shelf",
    "found_in_backroom": "Found in backroom",
    "possible_misplaced": "Possible misplaced item",
    "not_found_either": "Not found in either location; investigation required",
    "inspection_incomplete": "Inspection incomplete",
    "checked_no_issue": "Checked; no issue found",
    "found_elsewhere": "Found elsewhere",
}


def _connect(db_path: str | Path) -> sqlite3.Connection:
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute(
        """CREATE TABLE IF NOT EXISTS inspections (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            alert_date TEXT NOT NULL,
            store_id TEXT NOT NULL,
            sku_id TEXT NOT NULL,
            outcome TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('pending', 'completed', 'awaiting investigation')),
            notes TEXT NOT NULL DEFAULT '',
            inspected_at TEXT NOT NULL
        )"""
    )
    conn.commit()
    return conn


def status_for_outcome(outcome: str) -> str:
    if outcome not in OUTCOMES:
        raise ValueError(f"Unsupported inspection outcome: {outcome}")
    if outcome == "inspection_incomplete":
        return "pending"
    if outcome in {"possible_misplaced", "not_found_either"}:
        return "awaiting investigation"
    return "completed"


def save_inspection(
    db_path: str | Path,
    alert_date: Any,
    store_id: str,
    sku_id: str,
    outcome: str,
    notes: str = "",
) -> int:
    """Save and commit an inspection, returning its persistent record ID."""
    if outcome not in OUTCOMES:
        raise ValueError(f"Unsupported inspection outcome: {outcome}")
    date_text = pd.Timestamp(alert_date).date().isoformat()
    with closing(_connect(db_path)) as conn:
        cursor = conn.execute(
            """INSERT INTO inspections
               (alert_date, store_id, sku_id, outcome, status, notes, inspected_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                date_text,
                str(store_id),
                str(sku_id),
                outcome,
                status_for_outcome(outcome),
                str(notes or "").strip(),
                datetime.now(timezone.utc).isoformat(timespec="seconds"),
            ),
        )
        conn.commit()
        record_id = int(cursor.lastrowid)
    return record_id


def list_inspections(db_path: str | Path) -> pd.DataFrame:
    """Return inspection history, newest first; an absent DB returns empty."""
    path = Path(db_path)
    if not path.exists():
        return pd.DataFrame(
            columns=["id", "alert_date", "store_id", "sku_id", "outcome", "status", "notes", "inspected_at"]
        )
    with closing(_connect(path)) as conn:
        rows = conn.execute("SELECT * FROM inspections ORDER BY inspected_at DESC, id DESC").fetchall()
    return pd.DataFrame([dict(row) for row in rows])


def latest_inspections(db_path: str | Path) -> pd.DataFrame:
    """Return only the latest saved result for each alert key."""
    history = list_inspections(db_path)
    if history.empty:
        return history
    return history.drop_duplicates(["alert_date", "store_id", "sku_id"], keep="first").reset_index(drop=True)

