"""Shared I/O, logging, and optional-dependency helpers."""

from __future__ import annotations

import json
import logging
import random
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

LOGGER = logging.getLogger(__name__)


def configure_logging(level: int = logging.INFO) -> None:
    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)


def try_import(module_name: str) -> Any | None:
    try:
        return __import__(module_name)
    except Exception as exc:  # noqa: BLE001 - optional dependency must not crash
        LOGGER.warning("Optional dependency '%s' is unavailable: %s", module_name, exc)
        return None


def read_table(path: Path) -> pd.DataFrame:
    """Read CSV, Parquet, or Excel based on suffix."""
    if not path.exists():
        raise FileNotFoundError(f"Input file not found: {path}")
    suffix = path.suffix.lower()
    if suffix in {".csv", ".txt"}:
        return pd.read_csv(path)
    if suffix in {".parquet", ".pq"}:
        return pd.read_parquet(path)
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(path)
    raise ValueError(f"Unsupported table format for {path}")


def write_table(df: pd.DataFrame, path: Path) -> Path:
    """Write Parquet when possible, otherwise CSV."""
    path.parent.mkdir(parents=True, exist_ok=True)
    suffix = path.suffix.lower()
    if suffix in {".parquet", ".pq"}:
        try:
            df.to_parquet(path, index=False)
            return path
        except Exception as exc:  # noqa: BLE001
            fallback = path.with_suffix(".csv")
            LOGGER.warning("Parquet write failed (%s); writing CSV to %s", exc, fallback)
            df.to_csv(fallback, index=False)
            return fallback
    df.to_csv(path, index=False)
    return path


def write_json(payload: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, default=str)


def discover_data_files(directory: Path) -> list[Path]:
    if not directory.exists():
        return []
    patterns = ("*.csv", "*.parquet", "*.pq", "*.xlsx", "*.xls", "*.json")
    found: list[Path] = []
    for pattern in patterns:
        found.extend(directory.glob(pattern))
    return sorted({p.resolve() for p in found})
