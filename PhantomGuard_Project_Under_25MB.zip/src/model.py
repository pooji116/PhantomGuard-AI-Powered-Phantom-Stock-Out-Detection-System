"""Supervised phantom-inventory models with chronological validation."""

from __future__ import annotations

import logging
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import average_precision_score, roc_auc_score

from src.baseline import score_baseline
from src.config import label_column, load_config, positive_label_value, project_root
from src.features import feature_columns, load_features
from src.io_utils import try_import, write_table
from src.rank_alerts import precision_at_k_store_day, rank_store_day_alerts

LOGGER = logging.getLogger(__name__)


@dataclass
class TrainResult:
    model_name: str
    n_features: int
    train_rows: int
    valid_rows: int
    train_start: str | None
    train_end: str | None
    valid_start: str | None
    valid_end: str | None
    average_precision: float | None
    roc_auc: float | None
    precision_at_20_macro: float | None
    calibration: bool
    synthetic_demo: bool
    feature_names: list[str]


def chronological_split(
    df: pd.DataFrame, cfg: dict[str, Any]
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split by date, never by random row shuffle."""
    splits = cfg.get("splits", {})
    dates = pd.to_datetime(df["date"]).sort_values().unique()
    if len(dates) < 3:
        raise ValueError("Need at least 3 distinct dates for a chronological split.")
    train_end = splits.get("train_end")
    valid_end = splits.get("valid_end")
    if train_end and valid_end:
        train_end_ts = pd.Timestamp(train_end)
        valid_end_ts = pd.Timestamp(valid_end)
    else:
        train_frac = float(splits.get("train_frac", 0.6))
        valid_frac = float(splits.get("valid_frac", 0.2))
        i_train = max(1, int(len(dates) * train_frac) - 1)
        i_valid = max(i_train + 1, int(len(dates) * (train_frac + valid_frac)) - 1)
        i_valid = min(i_valid, len(dates) - 2)
        train_end_ts = pd.Timestamp(dates[i_train])
        valid_end_ts = pd.Timestamp(dates[i_valid])
    d = pd.to_datetime(df["date"])
    train = df.loc[d <= train_end_ts].copy()
    valid = df.loc[(d > train_end_ts) & (d <= valid_end_ts)].copy()
    test = df.loc[d > valid_end_ts].copy()
    LOGGER.info(
        "Chronological split train<=%s (%s) valid<=%s (%s) test (%s)",
        train_end_ts.date(),
        len(train),
        valid_end_ts.date(),
        len(valid),
        len(test),
    )
    return train, valid, test


def purge_boundary_anomaly_events(
    df: pd.DataFrame, cfg: dict[str, Any], boundaries: tuple[pd.Timestamp, pd.Timestamp] | None = None
) -> tuple[pd.DataFrame, int]:
    """Remove entire contiguous labeled incidents that cross a split boundary."""
    lbl = label_column(cfg)
    if lbl not in df or df[lbl].notna().sum() == 0:
        return df.copy(), 0
    if boundaries is None:
        train, valid, _ = chronological_split(df, cfg)
        boundaries = (pd.to_datetime(train["date"]).max(), pd.to_datetime(valid["date"]).max())
    positive = df[lbl].eq(positive_label_value(cfg))
    ordered = df.loc[positive, ["store_id", "sku_id", "date"]].copy()
    ordered["date"] = pd.to_datetime(ordered["date"]).dt.normalize()
    ordered["_source_index"] = ordered.index
    ordered = ordered.sort_values(["store_id", "sku_id", "date"])
    drop_indices: set[int] = set()
    for (store, sku), group in ordered.groupby(["store_id", "sku_id"], sort=False):
        dates = group["date"]
        event_id = dates.diff().dt.days.ne(1).cumsum()
        for _, event in group.groupby(event_id, sort=False):
            start, end = event["date"].min(), event["date"].max()
            if any(start <= boundary < end for boundary in boundaries):
                drop_indices.update(event["_source_index"].astype(int).tolist())
    if not drop_indices:
        return df.copy(), 0
    LOGGER.warning("Purged %s positive rows belonging to boundary-crossing labeled events", len(drop_indices))
    return df.drop(index=list(drop_indices)).copy(), len(drop_indices)


def assign_chronological_split(df: pd.DataFrame, cfg: dict[str, Any]) -> pd.Series:
    """Tag rows by time split using boundaries derived from all observations."""
    train, valid, _ = chronological_split(df, cfg)
    if train.empty or valid.empty:
        raise ValueError("Cannot assign chronological splits with empty train/validation periods.")
    dates = pd.to_datetime(df["date"])
    train_end = pd.to_datetime(train["date"]).max()
    valid_end = pd.to_datetime(valid["date"]).max()
    return pd.Series(
        np.select([dates.le(train_end), dates.le(valid_end)], ["train", "validation"], default="test"),
        index=df.index,
        name="split",
    )


def _y(df: pd.DataFrame, cfg: dict[str, Any]) -> pd.Series:
    col = label_column(cfg)
    if col not in df.columns:
        raise ValueError(f"Label column '{col}' is required for training.")
    pos = positive_label_value(cfg)
    return (df[col] == pos).astype(int)


def matrix(df: pd.DataFrame, cfg: dict[str, Any], columns: list[str] | None = None) -> pd.DataFrame:
    cols = columns or feature_columns(df, cfg)
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise ValueError(f"Feature columns missing from frame: {missing}")
    X = df[cols].copy()
    label_hits = [c for c in X.columns if c in {label_column(cfg), "is_phantom", "label", "target"}]
    if label_hits:
        raise ValueError(f"Label leakage: {label_hits} present in feature matrix.")
    return X


def _available_estimators(cfg: dict[str, Any], seed: int) -> dict[str, Any]:
    requested = str(cfg.get("model", {}).get("type", "auto"))
    params = cfg.get("model", {})
    n_estimators = int(params.get("n_estimators", 150))
    max_depth = int(params.get("max_depth", 6))
    lr = float(params.get("learning_rate", 0.05))
    models: dict[str, Any] = {}

    lgb_mod = try_import("lightgbm") if cfg.get("optional_dependencies", {}).get("lightgbm", True) else None
    xgb_mod = try_import("xgboost") if cfg.get("optional_dependencies", {}).get("xgboost", True) else None

    if lgb_mod is not None and requested in {"auto", "lightgbm"}:
        models["lightgbm"] = lgb_mod.LGBMClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            learning_rate=lr,
            subsample=0.9,
            colsample_bytree=0.8,
            random_state=seed,
            class_weight="balanced",
            verbosity=-1,
        )
    if xgb_mod is not None and requested in {"auto", "xgboost"}:
        models["xgboost"] = xgb_mod.XGBClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            learning_rate=lr,
            subsample=0.9,
            colsample_bytree=0.8,
            random_state=seed,
            n_jobs=1,
            eval_metric="logloss",
            scale_pos_weight=1.0,
        )
    if requested in {"auto", "sklearn"} or not models:
        hgb_kwargs = dict(
            max_depth=max_depth,
            learning_rate=lr,
            max_iter=n_estimators,
            random_state=seed,
        )
        try:
            models["sklearn_hgb"] = HistGradientBoostingClassifier(
                class_weight="balanced",
                **hgb_kwargs,
            )
        except TypeError:
            models["sklearn_hgb"] = HistGradientBoostingClassifier(**hgb_kwargs)
    if requested not in {"auto", "lightgbm", "xgboost", "sklearn"}:
        raise ValueError(f"Unknown model.type: {requested}")
    if requested != "auto":
        key = "sklearn_hgb" if requested == "sklearn" else requested
        if key not in models:
            LOGGER.warning("Requested model %s unavailable; using sklearn_hgb.", requested)
            return {"sklearn_hgb": models["sklearn_hgb"]}
        return {key: models[key]}
    return models


def _predict_proba(est: Any, X: pd.DataFrame) -> np.ndarray:
    if hasattr(est, "predict_proba"):
        proba = est.predict_proba(X)
        if proba.ndim == 2 and proba.shape[1] == 2:
            return proba[:, 1]
        return proba.ravel()
    if hasattr(est, "decision_function"):
        scores = est.decision_function(X)
        return 1.0 / (1.0 + np.exp(-scores))
    raise TypeError("Estimator cannot produce probabilities.")


def _selection_score(df: pd.DataFrame, proba: np.ndarray, y: np.ndarray, cfg: dict[str, Any]) -> float:
    tmp = df.copy()
    tmp["predicted_probability"] = proba
    tmp["expected_daily_revenue_loss"] = tmp.get("expected_demand", 0).fillna(0) * tmp.get(
        "unit_price", pd.Series(1.0, index=tmp.index)
    ).fillna(1.0)
    ranked = rank_store_day_alerts(tmp, cfg, probability_col="predicted_probability")
    p20 = precision_at_k_store_day(ranked, y_col=_label_name(cfg), positive_value=positive_label_value(cfg))
    return float(p20["macro_average"])


def _label_name(cfg: dict[str, Any]) -> str:
    return label_column(cfg)


def train_models(df: pd.DataFrame, cfg: dict[str, Any] | None = None) -> tuple[Any, TrainResult, pd.DataFrame]:
    cfg = cfg or load_config()
    seed = int(cfg.get("project", {}).get("random_seed", 42))
    lbl = label_column(cfg)
    if lbl not in df.columns or df[lbl].notna().sum() == 0:
        raise ValueError("No labeled rows available for training.")
    # Establish time boundaries from the full observation panel, not only the
    # sparse labeled subset. Fit/select on authorized labels within those eras.
    period_train, period_valid, period_test = chronological_split(df, cfg)
    boundaries = (pd.to_datetime(period_train["date"]).max(), pd.to_datetime(period_valid["date"]).max())
    clean, _ = purge_boundary_anomaly_events(df, cfg, boundaries)
    period_train, period_valid, period_test = chronological_split(clean, cfg)
    train = period_train.loc[period_train[lbl].notna()].copy()
    valid = period_valid.loc[period_valid[lbl].notna()].copy()
    if train.empty or valid.empty:
        raise ValueError("Train or validation split is empty after chronological cut.")

    # Large demo panels can contain millions of training rows. A reproducible
    # stratified sample bounds fitting time while leaving validation and the
    # final chronological test period untouched and at full size.
    train_cap = int(cfg.get("model", {}).get("max_training_rows", 0) or 0)
    if train_cap > 0 and len(train) > train_cap:
        rng = np.random.default_rng(seed)
        y_all = _y(train, cfg)
        pos_idx = train.index[y_all.eq(1)].to_numpy()
        neg_idx = train.index[y_all.eq(0)].to_numpy()
        pos_n = min(len(pos_idx), max(1, int(round(train_cap * len(pos_idx) / len(train)))))
        neg_n = min(len(neg_idx), train_cap - pos_n)
        selected = np.concatenate([
            rng.choice(pos_idx, size=pos_n, replace=False),
            rng.choice(neg_idx, size=neg_n, replace=False),
        ])
        train = train.loc[np.sort(selected)].copy()
        LOGGER.info("Stratified training sample: %s rows from %s labeled training rows", len(train), len(pos_idx) + len(neg_idx))

    feat_names = feature_columns(train, cfg)
    X_train, y_train = matrix(train, cfg, feat_names), _y(train, cfg)
    X_valid, y_valid = matrix(valid, cfg, feat_names), _y(valid, cfg)

    if y_train.sum() == 0:
        raise ValueError("Training split contains no positive labels.")
    if y_train.nunique() < 2:
        raise ValueError("Training split must contain both positive and negative labels.")

    pos = max(int(y_train.sum()), 1)
    neg = max(int((1 - y_train).sum()), 1)
    scale_pos = neg / pos

    estimators = _available_estimators(cfg, seed)
    best_name = None
    best_est = None
    best_score = -1.0
    metrics_by_model: dict[str, dict[str, float | None]] = {}
    calibration_by_model: dict[str, bool] = {}

    for name, est in estimators.items():
        if name == "xgboost" and hasattr(est, "set_params"):
            est.set_params(scale_pos_weight=scale_pos)
        LOGGER.info("Fitting %s on %s rows / %s features", name, len(X_train), len(feat_names))
        calibrate = bool(cfg.get("model", {}).get("calibrate", True)) and y_train.nunique() > 1
        if calibrate:
            # Calibrate entirely inside the training window. Validation labels
            # remain reserved for model selection and reporting.
            fitted: Any = CalibratedClassifierCV(estimator=est, method="sigmoid", cv=3)
            try:
                fitted.fit(X_train, y_train)
                calibration_by_model[name] = True
            except (ValueError, TypeError) as exc:
                LOGGER.warning("Calibration unavailable for %s; using uncalibrated estimator: %s", name, exc)
                est.fit(X_train, y_train)
                fitted = est
                calibration_by_model[name] = False
        else:
            est.fit(X_train, y_train)
            fitted = est
            calibration_by_model[name] = False
        proba = _predict_proba(fitted, X_valid)
        ap = float(average_precision_score(y_valid, proba)) if y_valid.nunique() > 1 else None
        try:
            auc = float(roc_auc_score(y_valid, proba)) if y_valid.nunique() > 1 else None
        except ValueError:
            auc = None
        p20 = _selection_score(valid.assign(**{lbl: valid[lbl]}), proba, y_valid.to_numpy(), cfg)
        metrics_by_model[name] = {"average_precision": ap, "roc_auc": auc, "precision_at_20_macro": p20}
        LOGGER.info("%s validation AP=%s P@20(macro)=%s", name, ap, p20)
        if p20 > best_score:
            best_score = p20
            best_name = name
            best_est = fitted

    assert best_est is not None and best_name is not None
    valid_proba = _predict_proba(best_est, X_valid)
    result = TrainResult(
        model_name=best_name,
        n_features=len(feat_names),
        train_rows=len(train),
        valid_rows=len(valid),
        train_start=str(pd.to_datetime(train["date"]).min().date()),
        train_end=str(pd.to_datetime(train["date"]).max().date()),
        valid_start=str(pd.to_datetime(valid["date"]).min().date()),
        valid_end=str(pd.to_datetime(valid["date"]).max().date()),
        average_precision=metrics_by_model[best_name]["average_precision"],
        roc_auc=metrics_by_model[best_name]["roc_auc"],
        precision_at_20_macro=metrics_by_model[best_name]["precision_at_20_macro"],
        calibration=calibration_by_model[best_name],
        synthetic_demo=bool(cfg.get("project", {}).get("synthetic_demo", False)),
        feature_names=feat_names,
    )
    artifact = {
        "estimator": best_est,
        "feature_names": feat_names,
        "train_result": asdict(result),
        "metrics_by_model": metrics_by_model,
        "label_column": lbl,
        "seed": seed,
        "scoring_time": cfg.get("features", {}).get("scoring_time"),
    }
    model_path = project_root() / cfg["files"]["model_artifact"]
    model_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(artifact, model_path)
    LOGGER.info("Saved model artifact to %s (selected=%s by precision@20)", model_path, best_name)

    score_columns = [
        "date", "store_id", "sku_id", lbl, "sales", "sales_lag_1",
        "days_since_previous_observation", "on_hand", "unit_price",
        "expected_demand", "history_days", "positive_stock_zero_streak",
        "zero_sales_streak", "promo_flag", "sales_velocity", "sales_mean_7",
        "positive_sales_days_28", "baseline_score", "baseline_reason",
        "baseline_eligible", "product_name", "Product Name", "Category",
    ]
    scored = clean[[column for column in score_columns if column in clean.columns]].copy()
    scored_probability = np.empty(len(clean), dtype=np.float32)
    infer_chunk = int(cfg.get("model", {}).get("inference_chunk_rows", 200000))
    for start in range(0, len(clean), infer_chunk):
        end = min(start + infer_chunk, len(clean))
        scored_probability[start:end] = _predict_proba(best_est, matrix(clean.iloc[start:end], cfg, feat_names))
    scored["predicted_probability"] = scored_probability
    scored["model_name"] = best_name
    scored["split"] = assign_chronological_split(clean, cfg)
    return best_est, result, scored


def optional_shap_values(estimator: Any, X: pd.DataFrame) -> Any | None:
    """Return SHAP values when the optional package and estimator support it."""
    shap_mod = try_import("shap")
    if shap_mod is None:
        return None
    try:
        explainer = shap_mod.Explainer(estimator, X.head(min(100, len(X))))
        return explainer(X.head(min(50, len(X))))
    except Exception as exc:  # noqa: BLE001
        LOGGER.warning("SHAP explanation unavailable: %s", exc)
        return None


def load_artifact(cfg: dict[str, Any] | None = None) -> dict[str, Any]:
    cfg = cfg or load_config()
    path = project_root() / cfg["files"]["model_artifact"]
    if not path.exists():
        raise FileNotFoundError(f"Model artifact not found: {path}")
    return joblib.load(path)


def predict_without_labels(df: pd.DataFrame, cfg: dict[str, Any] | None = None) -> pd.DataFrame:
    """Score rows using a persisted model. Labels are not required."""
    cfg = cfg or load_config()
    artifact = load_artifact(cfg)
    feat_names = artifact["feature_names"]
    X = matrix(df, cfg, feat_names)
    out = df.copy()
    out["predicted_probability"] = _predict_proba(artifact["estimator"], X)
    out["model_name"] = artifact["train_result"]["model_name"]
    return out


def run_train(config_path: str | Path | None = None) -> Path:
    cfg = load_config(config_path)
    feats = load_features(cfg)
    feats = score_baseline(feats, cfg)
    _, result, scored = train_models(feats, cfg)
    keep_extra = ["predicted_probability", "model_name", "baseline_score", "baseline_reason", "baseline_eligible", "split"]
    required_for_rank_and_eval = {
        "date", "store_id", "sku_id", label_column(cfg), "sales", "sales_lag_1",
        "days_since_previous_observation", "on_hand",
        "expected_demand", "unit_price", "history_days", "positive_stock_zero_streak",
        "zero_sales_streak", "promo_flag", "sales_velocity", "sales_mean_7",
        "positive_sales_days_28", "product_name", "Product Name", "Category",
        *keep_extra,
    }
    cols = [c for c in scored.columns if c in required_for_rank_and_eval]
    out = write_table(
        scored[cols],
        project_root() / cfg["paths"]["predictions_dir"] / cfg["files"]["model_predictions"],
    )
    LOGGER.info("Training complete: %s", asdict(result))
    return out


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run_train()
