"""Ingest, validate, join, and persist the PhantomGuard master dataset."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from src.config import get_column_map, label_column, load_config, project_root
from src.io_utils import discover_data_files, read_table, write_json, write_table

LOGGER = logging.getLogger(__name__)

REQUIRED_CANONICAL = ("date", "store_id", "sku_id", "sales", "on_hand")


class DuplicateKeyError(ValueError):
    """Raised when SKU-store-date keys conflict with different values."""


def _cfg_path(cfg: dict[str, Any], key: str) -> Path:
    rel = cfg["paths"][key]
    return project_root() / rel


def _source_path(cfg: dict[str, Any], file_key: str) -> Path:
    return _cfg_path(cfg, "raw_dir") / cfg["files"][file_key]


COMMON_COLUMN_ALIASES: dict[str, tuple[str, ...]] = {
    "date": ("date", "dt", "day", "transaction_date"),
    "store_id": ("store_id", "store", "store id", "store_code", "location_id"),
    "sku_id": ("sku_id", "sku", "product_id", "product id", "item_id", "item id", "article_id"),
    "sales": ("sales", "units_sold", "units sold", "quantity_sold", "qty_sold", "demand", "volume"),
    "on_hand": ("on_hand", "inventory_level", "inventory level", "stock", "stock_on_hand", "soh", "current_inventory", "inventory"),
    "unit_price": ("unit_price", "price", "unit price", "selling_price", "retail_price"),
    "promo_flag": ("promo_flag", "promotion", "promo", "is_promo", "promotion_flag"),
}


def remap_columns(df: pd.DataFrame, mapping: dict[str, str]) -> pd.DataFrame:
    """Rename configured source columns onto canonical names when present."""
    rename = {src: canon for canon, src in mapping.items() if src in df.columns and src != canon}
    normalized_cols = {col.lower().replace("_", "").replace(" ", ""): col for col in df.columns}
    for canon, configured_src in mapping.items():
        if canon not in rename.values() and canon not in df.columns:
            conf_norm = configured_src.lower().replace("_", "").replace(" ", "")
            if conf_norm in normalized_cols:
                rename[normalized_cols[conf_norm]] = canon
                continue
            aliases = COMMON_COLUMN_ALIASES.get(canon, ())
            for alias in aliases:
                norm_alias = alias.lower().replace("_", "").replace(" ", "")
                if norm_alias in normalized_cols:
                    rename[normalized_cols[norm_alias]] = canon
                    break
    out = df.rename(columns=rename).copy()
    return out


def parse_dates(df: pd.DataFrame, date_format: str | None) -> pd.DataFrame:
    if "date" not in df.columns:
        return df
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"], format=date_format, errors="coerce")
    bad = int(df["date"].isna().sum())
    if bad:
        LOGGER.warning("Dropped %s rows with unparseable dates", bad)
        df = df.loc[df["date"].notna()].copy()
    df["date"] = df["date"].dt.normalize()
    return df


def coerce_numeric(df: pd.DataFrame, columns: tuple[str, ...]) -> pd.DataFrame:
    df = df.copy()
    for col in columns:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


def validate_required(df: pd.DataFrame, required: tuple[str, ...] = REQUIRED_CANONICAL) -> None:
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(
            "Required columns missing after mapping: "
            f"{missing}. Present columns: {list(df.columns)}"
        )


def _identical_duplicates(df: pd.DataFrame, keys: list[str]) -> pd.Series:
    return df.duplicated(keep=False) & df.duplicated(subset=keys, keep=False)


def resolve_duplicates(df: pd.DataFrame, keys: list[str], policy: str) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Drop identical duplicate rows; fail (default) on conflicting keys."""
    diag: dict[str, Any] = {"duplicate_key_rows": 0, "identical_dropped": 0, "conflicting_keys": 0}
    if df.empty:
        return df, diag
    dup_mask = df.duplicated(subset=keys, keep=False)
    diag["duplicate_key_rows"] = int(dup_mask.sum())
    if not dup_mask.any():
        return df.reset_index(drop=True), diag

    identical = df.duplicated(keep="first") & df.duplicated(subset=keys, keep="first")
    # Drop fully identical rows first.
    before = len(df)
    df = df.drop_duplicates(keep="first")
    diag["identical_dropped"] = before - len(df)

    still = df.duplicated(subset=keys, keep=False)
    diag["conflicting_keys"] = int(df.loc[still, keys].drop_duplicates().shape[0])
    if still.any():
        sample = df.loc[still, keys].drop_duplicates().head(10)
        msg = (
            "Conflicting duplicate SKU-store-date keys detected. "
            "PhantomGuard will not silently keep one version. "
            f"Conflicting key sample:\n{sample.to_string(index=False)}"
        )
        if policy != "fail":
            LOGGER.warning("%s Policy=%s; keeping first occurrence.", msg, policy)
            df = df.drop_duplicates(subset=keys, keep="first")
        else:
            raise DuplicateKeyError(msg)
    return df.reset_index(drop=True), diag


def join_with_cardinality_check(
    left: pd.DataFrame,
    right: pd.DataFrame,
    on: list[str],
    how: str,
    name: str,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    before = len(left)
    merged = left.merge(right, on=on, how=how, suffixes=("", f"_{name}"))
    after = len(merged)
    left_match = left[on].merge(right[on].drop_duplicates(), on=on, how="left", indicator=True)
    right_match = right[on].merge(left[on].drop_duplicates(), on=on, how="left", indicator=True)
    diag = {
        "join": name,
        "on": on,
        "how": how,
        "left_rows": before,
        "right_rows": len(right),
        "result_rows": after,
        "row_multiplication": after > before,
        "unmatched_left": int(left_match["_merge"].eq("left_only").sum()),
        "unmatched_right": int(right_match["_merge"].eq("left_only").sum()),
    }
    if after > before:
        LOGGER.warning(
            "Join '%s' increased row count from %s to %s. Check cardinality of %s.",
            name,
            before,
            after,
            on,
        )
    return merged, diag


def gap_report(df: pd.DataFrame) -> dict[str, Any]:
    """Report missing dates inside each SKU-store min/max window without filling them."""
    if df.empty:
        return {"series_with_gaps": 0, "missing_days_total": 0}
    grouped = df.groupby(["store_id", "sku_id"], sort=False)["date"]
    missing_total = 0
    series_with_gaps = 0
    examples: list[dict[str, Any]] = []
    for (store, sku), dates in grouped:
        dates = dates.sort_values().drop_duplicates()
        expected = (dates.max() - dates.min()).days + 1
        actual = int(dates.nunique())
        missing = expected - actual
        if missing > 0:
            series_with_gaps += 1
            missing_total += int(missing)
            if len(examples) < 8:
                examples.append(
                    {
                        "store_id": store,
                        "sku_id": sku,
                        "missing_days": int(missing),
                        "span_days": int(expected),
                    }
                )
    return {
        "series_with_gaps": series_with_gaps,
        "missing_days_total": missing_total,
        "examples": examples,
        "fill_policy": "absent rows are NOT treated as zero sales",
    }


def load_optional_table(path: Path) -> pd.DataFrame | None:
    if not path.exists():
        LOGGER.info("Optional source not found: %s", path)
        return None
    return read_table(path)


def build_master(cfg: dict[str, Any] | None = None) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Load configured sources, clean, join, and return the master panel."""
    cfg = cfg or load_config()
    mapping = get_column_map(cfg)
    date_fmt = cfg.get("date", {}).get("format") or None
    raw_dir = _cfg_path(cfg, "raw_dir")
    discovered = discover_data_files(raw_dir)
    report: dict[str, Any] = {
        "discovered_files": [str(p) for p in discovered],
        "synthetic_demo": bool(cfg.get("project", {}).get("synthetic_demo", False)),
        "joins": [],
        "warnings": [],
    }

    sales_path = _source_path(cfg, "sales")
    inventory_path = _source_path(cfg, "inventory")
    if not sales_path.exists() or not inventory_path.exists():
        raise FileNotFoundError(
            "Required sales and inventory files were not found in data/raw/. "
            "Place organizer files there or run: python scripts/generate_demo_data.py. "
            f"Looked for {sales_path.name} and {inventory_path.name}."
        )

    raw_sales = read_table(sales_path)
    raw_sales_mapped = remap_columns(raw_sales, mapping)
    raw_date_count = int(raw_sales_mapped["date"].notna().sum()) if "date" in raw_sales_mapped else 0
    sales = parse_dates(raw_sales_mapped, date_fmt)
    report["sales_source_validation"] = {
        "rows_read": int(len(raw_sales)),
        "invalid_or_missing_dates_dropped": int(len(raw_sales) - len(sales)),
        "missing_by_column": {str(c): int(n) for c, n in raw_sales.isna().sum().items() if n},
        "date_rows_before_parse": raw_date_count,
    }
    if sales_path.resolve() == inventory_path.resolve():
        # Some providers supply a single fact table containing both units sold
        # and the stock snapshot. Keep one untouched source and avoid a
        # many-to-many self-join on its daily SKU-store key.
        inventory = sales[[c for c in ["date", "store_id", "sku_id", "on_hand"] if c in sales.columns]].copy()
        report["input_layout"] = "combined sales and inventory panel"
    else:
        inventory = remap_columns(parse_dates(read_table(inventory_path), date_fmt), mapping)
        report["input_layout"] = "separate sales and inventory tables"

    sales = coerce_numeric(sales, ("sales", "unit_price", "margin", "promo_flag", "holiday_flag"))
    inventory = coerce_numeric(inventory, ("on_hand",))
    report["sales_source_validation"]["invalid_numeric_values"] = {
        col: int(sales[col].isna().sum()) for col in ("sales", "on_hand", "unit_price") if col in sales
    }

    keys = ["date", "store_id", "sku_id"]
    for frame, name in ((sales, "sales"), (inventory, "inventory")):
        missing_ids = frame[keys].isna().any(axis=1)
        if missing_ids.any():
            LOGGER.warning("Dropping %s %s rows with missing key fields", int(missing_ids.sum()), name)
            if name == "sales":
                sales = sales.loc[~missing_ids].copy()
            else:
                inventory = inventory.loc[~missing_ids].copy()

    policy = str(cfg.get("duplicates", {}).get("policy", "fail"))
    sales, sales_dup = resolve_duplicates(sales, keys, policy)
    inventory, inv_dup = resolve_duplicates(inventory, keys, policy)
    report["sales_duplicates"] = sales_dup
    report["inventory_duplicates"] = inv_dup

    inv_cols = [c for c in ["date", "store_id", "sku_id", "on_hand"] if c in inventory.columns]
    master, join_diag = join_with_cardinality_check(sales, inventory[inv_cols], keys, "outer", "inventory")
    report["joins"].append(join_diag)

    promotions = load_optional_table(_source_path(cfg, "promotions"))
    if promotions is not None:
        promotions = remap_columns(parse_dates(promotions, date_fmt), mapping)
        promo_keys = [c for c in keys if c in promotions.columns]
        if "promo_flag" in promotions.columns and set(promo_keys) == set(keys):
            promotions, _ = resolve_duplicates(promotions[promo_keys + ["promo_flag"]], keys, policy)
            master, d = join_with_cardinality_check(
                master, promotions[keys + ["promo_flag"]], keys, "left", "promotions"
            )
            report["joins"].append(d)
        elif {"sku_id", "start_date", "end_date"}.issubset(promotions.columns):
            promotions["start_date"] = pd.to_datetime(promotions["start_date"], errors="coerce")
            promotions["end_date"] = pd.to_datetime(promotions["end_date"], errors="coerce")
            master = _apply_promo_windows(master, promotions)
            report["joins"].append({"join": "promotions_windows", "right_rows": len(promotions)})

    stores = load_optional_table(_source_path(cfg, "stores"))
    if stores is not None:
        stores = remap_columns(stores, mapping)
        keep = [c for c in ["store_id", "store_size", "store_format", "city_tier"] if c in stores.columns]
        stores = stores[keep].drop_duplicates(subset=["store_id"])
        master, d = join_with_cardinality_check(master, stores, ["store_id"], "left", "stores")
        report["joins"].append(d)

    labels_path = _source_path(cfg, "labels")
    labels = load_optional_table(labels_path)
    lbl = label_column(cfg)
    if labels is not None:
        labels = remap_columns(parse_dates(labels, date_fmt), mapping)
        if lbl not in labels.columns and "label" in labels.columns:
            labels = labels.rename(columns={mapping["label"]: lbl})
        if set(keys).issubset(labels.columns) and lbl in labels.columns:
            labels, _ = resolve_duplicates(labels[keys + [lbl]], keys, policy)
            master, d = join_with_cardinality_check(master, labels[keys + [lbl]], keys, "left", "labels")
            report["joins"].append(d)
            report["labels_available"] = True
        else:
            report["labels_available"] = False
            report["warnings"].append("Labels file found but missing expected keys/column.")
    else:
        report["labels_available"] = False
        LOGGER.info("No labels file found; inference/training labels will be absent.")

    if "promo_flag" not in master.columns:
        master["promo_flag"] = 0
    if "holiday_flag" not in master.columns:
        master["holiday_flag"] = 0
    master["promo_flag"] = pd.to_numeric(master["promo_flag"], errors="coerce").fillna(0).astype(int)
    master["holiday_flag"] = pd.to_numeric(master["holiday_flag"], errors="coerce").fillna(0).astype(int)

    validate_required(master, ("date", "store_id", "sku_id"))
    master["store_id"] = master["store_id"].astype(str)
    master["sku_id"] = master["sku_id"].astype(str)
    master = coerce_numeric(master, ("sales", "on_hand", "unit_price", "store_size", "margin"))

    invalid = {
        "negative_sales": int((master.get("sales", 0) < 0).sum()) if "sales" in master.columns else 0,
        "negative_on_hand": int((master.get("on_hand", 0) < 0).sum()) if "on_hand" in master.columns else 0,
    }
    report["invalid_values"] = invalid
    if invalid["negative_sales"]:
        LOGGER.warning("Found %s negative sales values; setting them to NA.", invalid["negative_sales"])
        master.loc[master["sales"] < 0, "sales"] = np.nan
    if invalid["negative_on_hand"]:
        LOGGER.warning("Found %s negative on-hand values; setting them to NA.", invalid["negative_on_hand"])
        master.loc[master["on_hand"] < 0, "on_hand"] = np.nan

    master, key_dup = resolve_duplicates(master, keys, policy)
    report["master_duplicates"] = key_dup

    master = master.sort_values(keys).reset_index(drop=True)
    if master.duplicated(subset=keys).any():
        raise DuplicateKeyError("Master dataset key date+store_id+sku_id is not unique after processing.")

    report["row_count"] = int(len(master))
    report["n_stores"] = int(master["store_id"].nunique())
    report["n_skus"] = int(master["sku_id"].nunique())
    report["n_store_sku_combinations"] = int(master[["store_id", "sku_id"]].drop_duplicates().shape[0])
    report["date_min"] = str(master["date"].min().date()) if len(master) else None
    report["date_max"] = str(master["date"].max().date()) if len(master) else None
    report["missingness"] = {
        col: int(master[col].isna().sum()) for col in ["sales", "on_hand", "unit_price"] if col in master.columns
    }
    report["gaps"] = gap_report(master)
    report["missing_vs_zero_sales"] = {
        "null_sales_rows": int(master["sales"].isna().sum()) if "sales" in master.columns else 0,
        "zero_sales_rows": int((master["sales"] == 0).sum()) if "sales" in master.columns else 0,
        "note": "Null sales mean the observation is missing, not a recorded zero.",
    }
    report["signal_support"] = {
        "positive_stock_zero_sales_rows": int(((master["sales"] == 0) & (master["on_hand"] > 0)).sum()),
        "note": "Rows with no sales and positive stock are required for the core phantom-stock signal; this count is descriptive, not ground truth.",
    }

    fill = bool(cfg.get("missing_dates", {}).get("fill_as_zero_sales", False))
    if fill:
        LOGGER.warning("fill_as_zero_sales is enabled; absent days will be inserted as sales=0.")
        master = _fill_calendar(master)
        report["warnings"].append("Absent SKU-store-days were filled as zero sales by configuration.")
    else:
        report["warnings"].append(
            "Calendar gaps were reported but not filled. Absent rows are not treated as zero sales."
        )

    return master, report


def _apply_promo_windows(master: pd.DataFrame, promotions: pd.DataFrame) -> pd.DataFrame:
    master = master.copy()
    if "promo_flag" in master:
        master["promo_flag"] = pd.to_numeric(master["promo_flag"], errors="coerce").fillna(0).to_numpy()
    else:
        master["promo_flag"] = 0
    # The old implementation scanned the entire fact table for every window.
    # Group once by SKU (and store where needed), then compare only that
    # segment's dates. This keeps organizer-size calendars tractable.
    date_values = pd.to_datetime(master["date"], errors="coerce").to_numpy(dtype="datetime64[ns]")
    promo_values = master["promo_flag"].to_numpy(copy=True)
    global_windows = promotions.loc[promotions.get("store_id", pd.Series(index=promotions.index, dtype=object)).isna()]
    scoped_windows = promotions.loc[promotions.get("store_id", pd.Series(index=promotions.index, dtype=object)).notna()]

    if not global_windows.empty:
        rows_by_sku = master.groupby("sku_id", sort=False, observed=True).indices
        for sku, windows in global_windows.groupby("sku_id", sort=False):
            positions = rows_by_sku.get(sku)
            if positions is None:
                continue
            dates = date_values[positions]
            for window in windows.itertuples(index=False):
                start = np.datetime64(window.start_date) if pd.notna(window.start_date) else dates.min()
                end = np.datetime64(window.end_date) if pd.notna(window.end_date) else dates.max()
                promo_values[positions[(dates >= start) & (dates <= end)]] = 1

    if not scoped_windows.empty:
        rows_by_pair = master.groupby(["store_id", "sku_id"], sort=False, observed=True).indices
        for (store, sku), windows in scoped_windows.groupby(["store_id", "sku_id"], sort=False):
            positions = rows_by_pair.get((store, sku))
            if positions is None:
                continue
            dates = date_values[positions]
            for window in windows.itertuples(index=False):
                start = np.datetime64(window.start_date) if pd.notna(window.start_date) else dates.min()
                end = np.datetime64(window.end_date) if pd.notna(window.end_date) else dates.max()
                promo_values[positions[(dates >= start) & (dates <= end)]] = 1

    master["promo_flag"] = promo_values
    return master


def _fill_calendar(master: pd.DataFrame) -> pd.DataFrame:
    pieces = []
    for (store, sku), g in master.groupby(["store_id", "sku_id"], sort=False):
        idx = pd.date_range(g["date"].min(), g["date"].max(), freq="D")
        g = g.set_index("date").reindex(idx)
        g.index.name = "date"
        g["store_id"] = store
        g["sku_id"] = sku
        g["sales"] = g["sales"].fillna(0)
        pieces.append(g.reset_index())
    return pd.concat(pieces, ignore_index=True) if pieces else master


def save_master(master: pd.DataFrame, report: dict[str, Any], cfg: dict[str, Any] | None = None) -> Path:
    cfg = cfg or load_config()
    processed = _cfg_path(cfg, "processed_dir")
    out = write_table(master, processed / cfg["files"]["master"])
    write_json(report, processed / cfg["files"]["quality_report"])
    LOGGER.info("Wrote master dataset to %s (%s rows)", out, len(master))
    return out


def load_master(cfg: dict[str, Any] | None = None) -> pd.DataFrame:
    cfg = cfg or load_config()
    processed = _cfg_path(cfg, "processed_dir")
    path = processed / cfg["files"]["master"]
    csv_fallback = path.with_suffix(".csv")
    if path.exists():
        return read_table(path)
    if csv_fallback.exists():
        return read_table(csv_fallback)
    raise FileNotFoundError(
        f"Processed master not found at {path} or {csv_fallback}. Run prepare_data first."
    )


def run_prepare(config_path: str | Path | None = None) -> Path:
    cfg = load_config(config_path)
    master, report = build_master(cfg)
    return save_master(master, report, cfg)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run_prepare()
