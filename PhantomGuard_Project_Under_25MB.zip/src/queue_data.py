"""Shared, testable rules for assembling a store-day alert queue."""

from __future__ import annotations

from datetime import date
from typing import Any, Mapping

import numpy as np
import pandas as pd

from src.analytics_engine import OperationalLeakClassifier
from src.config import load_config

QUEUE_KEY = ["date", "store_id", "sku_id"]
INVENTORY_TIMESTAMP_COLUMNS = (
    "inventory_updated_at",
    "inventory_snapshot_at",
    "snapshot_at",
    "updated_at",
    "recorded_at",
    "ingested_at",
)


def filter_store_day(frame: pd.DataFrame, store_id: str, business_date: date | str) -> pd.DataFrame:
    """Select only the requested store and business date."""
    if frame.empty:
        return frame.copy()
    missing = [column for column in QUEUE_KEY if column not in frame.columns]
    if missing:
        raise ValueError(f"Daily queue data is missing key columns: {missing}")

    target_date = pd.Timestamp(business_date).date()
    dates = pd.to_datetime(frame["date"], errors="coerce").dt.date
    mask = frame["store_id"].astype(str).eq(str(store_id)) & dates.eq(target_date)
    selected = frame.loc[mask].copy()
    selected["date"] = pd.to_datetime(selected["date"], errors="coerce").dt.date
    return selected


def deduplicate_daily_rows(frame: pd.DataFrame, *, ranked: bool = False) -> pd.DataFrame:
    """Keep one record per date/store/SKU before applying the daily budget.

    An explicit inventory snapshot/update timestamp is authoritative; the newest
    timestamp wins. Ties use the best existing model rank, then highest model
    priority score. When timestamps are absent, ranked artifacts use that same
    rank/score tie-break; unranked source exports retain their last occurrence,
    which is the latest exported snapshot by source order. The selected row is
    kept intact so its stock, sales evidence, and explanation stay together.
    """
    if frame.empty:
        return frame.copy()
    missing = [column for column in QUEUE_KEY if column not in frame.columns]
    if missing:
        raise ValueError(f"Daily queue data is missing key columns: {missing}")

    work = frame.copy()
    work["_queue_source_order"] = np.arange(len(work))
    timestamp = next((column for column in INVENTORY_TIMESTAMP_COLUMNS if column in work.columns), None)
    if timestamp:
        work["_queue_state_timestamp"] = pd.to_datetime(work[timestamp], errors="coerce", utc=True)
    else:
        work["_queue_state_timestamp"] = pd.NaT

    if ranked or "rank" in work.columns:
        work["_queue_rank"] = (
            pd.to_numeric(work["rank"], errors="coerce")
            if "rank" in work.columns else np.nan
        )
    else:
        work["_queue_rank"] = np.nan
    work["_queue_score"] = (
        pd.to_numeric(work["priority_score"], errors="coerce")
        if "priority_score" in work.columns else np.nan
    )

    # With keep='last', sort lower ranks and higher scores last so they win ties.
    work = work.sort_values(
        ["_queue_state_timestamp", "_queue_rank", "_queue_score", "_queue_source_order"],
        ascending=[True, False, True, True],
        na_position="first",
        kind="stable",
    )
    work = work.drop_duplicates(subset=QUEUE_KEY, keep="last")
    return work.drop(
        columns=["_queue_source_order", "_queue_state_timestamp", "_queue_rank", "_queue_score"]
    ).reset_index(drop=True)


def attach_inventory_verification(
    frame: pd.DataFrame,
    verified_on_hand: Mapping[Any, float],
    verified_outcomes: Mapping[Any, str],
    *,
    key_column: str,
) -> pd.DataFrame:
    """Attach physical findings without mutating source system inventory."""
    result = frame.copy()
    if "on_hand" in result.columns:
        result["system_recorded_on_hand"] = result["on_hand"]
    keys = result[key_column]
    if key_column == "date":
        keys = pd.to_datetime(keys, errors="coerce").dt.date
    result["verified_on_hand"] = keys.map(verified_on_hand)
    result["verified_outcome"] = keys.map(verified_outcomes)
    return result


def _finite_number(value: Any, default: float = 0.0) -> float:
    number = pd.to_numeric(value, errors="coerce")
    return default if pd.isna(number) else float(number)


def priority_from_evidence(priority_score: Any, zero_sales_streak: Any, cfg: dict[str, Any]) -> str:
    """Assign a policy tier from the existing model risk score and persistence.

    ``priority_score`` is the model probability multiplied by expected daily
    recoverable revenue (INR/day). Critical also requires a persistent signal;
    one zero-sales day alone cannot be called critical.
    """
    rules = cfg.get("priority", {})
    score = max(0.0, _finite_number(priority_score))
    streak = max(0, int(_finite_number(zero_sales_streak)))
    critical_score = float(rules.get("critical_score_inr_per_day", 250.0))
    critical_streak = int(rules.get("critical_min_zero_streak", 3))
    high_score = float(rules.get("high_score_inr_per_day", 100.0))
    high_streak = int(rules.get("high_min_zero_streak", 2))
    medium_score = float(rules.get("medium_score_inr_per_day", 25.0))

    if score >= critical_score and streak >= critical_streak:
        return "Critical"
    if score >= critical_score or (score >= high_score and streak >= high_streak):
        return "High"
    if score >= medium_score:
        return "Medium"
    return "Low"


def classify_queue_candidates(
    candidates: pd.DataFrame,
    history: pd.DataFrame,
    stores: pd.DataFrame | None,
    business_date: date | str,
    scoring_time: str | None = None,
) -> dict[str, str]:
    """Return cautious signal hypotheses using history available by the date.

    The operational classifier's heuristic score is deliberately not returned;
    queue probabilities continue to come only from the existing predictive model.
    """
    if candidates.empty:
        return {}

    scoring_time = scoring_time or str(load_config().get("features", {}).get("scoring_time", "start_of_day"))
    target_date = pd.Timestamp(business_date).normalize()
    if history.empty:
        return {str(sku): "UNSPECIFIED_DISCREPANCY" for sku in candidates["sku_id"]}

    frame = history.copy()
    frame["date"] = pd.to_datetime(frame["date"], errors="coerce").dt.normalize()
    if scoring_time == "start_of_day":
        frame = frame.loc[frame["date"].lt(target_date)]
    else:
        frame = frame.loc[frame["date"].le(target_date)]
    frame = deduplicate_daily_rows(frame)
    classifier = OperationalLeakClassifier()

    tier_by_store: dict[str, str] = {}
    if stores is not None and {"store_id", "city_tier"}.issubset(stores.columns):
        tier_by_store = stores.drop_duplicates("store_id").set_index("store_id")["city_tier"].astype(str).to_dict()
    peers_by_tier: dict[str, list[str]] = {}
    if tier_by_store and stores is not None:
        peer_frame = stores[["store_id", "city_tier"]].dropna().drop_duplicates("store_id")
        for tier, group in peer_frame.groupby("city_tier", sort=False):
            peers_by_tier[str(tier)] = group["store_id"].astype(str).tolist()

    result: dict[str, str] = {}
    for candidate in candidates.to_dict("records"):
        sku_id = str(candidate["sku_id"])
        store_id = str(candidate["store_id"])
        local = frame.loc[
            frame["store_id"].astype(str).eq(store_id)
            & frame["sku_id"].astype(str).eq(sku_id)
        ].sort_values("date").tail(56)
        expected_latest_date = target_date - pd.DateOffset(days=1) if scoring_time == "start_of_day" else target_date
        if local.empty or local["date"].max() != expected_latest_date:
            result[sku_id] = "UNSPECIFIED_DISCREPANCY"
            continue

        if scoring_time == "start_of_day" and pd.notna(candidate.get("on_hand")):
            local.loc[local.index[-1], "on_hand"] = float(candidate["on_hand"])

        price_values = pd.to_numeric(local.get("unit_price"), errors="coerce")
        price = float(price_values.dropna().median()) if price_values.notna().any() else 0.0
        regional_matrix = None
        tier = tier_by_store.get(store_id)
        peers = peers_by_tier.get(tier, []) if tier else []
        if len(peers) > 1:
            regional = frame.loc[
                frame["sku_id"].astype(str).eq(sku_id)
                & frame["store_id"].astype(str).isin(peers)
            ].pivot(index="date", columns="store_id", values="sales")
            regional = regional.reindex(local["date"])
            if set(peers).issubset(regional.columns) and not regional[peers].isna().any().any():
                regional_matrix = regional[peers].to_numpy(dtype=float)

        signal = classifier.classify_single_combination(
            pd.to_numeric(local["sales"], errors="coerce").fillna(0).to_numpy(dtype=float),
            pd.to_numeric(local["on_hand"], errors="coerce").fillna(0).to_numpy(dtype=float),
            sku_id,
            store_id,
            price,
            regional_matrix,
        )
        if signal.classification in {"PHANTOM_STOCKOUT", "MISPLACED", "DELISTED"}:
            result[sku_id] = f"POSSIBLE_{signal.classification}"
        elif signal.classification == "NORMAL_SLOW_MOVER":
            result[sku_id] = "NORMAL_SLOW_MOVER"
        else:
            result[sku_id] = "UNSPECIFIED_DISCREPANCY"
    return result
