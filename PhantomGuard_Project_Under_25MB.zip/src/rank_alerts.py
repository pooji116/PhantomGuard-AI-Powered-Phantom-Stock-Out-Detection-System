"""Priority ranking with a strict top-20 store-day constraint."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from src.config import label_column, load_config, positive_label_value, project_root
from src.io_utils import write_table
from src.queue_data import deduplicate_daily_rows

LOGGER = logging.getLogger(__name__)

ACTION = (
    "Physically verify shelf facings and backroom quantity for this SKU. "
    "Do not adjust system inventory until the count is confirmed."
)


def _number_or(value: Any, default: float = 0.0) -> float:
    number = pd.to_numeric(value, errors="coerce")
    return default if pd.isna(number) else float(number)


def expected_daily_revenue_loss(
    expected_demand: pd.Series,
    unit_price: pd.Series | None,
    recoverable_fraction: float,
) -> tuple[pd.Series, bool]:
    """Estimate expected daily lost revenue without using labels.

    If prices are missing, returns NaN losses and ``prices_available=False``.
    """
    demand = pd.to_numeric(expected_demand, errors="coerce").fillna(0).clip(lower=0)
    if unit_price is None:
        return pd.Series(np.nan, index=demand.index), False
    price = pd.to_numeric(unit_price, errors="coerce")
    if price.notna().sum() == 0:
        return pd.Series(np.nan, index=demand.index), False
    loss = demand * price * float(recoverable_fraction)
    return loss, True


def generate_reason(row: pd.Series, scoring_time: str = "end_of_day") -> str:
    stock = row.get("on_hand", np.nan)
    streak = int(_number_or(row.get("positive_stock_zero_streak", row.get("zero_sales_streak", 0))))
    expected = row.get("expected_demand", np.nan)
    sales = row.get("sales", np.nan)
    if scoring_time == "start_of_day":
        sales = row.get("sales_lag_1", np.nan)
    recent = row.get("sales_mean_7", expected)
    stock_txt = f"{stock:.0f} units" if pd.notna(stock) else "an unknown quantity"
    if pd.notna(sales) and float(sales) == 0:
        period = "completed day(s)" if scoring_time == "start_of_day" else "day(s)"
        signal = f"no sales were recorded for {streak} consecutive {period}"
    elif pd.notna(sales):
        period = "on the last completed day" if scoring_time == "start_of_day" else "today"
        signal = f"only {sales:.0f} units were sold {period}"
    else:
        signal = "recent sales data is missing"
    demand_txt = f"Recent sales averaged {recent:.1f} units per day. " if pd.notna(recent) else ""
    return (
        f"The system shows {stock_txt} in stock, but {signal}. {demand_txt}"
        "Check the shelf, then check the backroom. This alert is a risk estimate and needs physical verification."
    )


def hypothesis_category(row: pd.Series) -> str:
    """Optional stretch label: a hypothesis only, never a confirmed cause."""
    expected = _number_or(row.get("expected_demand", 0))
    streak = int(_number_or(row.get("positive_stock_zero_streak", 0)))
    velocity = _number_or(row.get("sales_velocity", expected), expected)
    if streak >= 14 and velocity < 0.15:
        return "hypothesis_possible_delist_or_dormant_demand"
    if expected < 0.30 or velocity < 0.25:
        return "hypothesis_legitimate_slow_mover_or_weak_demand"
    if streak >= 3 and expected >= 1.0:
        return "hypothesis_possible_phantom_stockout"
    inventory_variance = _number_or(row.get("inventory_variance_during_zero_streak", 0))
    if streak >= 2 and inventory_variance > 0:
        return "hypothesis_possible_misplaced_or_unreplenished_shelf"
    return "hypothesis_unspecified_discrepancy"


def eligible_mask(df: pd.DataFrame, cfg: dict[str, Any]) -> pd.Series:
    rank_cfg = cfg.get("ranking", {})
    min_demand = float(rank_cfg.get("min_expected_demand", 0.05))
    min_positive_days = int(rank_cfg.get("min_positive_sales_days_28", 0))
    min_zero_streak = int(rank_cfg.get("min_positive_stock_zero_streak", 1))
    require_stock = bool(rank_cfg.get("require_positive_on_hand", True))
    require_zero = bool(rank_cfg.get("require_zero_sales", True))
    min_history = int(cfg.get("features", {}).get("min_history_days", 14))
    scoring = str(cfg.get("features", {}).get("scoring_time", "start_of_day"))
    mask = df.get("history_days", pd.Series(min_history, index=df.index)).fillna(0) >= min_history
    mask &= df.get("expected_demand", pd.Series(0, index=df.index)).fillna(0) >= min_demand
    streak = pd.to_numeric(
        df.get("positive_stock_zero_streak", df.get("zero_sales_streak", pd.Series(0, index=df.index))),
        errors="coerce",
    ).fillna(0)
    mask &= streak >= min_zero_streak
    if min_positive_days > 0 and "positive_sales_days_28" in df.columns:
        positive_days = pd.to_numeric(df["positive_sales_days_28"], errors="coerce").fillna(0)
        mask &= positive_days >= min_positive_days
    if require_stock:
        mask &= df.get("on_hand", pd.Series(0, index=df.index)).fillna(0) > 0
    if require_zero:
        sales_col = "sales" if scoring == "end_of_day" else "sales_lag_1"
        if sales_col in df.columns:
            sales_s = pd.to_numeric(df[sales_col], errors="coerce")
            mask &= (sales_s == 0) & sales_s.notna()
            if scoring == "start_of_day":
                if "days_since_previous_observation" in df.columns:
                    gap = pd.to_numeric(df["days_since_previous_observation"], errors="coerce")
                    mask &= gap.eq(1)
                else:
                    mask &= False
        else:
            mask &= False
    return mask.fillna(False)


def rank_store_day_alerts(
    df: pd.DataFrame,
    cfg: dict[str, Any] | None = None,
    probability_col: str = "predicted_probability",
    max_alerts: int | None = None,
) -> pd.DataFrame:
    """Select at most ``max_alerts`` candidates per store-day.

    ``priority_score = predicted_probability * expected_daily_revenue_loss``
    when prices exist. If prices are missing, ranking falls back to probability
    only and ``ranking_mode`` is set to ``probability_only``.
    """
    cfg = cfg or load_config()
    rank_cfg = cfg.get("ranking", {})
    k = int(max_alerts if max_alerts is not None else rank_cfg.get("max_alerts_per_store_day", 20))
    recoverable = float(rank_cfg.get("recoverable_fraction", 0.5))
    min_priority = float(rank_cfg.get("min_priority_score", 0.0))
    fallback_price = rank_cfg.get("fallback_unit_price", None)

    work = deduplicate_daily_rows(df)
    required_keys = ["date", "store_id", "sku_id"]
    missing_keys = [column for column in required_keys if column not in work.columns]
    if missing_keys:
        raise ValueError(f"Ranking requires key columns: {missing_keys}")
    if probability_col not in work.columns:
        if "baseline_score" in work.columns:
            probability_col = "baseline_score"
        else:
            raise ValueError("No predicted_probability or baseline_score column available for ranking.")
    work["predicted_probability"] = pd.to_numeric(work[probability_col], errors="coerce").fillna(0).clip(0, 1)

    price = work["unit_price"] if "unit_price" in work.columns else None
    prices_available = price is not None and pd.to_numeric(price, errors="coerce").notna().any()
    if (not prices_available) and fallback_price is not None:
        LOGGER.warning(
            "Unit prices are missing; ranking uses configured fallback_unit_price=%s. "
            "This is not an observed price.",
            fallback_price,
        )
        price = pd.Series(float(fallback_price), index=work.index)
        prices_available = True
        work["price_mode"] = "configured_fallback"
    elif prices_available:
        work["price_mode"] = "observed_or_file"
    else:
        work["price_mode"] = "missing"

    loss, ok = expected_daily_revenue_loss(work.get("expected_demand", 0), price, recoverable)
    work["expected_daily_revenue_loss"] = loss
    if ok and prices_available:
        work["priority_score"] = work["predicted_probability"] * work["expected_daily_revenue_loss"].fillna(0)
        work["ranking_mode"] = "probability_times_expected_daily_revenue_loss"
    else:
        work["priority_score"] = work["predicted_probability"]
        work["ranking_mode"] = "probability_only"
        LOGGER.warning(
            "Unit prices unavailable; ranking uses predicted probability only. "
            "Business-impact ordering is less reliable."
        )

    mask = eligible_mask(work, cfg)
    cand = work.loc[mask].copy()
    cand = cand.loc[cand["priority_score"] >= min_priority].copy()
    if cand.empty:
        LOGGER.info("No eligible ranking candidates.")
        return cand

    scoring_time = str(cfg.get("features", {}).get("scoring_time", "start_of_day"))
    cand["reason"] = cand.apply(lambda row: generate_reason(row, scoring_time), axis=1)
    cand["recommended_action"] = ACTION
    cand["hypothesis_category"] = cand.apply(hypothesis_category, axis=1)

    tie = list(rank_cfg.get("tie_breakers", ["priority_score", "predicted_probability", "sku_id"]))
    ascending = [False if c != "sku_id" else True for c in tie]
    # sku_id always ascending for deterministic ties; numeric scores descending.
    sort_cols = []
    sort_asc = []
    for col in tie:
        if col in cand.columns:
            sort_cols.append(col)
            sort_asc.append(col == "sku_id")
    if "priority_score" not in sort_cols:
        sort_cols.insert(0, "priority_score")
        sort_asc.insert(0, False)

    cand = cand.sort_values(sort_cols, ascending=sort_asc, kind="mergesort")
    cand["rank"] = cand.groupby(["store_id", "date"], sort=False).cumcount() + 1
    selected = cand.loc[cand["rank"] <= k].copy()
    sizes = selected.groupby(["store_id", "date"]).size()
    if (sizes > k).any():
        raise RuntimeError("Ranking exceeded the per store-day alert cap.")
    LOGGER.info("Ranked %s alerts across %s store-days (cap=%s)", len(selected), sizes.shape[0], k)
    return selected.reset_index(drop=True)


def precision_at_k_store_day(
    ranked: pd.DataFrame,
    y_col: str,
    positive_value: int = 1,
    k: int = 20,
) -> dict[str, float | int | None]:
    """Macro and micro precision@k. Does not treat unlabeled rows as negatives."""
    if ranked.empty or y_col not in ranked.columns:
        return {
            "macro_average": None,
            "micro_average": None,
            "n_store_days": 0,
            "n_labeled_selected": 0,
            "policy": "unlabeled selected alerts are excluded from the denominator",
        }
    labeled = ranked.loc[ranked[y_col].notna()].copy()
    if labeled.empty:
        return {
            "macro_average": None,
            "micro_average": None,
            "n_store_days": 0,
            "n_labeled_selected": 0,
            "policy": "no labeled selected alerts",
        }
    labeled["hit"] = (labeled[y_col] == positive_value).astype(int)
    per = labeled.groupby(["store_id", "date"], sort=False)["hit"].mean()
    hits_by_day = labeled.groupby(["store_id", "date"], sort=False)["hit"].sum()
    micro = float(labeled["hit"].mean())
    return {
        "macro_average": float(per.mean()) if len(per) else None,
        "micro_average": micro,
        "fixed_k_denominator_macro": float((hits_by_day / max(int(k), 1)).mean()) if len(hits_by_day) else None,
        "n_store_days": int(len(per)),
        "n_labeled_selected": int(len(labeled)),
        "true_positives_selected": int(labeled["hit"].sum()),
        "k": k,
        "policy": (
            "macro_average/micro_average divide hits by labeled selected alerts (unlabeled alerts omitted, not negatives); "
            "fixed_k_denominator_macro divides each store-day's hits by k, even when fewer than k candidates were selected. "
            "The fixed-k value therefore penalizes short candidate lists and is shown as a separate convention."
        ),
    }


def run_rank(config_path: str | Path | None = None, use_baseline: bool = False) -> Path:
    from src.io_utils import read_table

    cfg = load_config(config_path)
    pred_dir = project_root() / cfg["paths"]["predictions_dir"]
    model_path = pred_dir / cfg["files"]["model_predictions"]
    base_path = pred_dir / cfg["files"]["baseline_predictions"]
    path = base_path if use_baseline or not model_path.exists() else model_path
    csv_fallback = path.with_suffix(".csv")
    if path.exists():
        df = read_table(path)
    elif csv_fallback.exists():
        df = read_table(csv_fallback)
    else:
        raise FileNotFoundError("No prediction file found. Run baseline or train first.")
    ranked = rank_store_day_alerts(df, cfg)
    out = write_table(ranked, pred_dir / cfg["files"]["ranked_alerts"])
    LOGGER.info("Wrote ranked alerts to %s", out)
    return out


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run_rank()
