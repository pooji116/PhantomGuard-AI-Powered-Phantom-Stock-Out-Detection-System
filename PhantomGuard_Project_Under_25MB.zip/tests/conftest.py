from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.config import load_config


@pytest.fixture
def cfg() -> dict:
    return load_config()


@pytest.fixture
def tiny_panel() -> pd.DataFrame:
    dates = pd.date_range("2024-01-01", periods=20, freq="D")
    rows = []
    for i, d in enumerate(dates):
        sales = 0 if i >= 14 else (3 if i % 2 == 0 else 2)
        rows.append(
            {
                "date": d,
                "store_id": "S01",
                "sku_id": "K001",
                "sales": float(sales),
                "on_hand": 8.0,
                "unit_price": 50.0,
                "promo_flag": 0,
                "holiday_flag": 0,
                "store_size": 1000,
                "store_format": "compact",
                "city_tier": "T1",
                "is_phantom": 1 if i >= 14 else 0,
            }
        )
        rows.append(
            {
                "date": d,
                "store_id": "S01",
                "sku_id": "K002",
                "sales": 1.0 if i < 18 else 0.0,
                "on_hand": 4.0,
                "unit_price": 20.0,
                "promo_flag": 0,
                "holiday_flag": 0,
                "store_size": 1000,
                "store_format": "compact",
                "city_tier": "T1",
                "is_phantom": 0,
            }
        )
    return pd.DataFrame(rows)
