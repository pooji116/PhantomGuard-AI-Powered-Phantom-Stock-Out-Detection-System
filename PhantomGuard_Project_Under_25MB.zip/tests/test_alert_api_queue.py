from __future__ import annotations

from datetime import date
from types import SimpleNamespace

import pandas as pd

from backend import main as api


class _ScalarResult:
    def __init__(self, values):
        self.values = values

    def all(self):
        return self.values


class _FakeSession:
    def __init__(self, responses):
        self.responses = responses
        self.calls = 0

    async def scalars(self, _statement):
        values = self.responses[self.calls]
        self.calls += 1
        return _ScalarResult(values)


def _run_without_os_loop(coroutine):
    """Drive route coroutines whose patched awaits complete immediately.

    Windows' sandboxed Python runtime can block while asyncio creates its
    private socket-pair wakeup pipe; this avoids any network or OS event loop.
    """
    try:
        coroutine.send(None)
    except StopIteration as completed:
        return completed.value
    raise AssertionError("Test coroutine unexpectedly yielded control")


def _source_rows() -> pd.DataFrame:
    rows = []
    for index in range(25):
        sku = "SKU0772" if index == 0 else f"SKU{index:04d}"
        rows.append({
            "date": "2025-07-01",
            "store_id": "S001",
            "sku_id": sku,
            "product_name": f"Item {sku}",
            "rank": index + 1,
            "priority_score": float(300 - index * 10),
            "predicted_probability": 0.7 - index * 0.01,
            "expected_daily_revenue_loss": 500.0 - index,
            "estimated_revenue_at_risk": 700.0 - index,
            "expected_demand": 5.0,
            "sales_mean_7": 5.0,
            "unit_price": 20.0,
            "sales": 0.0,
            "on_hand": 49 if sku == "SKU0772" else 10 + index,
            "positive_stock_zero_streak": 1 + index % 4,
        })
    rows.extend([
        {**rows[1], "date": "2025-07-02", "sku_id": "OTHER_DATE"},
        {**rows[2], "store_id": "S002", "sku_id": "OTHER_STORE"},
    ])
    return pd.DataFrame(rows)


def test_alert_api_filters_unique_top_twenty_and_keeps_verified_count_separate(monkeypatch) -> None:
    source = _source_rows()
    async def direct_to_thread(function, *args, **kwargs):
        return function(*args, **kwargs)

    monkeypatch.setattr(api.asyncio, "to_thread", direct_to_thread)
    monkeypatch.setattr(api, "_read_parquet", lambda *_args, **_kwargs: source.copy())
    monkeypatch.setattr(api, "_read_alert_history", lambda *_args, **_kwargs: pd.DataFrame())
    audited = SimpleNamespace(sku_id="SKU0772", outcome="stock_missing")
    verified = SimpleNamespace(sku_id="SKU0772", adjusted_on_hand=0.0)
    session = _FakeSession([[audited], [verified], []])

    result = _run_without_os_loop(api.alerts(
        store_id="S001",
        alert_date=date(2025, 7, 1),
        tenant_id="demo",
        session=session,
    ))

    assert len(result) == 20
    assert len({(item["store_id"], item["sku_id"], item["date"]) for item in result}) == 20
    assert all(item["store_id"] == "S001" and item["date"] == "2025-07-01" for item in result)
    scores = [item["priority_score"] for item in result]
    assert scores == sorted(scores, reverse=True)

    item = next(alert for alert in result if alert["sku_id"] == "SKU0772")
    assert item["on_hand"] == item["system_recorded_on_hand"] == 49
    assert item["verified_on_hand"] == 0
    assert "49 units" in item["reason"]


def test_empty_morning_queue_uses_zero_instead_of_example_totals(monkeypatch) -> None:
    empty = pd.DataFrame(columns=["date", "store_id", "sku_id"])
    async def direct_to_thread(function, *args, **kwargs):
        return function(*args, **kwargs)

    monkeypatch.setattr(api.asyncio, "to_thread", direct_to_thread)
    monkeypatch.setattr(api, "_read_parquet", lambda *_args, **_kwargs: empty.copy())

    result = _run_without_os_loop(api.morning_dispatch_cron(
        store_id="S001",
        target_date=date(2025, 7, 1),
        tenant_id="demo",
    ))

    assert result.item_count == 0
    assert result.total_sales_at_risk == 0
    assert "0 items" in result.notification_payload.body
    assert "₹0" in result.notification_payload.body
