from __future__ import annotations

import pandas as pd

from src.business_impact import aggregate_impact, attach_revenue_fields, format_inr
from src.rank_alerts import expected_daily_revenue_loss


def test_revenue_arithmetic(cfg: dict) -> None:
    demand = pd.Series([2.0, 0.0])
    price = pd.Series([50.0, 50.0])
    loss, ok = expected_daily_revenue_loss(demand, price, 0.5)
    assert ok
    assert list(loss) == [50.0, 0.0]


def test_missing_price_does_not_invent(cfg: dict) -> None:
    demand = pd.Series([2.0])
    loss, ok = expected_daily_revenue_loss(demand, None, 0.5)
    assert not ok
    assert loss.isna().all()


def test_incident_dedup_and_format(cfg: dict) -> None:
    df = pd.DataFrame(
        {
            "date": pd.to_datetime(["2024-01-01", "2024-01-02", "2024-01-04"]),
            "store_id": ["S", "S", "S"],
            "sku_id": ["K", "K", "K"],
            "expected_demand": [2.0, 2.0, 2.0],
            "unit_price": [100.0, 100.0, 100.0],
            "predicted_probability": [0.5, 0.6, 0.4],
            "priority_score": [1, 1, 1],
            "positive_stock_zero_streak": [2, 3, 1],
        }
    )
    summary = aggregate_impact(df, cfg, observed_period_days=10)
    assert summary["prices_available"] is True
    # Two incidents because of the gap after 2024-01-02.
    assert summary["n_incidents_deduped"] == 2
    assert format_inr(1000).startswith("₹")
    framed = attach_revenue_fields(df, cfg)
    recoverable = float(cfg["ranking"]["recoverable_fraction"])
    assert framed.loc[0, "estimated_daily_revenue_at_risk"] == 2.0 * 100.0
    assert framed.loc[0, "estimated_daily_potential_recovery"] == 2.0 * 100.0 * recoverable
    assert summary["actually_recovered_revenue"] is None
    assert summary["estimated_period_revenue_at_risk"] >= summary["estimated_period_potential_recovery"]
    assert summary["estimated_daily_revenue_at_risk_sum"] == 600.0
    assert summary["estimated_period_revenue_at_risk"] == 800.0
    assert summary["estimated_period_potential_recovery"] == 400.0
    assert summary["estimated_annualized_potential_recovery"] == 400.0 * 365 / 10


def test_empty_alerts(cfg: dict) -> None:
    summary = aggregate_impact(pd.DataFrame(), cfg)
    assert summary["n_alerts"] == 0
