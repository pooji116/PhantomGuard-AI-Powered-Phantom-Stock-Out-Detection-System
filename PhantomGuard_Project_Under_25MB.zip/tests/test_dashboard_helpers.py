from __future__ import annotations

import pandas as pd
from pathlib import Path
from streamlit.testing.v1 import AppTest

from src.dashboard_helpers import (
    filter_product_history,
    filter_store_day_alerts,
    has_ranked_alerts,
    latest_alert_defaults,
    selection_data_available,
)


def test_dashboard_filter_returns_selected_store_day() -> None:
    rows = pd.DataFrame(
        {
            "date": pd.to_datetime(["2024-01-01", "2024-01-01", "2024-01-02"]),
            "store_id": ["S1", "S2", "S1"],
            "sku_id": ["A", "B", "C"],
        }
    )
    out = filter_store_day_alerts(rows, "2024-01-01", "S1")
    assert out["sku_id"].tolist() == ["A"]


def test_dashboard_filter_empty_or_missing_columns_is_safe() -> None:
    assert filter_store_day_alerts(pd.DataFrame(), "2024-01-01", "S1").empty
    assert filter_store_day_alerts(pd.DataFrame({"sku_id": ["A"]}), "2024-01-01", "S1").empty


def test_dashboard_missing_and_empty_prediction_artifacts() -> None:
    assert has_ranked_alerts(None) is False
    assert has_ranked_alerts(pd.DataFrame()) is False
    assert has_ranked_alerts(pd.DataFrame({"sku_id": ["A"]})) is True


def test_dashboard_defaults_to_latest_store_date_with_alerts() -> None:
    alerts = pd.DataFrame({
        "date": pd.to_datetime(["2024-01-20", "2024-01-28", "2024-01-28"]),
        "store_id": ["S01", "S02", "S01"],
    })
    assert latest_alert_defaults(alerts, ["S01", "S02"], pd.Timestamp("2024-01-30").date()) == (
        "S01", pd.Timestamp("2024-01-28").date()
    )


def test_product_history_is_limited_to_selected_store_sku_and_date() -> None:
    frame = pd.DataFrame({
        "date": pd.to_datetime(["2024-01-01", "2024-01-02", "2024-01-03", "2024-01-02"]),
        "store_id": ["S1", "S1", "S1", "S2"],
        "sku_id": ["A", "A", "A", "A"],
        "sales": [1, 0, 3, 9],
    })
    result = filter_product_history(frame, "S1", "A", "2024-01-02")
    assert result["sales"].tolist() == [1, 0]


def test_selection_data_available_requires_actual_sales_and_stock() -> None:
    frame = pd.DataFrame({
        "date": pd.to_datetime(["2024-01-01", "2024-01-01"]),
        "store_id": ["S1", "S1"], "sales": [0, None], "on_hand": [4, None],
    })
    assert selection_data_available(frame, "S1", "2024-01-01")
    assert not selection_data_available(frame, "S2", "2024-01-01")
    assert not selection_data_available(None, "S1", "2024-01-01")


def test_streamlit_dashboard_renders_without_exceptions() -> None:
    app_path = Path(__file__).resolve().parents[1] / "app" / "app.py"
    app = AppTest.from_file(str(app_path), default_timeout=30).run()
    assert not app.exception
    assert [radio.value for radio in app.radio] == ["Overview"]
    assert "PhantomGuard" in [title.value for title in app.title]
    app.radio[0].set_value("Reports").run()
    assert not app.exception
    assert "Reports" in [heading.value for heading in app.subheader]

