from __future__ import annotations

import pandas as pd

from scripts.generate_demo_data import generate_demo, write_demo


def test_synthetic_anomaly_generation_is_reproducible() -> None:
    first = generate_demo(n_stores=2, n_skus=5, n_days=40, seed=123)
    second = generate_demo(n_stores=2, n_skus=5, n_days=40, seed=123)
    for name in first:
        pd.testing.assert_frame_equal(first[name], second[name])
    assert first["labels"]["is_phantom"].sum() > 0
    assert first["products"]["sku_id"].tolist() == [f"SKU{i:04d}" for i in range(1, 6)]
    assert first["products"].loc[0, "product_name"] == "Staples item 0001"


def test_demo_writer_keeps_generated_tables_in_requested_sample_directory(tmp_path) -> None:
    tables = generate_demo(n_stores=2, n_skus=5, n_days=40, seed=123)
    destination = tmp_path / "sample"
    write_demo(destination, tables)
    assert (destination / "SYNTHETIC.txt").exists()
    assert (destination / "labels.csv").exists()
    assert (destination / "products.csv").exists()
    assert not (tmp_path / "raw" / "labels.csv").exists()
