from __future__ import annotations

import pandas as pd

from src.evaluate import evaluate_model_vs_baseline, evaluate_predictions, recall_labeled
from src.model import assign_chronological_split, matrix
from src.rank_alerts import precision_at_k_store_day


def test_precision_at_20_and_recall() -> None:
    dates = pd.to_datetime(["2024-01-10"] * 25 + ["2024-01-10"] * 5)
    df = pd.DataFrame(
        {
            "date": list(dates[:25]) + list(pd.to_datetime(["2024-01-11"] * 5)),
            "store_id": ["S1"] * 25 + ["S1"] * 5,
            "sku_id": [f"K{i:02d}" for i in range(25)] + [f"Z{i}" for i in range(5)],
            "is_phantom": [1] * 5 + [0] * 20 + [1] * 2 + [0] * 3,
        }
    )
    ranked = df.copy()
    ranked["rank"] = list(range(1, 26)) + list(range(1, 6))
    # First store-day has 25 rows; evaluator uses whatever ranked list it receives.
    p = precision_at_k_store_day(ranked.groupby(["store_id", "date"]).head(20), "is_phantom", 1, k=20)
    assert p["n_store_days"] == 2
    assert 0 <= p["macro_average"] <= 1
    rec = recall_labeled(ranked.groupby(["store_id", "date"]).head(20), df, "is_phantom", 1)
    assert rec["positives"] == 7
    assert rec["captured"] >= 1


def test_unlabeled_not_treated_as_negative() -> None:
    ranked = pd.DataFrame(
        {
            "date": pd.to_datetime(["2024-01-01"] * 3),
            "store_id": ["S"] * 3,
            "sku_id": ["A", "B", "C"],
            "is_phantom": [1, None, None],
        }
    )
    p = precision_at_k_store_day(ranked, "is_phantom", 1, k=20)
    # Only the labeled selected row counts; unlabeled are omitted.
    assert p["n_labeled_selected"] == 1
    assert p["micro_average"] == 1.0


def test_unlabeled_candidates_compete_for_top_k(cfg: dict) -> None:
    # Two high-scoring unlabeled rows must occupy both audit slots. Ranking
    # only labeled rows would incorrectly select the positive third row.
    cfg["ranking"]["max_alerts_per_store_day"] = 2
    candidates = pd.DataFrame(
        {
            "date": pd.to_datetime(["2024-01-01"] * 3),
            "store_id": ["S"] * 3,
            "sku_id": ["A", "B", "C"],
            "label": [None, None, 1],
            "predicted_probability": [0.99, 0.90, 0.80],
            "expected_demand": [1.0] * 3,
            "unit_price": [10.0] * 3,
            "history_days": [30] * 3,
            "sales_lag_1": [0.0] * 3,
            "days_since_previous_observation": [1] * 3,
            "on_hand": [5.0] * 3,
            "sales": [0.0] * 3,
            "positive_stock_zero_streak": [3] * 3,
        }
    )

    report = evaluate_predictions(candidates, cfg, max_alerts=2)

    assert report["precision_at_20"]["n_labeled_selected"] == 0
    assert report["recall"]["captured"] == 0


def test_model_and_baseline_are_scored_independently_on_same_candidates(cfg: dict) -> None:
    cfg["ranking"]["max_alerts_per_store_day"] = 2
    common = {
        "date": pd.to_datetime(["2024-01-01"] * 4),
        "store_id": ["S"] * 4,
        "sku_id": ["A", "B", "C", "D"],
        "label": [1, 0, 0, 1],
        "sales": [0.0] * 4,
        "sales_lag_1": [0.0] * 4,
        "days_since_previous_observation": [1] * 4,
        "on_hand": [4.0] * 4,
        "expected_demand": [1.0] * 4,
        "unit_price": [10.0] * 4,
        "history_days": [30] * 4,
        "positive_stock_zero_streak": [3] * 4,
        "split": ["test"] * 4,
    }
    model = pd.DataFrame({**common, "predicted_probability": [0.95, 0.90, 0.80, 0.10]})
    baseline = pd.DataFrame({**common, "baseline_score": [0.80, 0.99, 0.90, 0.20]})

    report = evaluate_model_vs_baseline(model, baseline, cfg)

    model_metrics = report["by_source"]["model"]
    baseline_metrics = report["by_source"]["baseline"]
    assert model_metrics["precision_at_20"]["macro_average"] == 0.5
    assert model_metrics["recall"]["recall"] == 0.5
    assert baseline_metrics["precision_at_20"]["macro_average"] == 0.0
    assert baseline_metrics["recall"]["recall"] == 0.0
    assert report["comparison"]["same_candidate_population"] is True


def test_train_validation_test_split_uses_observation_dates(tiny_panel: pd.DataFrame, cfg: dict) -> None:
    split = assign_chronological_split(tiny_panel, cfg)
    dates_by_split = pd.DataFrame({"date": tiny_panel["date"], "split": split}).groupby("split")["date"].agg(["min", "max"])
    assert dates_by_split.loc["train", "max"] < dates_by_split.loc["validation", "min"]
    assert dates_by_split.loc["validation", "max"] < dates_by_split.loc["test", "min"]


def test_evaluate_empty_labels(cfg: dict) -> None:
    df = pd.DataFrame(
        {
            "date": pd.to_datetime(["2024-01-01"]),
            "store_id": ["S"],
            "sku_id": ["K"],
            "sales": [0.0],
            "on_hand": [3.0],
            "expected_demand": [1.0],
            "history_days": [20],
            "predicted_probability": [0.9],
        }
    )
    report = evaluate_predictions(df, cfg)
    assert "error" in report


def test_feature_matrix_rejects_labels(tiny_panel: pd.DataFrame, cfg: dict) -> None:
    from src.features import build_features

    feats = build_features(tiny_panel, cfg)
    X = matrix(feats, cfg)
    assert "is_phantom" not in X.columns
    assert "date" not in X.columns


def test_boundary_crossing_labeled_event_is_purged(cfg: dict) -> None:
    from src.model import purge_boundary_anomaly_events

    rows = []
    for day in range(1, 8):
        rows.append({"date": pd.Timestamp(2024, 1, day), "store_id": "S", "sku_id": "K", "label": int(day in {3, 4, 5})})
    panel = pd.DataFrame(rows)
    clean, purged = purge_boundary_anomaly_events(panel, cfg, (pd.Timestamp("2024-01-04"), pd.Timestamp("2024-01-06")))
    assert purged == 3
    assert clean["label"].sum() == 0


def test_evaluation_reports_precision_denominators_and_f1(cfg: dict) -> None:
    candidates = pd.DataFrame({
        "date": pd.to_datetime(["2024-01-01"] * 3), "store_id": ["S"] * 3,
        "sku_id": ["A", "B", "C"], "label": [1, 0, 0],
        "predicted_probability": [0.9, 0.8, 0.1], "sales": [0] * 3,
        "on_hand": [3] * 3, "expected_demand": [1] * 3,
        "unit_price": [10] * 3, "history_days": [30] * 3,
        "sales_lag_1": [0] * 3, "days_since_previous_observation": [1] * 3,
        "positive_stock_zero_streak": [2] * 3,
    })
    from src.evaluate import evaluate_predictions
    result = evaluate_predictions(candidates, cfg)
    assert "fixed_k_denominator_macro" in result["precision_at_20"]
    assert result["precision_at_20"]["fixed_k_denominator_macro"] == 0.05
    assert result["f1_at_20"] == 0.5
