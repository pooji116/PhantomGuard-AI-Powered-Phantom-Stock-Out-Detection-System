from __future__ import annotations

import pandas as pd

from src.features import LABEL_LIKE, add_time_features, build_features, feature_columns


def test_lag_alignment_no_future_leak(tiny_panel: pd.DataFrame) -> None:
    feats = add_time_features(tiny_panel, scoring_time="end_of_day", min_history=5)
    k1 = feats.loc[feats["sku_id"] == "K001"].sort_values("date").reset_index(drop=True)
    # Day index 5 uses sales from index 4 as lag-1, never index 6.
    assert k1.loc[5, "sales_lag_1"] == k1.loc[4, "sales"]
    assert k1.loc[5, "sales_lag_1"] != k1.loc[6, "sales"] or k1.loc[4, "sales"] == k1.loc[6, "sales"]
    # Rolling mean at t uses only shifted history (not today's sales in the 7-day mean).
    # For a constant prefix this is still shifted: mean at t excludes sales[t].
    window_vals = k1.loc[0:4, "sales"]  # used by shift+roll at index 5: sales 0-4
    expected = window_vals.tail(7).mean()
    assert abs(k1.loc[5, "sales_mean_7"] - expected) < 1e-9


def test_future_spike_does_not_enter_past_features() -> None:
    dates = pd.date_range("2024-01-01", periods=10, freq="D")
    sales = [1.0] * 9 + [1000.0]
    df = pd.DataFrame(
        {
            "date": dates,
            "store_id": ["S"] * 10,
            "sku_id": ["K"] * 10,
            "sales": sales,
            "on_hand": [5.0] * 10,
            "promo_flag": 0,
            "holiday_flag": 0,
        }
    )
    feats = add_time_features(df, "end_of_day", min_history=3)
    # Features on day 8 (0-based) must not see the spike on day 9.
    assert feats.loc[8, "sales_lag_1"] == 1.0
    assert feats.loc[8, "sales_mean_7"] == 1.0
    assert feats.loc[9, "sales_lag_1"] == 1.0
    assert feats.loc[9, "sales"] == 1000.0


def test_start_of_day_streak_ignores_today_sales(tiny_panel: pd.DataFrame) -> None:
    eod = add_time_features(tiny_panel, "end_of_day", min_history=5)
    sod = add_time_features(tiny_panel, "start_of_day", min_history=5)
    last_eod = eod.loc[eod["sku_id"] == "K001"].iloc[-1]
    last_sod = sod.loc[sod["sku_id"] == "K001"].iloc[-1]
    assert last_eod["zero_sales_streak"] >= last_sod["zero_sales_streak"]


def test_start_of_day_features_do_not_change_when_current_sales_change(tiny_panel: pd.DataFrame) -> None:
    changed = tiny_panel.copy()
    target = changed.index[changed["sku_id"].eq("K001")][-1]
    changed.loc[target, "sales"] = 500.0
    original_features = add_time_features(tiny_panel, "start_of_day", min_history=5)
    changed_features = add_time_features(changed, "start_of_day", min_history=5)
    original = original_features.loc[original_features["sku_id"].eq("K001")].iloc[-1]
    updated = changed_features.loc[changed_features["sku_id"].eq("K001")].iloc[-1]
    assert updated["sales_used_for_streak"] == original["sales_used_for_streak"]
    assert updated["positive_stock_zero_streak"] == original["positive_stock_zero_streak"]
    assert updated["demand_deviation"] == original["demand_deviation"]


def test_missing_calendar_day_breaks_morning_zero_sales_streak() -> None:
    dates = pd.to_datetime(["2025-01-01", "2025-01-02", "2025-01-04", "2025-01-05"])
    panel = pd.DataFrame({
        "date": dates,
        "store_id": "S001",
        "sku_id": "SKU1",
        "sales": [0.0, 0.0, 0.0, 0.0],
        "on_hand": [6.0, 6.0, 6.0, 6.0],
    })
    features = add_time_features(panel, "start_of_day", min_history=1)
    assert features.loc[2, "days_since_previous_observation"] == 2
    assert pd.isna(features.loc[2, "sales_used_for_streak"])
    assert features.loc[2, "positive_stock_zero_streak"] == 0
    assert features.loc[3, "positive_stock_zero_streak"] == 1


def test_label_not_in_feature_matrix(tiny_panel: pd.DataFrame, cfg: dict) -> None:
    feats = build_features(tiny_panel, cfg)
    cols = feature_columns(feats, cfg)
    for banned in LABEL_LIKE | {"is_phantom", "date", "store_id", "sku_id"}:
        assert banned not in cols


def test_default_scoring_time_is_before_sales_close(cfg: dict) -> None:
    assert cfg["features"]["scoring_time"] == "start_of_day"
