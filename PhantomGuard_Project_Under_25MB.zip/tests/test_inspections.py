from __future__ import annotations

from src.inspections import latest_inspections, list_inspections, save_inspection


def test_inspection_persistence_status_and_history(tmp_path) -> None:
    db_path = tmp_path / "checks.sqlite3"

    first_id = save_inspection(db_path, "2024-02-01", "S01", "K01", "inspection_incomplete", "Shelf not checked")
    second_id = save_inspection(db_path, "2024-02-01", "S01", "K01", "not_found_either", "Manager notified")

    history = list_inspections(db_path)
    latest = latest_inspections(db_path)
    assert second_id > first_id
    assert len(history) == 2
    assert latest.iloc[0]["outcome"] == "not_found_either"
    assert latest.iloc[0]["status"] == "awaiting investigation"
    assert history.loc[history["id"] == first_id, "status"].iloc[0] == "pending"


def test_inspection_completed_for_physical_findings(tmp_path) -> None:
    db_path = tmp_path / "checks.sqlite3"
    save_inspection(db_path, "2024-02-01", "S01", "K01", "found_in_backroom")
    assert latest_inspections(db_path).iloc[0]["status"] == "completed"


def test_mark_checked_outcome_is_persisted_as_completed(tmp_path) -> None:
    db_path = tmp_path / "checks.sqlite3"
    save_inspection(db_path, "2024-02-01", "S01", "K01", "checked_no_issue")
    assert latest_inspections(db_path).iloc[0]["outcome"] == "checked_no_issue"
    assert latest_inspections(db_path).iloc[0]["status"] == "completed"


def test_found_elsewhere_outcome_is_persisted(tmp_path) -> None:
    db_path = tmp_path / "checks.sqlite3"
    save_inspection(db_path, "2024-02-01", "S01", "K01", "found_elsewhere")
    latest = latest_inspections(db_path).iloc[0]
    assert latest["outcome"] == "found_elsewhere"
    assert latest["status"] == "completed"
