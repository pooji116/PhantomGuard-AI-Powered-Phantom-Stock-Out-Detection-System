from __future__ import annotations

import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier

from src.features import build_features, feature_columns
from src.model import _predict_proba, chronological_split, matrix


def test_prediction_without_label_columns(tiny_panel: pd.DataFrame, cfg: dict) -> None:
    feats = build_features(tiny_panel, cfg)
    cols = feature_columns(feats, cfg)
    y = feats["is_phantom"].astype(int)
    est = HistGradientBoostingClassifier(max_iter=20, random_state=42)
    est.fit(matrix(feats, cfg, cols).fillna(0), y)
    unlabeled = feats.drop(columns=["is_phantom"])
    X = matrix(unlabeled, cfg, cols)
    proba = _predict_proba(est, X.fillna(0))
    assert len(proba) == len(unlabeled)
    assert "is_phantom" not in X.columns


def test_chronological_split_is_ordered(tiny_panel: pd.DataFrame, cfg: dict) -> None:
    train, valid, test = chronological_split(tiny_panel, cfg)
    assert train["date"].max() <= valid["date"].min()
    assert valid["date"].max() <= test["date"].min()


def test_insufficient_history_flag(tiny_panel: pd.DataFrame, cfg: dict) -> None:
    feats = build_features(tiny_panel, cfg)
    first = feats.sort_values(["sku_id", "date"]).groupby("sku_id").head(1)
    assert (first["insufficient_history"] == 1).all()
    last = feats.sort_values(["sku_id", "date"]).groupby("sku_id").tail(1)
    assert (last["insufficient_history"] == 0).all()


def test_empty_ranking(cfg: dict) -> None:
    from src.rank_alerts import rank_store_day_alerts

    empty = pd.DataFrame(
        columns=[
            "date",
            "store_id",
            "sku_id",
            "sales",
            "on_hand",
            "expected_demand",
            "history_days",
            "predicted_probability",
        ]
    )
    out = rank_store_day_alerts(empty, cfg)
    assert out.empty
