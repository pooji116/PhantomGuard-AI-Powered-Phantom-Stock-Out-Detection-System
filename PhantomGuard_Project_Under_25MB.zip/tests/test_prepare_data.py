from __future__ import annotations

import pandas as pd
import pytest

from src.prepare_data import DuplicateKeyError, join_with_cardinality_check, parse_dates, remap_columns, resolve_duplicates, validate_required
from src.prepare_data import build_master


def test_remap_and_required_columns() -> None:
    df = pd.DataFrame({"Date": ["2024-01-01"], "store": ["S1"], "sku": ["K1"], "qty": [1], "stock": [2]})
    mapping = {
        "date": "Date",
        "store_id": "store",
        "sku_id": "sku",
        "sales": "qty",
        "on_hand": "stock",
        "unit_price": "unit_price",
        "promo_flag": "promo_flag",
        "label": "is_phantom",
        "store_size": "store_size",
        "store_format": "format",
        "city_tier": "city_tier",
        "holiday_flag": "holiday_flag",
        "margin": "margin",
    }
    out = remap_columns(df, mapping)
    validate_required(out)
    assert set(["date", "store_id", "sku_id", "sales", "on_hand"]).issubset(out.columns)


def test_date_parsing_drops_invalid() -> None:
    df = pd.DataFrame({"date": ["2024-01-01", "not-a-date"], "store_id": ["A", "A"], "sku_id": ["1", "1"]})
    out = parse_dates(df, "%Y-%m-%d")
    assert len(out) == 1
    assert pd.api.types.is_datetime64_any_dtype(out["date"])


def test_identical_duplicates_dropped() -> None:
    df = pd.DataFrame(
        {
            "date": ["2024-01-01", "2024-01-01"],
            "store_id": ["S", "S"],
            "sku_id": ["K", "K"],
            "sales": [1, 1],
        }
    )
    cleaned, diag = resolve_duplicates(df, ["date", "store_id", "sku_id"], "fail")
    assert len(cleaned) == 1
    assert diag["identical_dropped"] == 1


def test_conflicting_duplicates_fail() -> None:
    df = pd.DataFrame(
        {
            "date": ["2024-01-01", "2024-01-01"],
            "store_id": ["S", "S"],
            "sku_id": ["K", "K"],
            "sales": [1, 9],
        }
    )
    with pytest.raises(DuplicateKeyError):
        resolve_duplicates(df, ["date", "store_id", "sku_id"], "fail")


def test_missing_required_raises() -> None:
    with pytest.raises(ValueError, match="Required columns"):
        validate_required(pd.DataFrame({"date": [1]}))


def test_join_reports_unmatched_rows() -> None:
    left = pd.DataFrame({"key": ["a", "b"], "sales": [1, 2]})
    right = pd.DataFrame({"key": ["a", "c"], "stock": [3, 4]})
    _, diagnostics = join_with_cardinality_check(left, right, ["key"], "left", "inventory")
    assert diagnostics["unmatched_left"] == 1
    assert diagnostics["unmatched_right"] == 1


def test_combined_csv_ingestion_maps_source_headers_and_validates(tmp_path, cfg: dict) -> None:
    from src.config import project_root

    raw = tmp_path / "raw"
    raw.mkdir()
    pd.DataFrame({
        "Date": ["2024-01-01", "2024-01-02"],
        "Store ID": ["S1", "S1"],
        "Product ID": ["P1", "P1"],
        "Units Sold": [2, 0],
        "Inventory Level": [5, 5],
        "Price": [10.0, 10.0],
        "Promotion": [0, 0],
    }).to_csv(raw / "combined.csv", index=False)
    import copy
    local = copy.deepcopy(cfg)
    local["paths"]["raw_dir"] = str(raw)
    local["files"].update({"sales": "combined.csv", "inventory": "combined.csv", "labels": "not_present.csv", "stores": "not_present.csv", "promotions": "not_present.csv"})
    from src.prepare_data import build_master
    master, report = build_master(local)
    assert len(master) == 2
    assert master["sales"].tolist() == [2, 0]
    assert master["on_hand"].tolist() == [5, 5]
    assert report["input_layout"] == "combined sales and inventory panel"
    assert report["signal_support"]["positive_stock_zero_sales_rows"] == 1
