from __future__ import annotations

import pandas as pd

from src.queue_data import (
    attach_inventory_verification,
    classify_queue_candidates,
    deduplicate_daily_rows,
    filter_store_day,
    priority_from_evidence,
)
from src.rank_alerts import generate_reason


def test_store_and_business_date_filtering_is_exact() -> None:
    rows = pd.DataFrame([
        {"date": "2025-07-01", "store_id": "S001", "sku_id": "SKU1"},
        {"date": "2025-07-02", "store_id": "S001", "sku_id": "SKU2"},
        {"date": "2025-07-01", "store_id": "S002", "sku_id": "SKU3"},
    ])
    selected = filter_store_day(rows, "S001", "2025-07-01")
    assert selected[["store_id", "sku_id"]].to_dict("records") == [
        {"store_id": "S001", "sku_id": "SKU1"}
    ]


def test_duplicate_key_keeps_latest_inventory_state_as_one_intact_row() -> None:
    duplicate_rows = pd.DataFrame([
        {"date": "2025-07-01", "store_id": "S001", "sku_id": "SKU1", "updated_at": "2025-07-01T08:00:00", "on_hand": 49, "sales": 0, "reason": "49 units"},
        {"date": "2025-07-01", "store_id": "S001", "sku_id": "SKU1", "updated_at": "2025-07-01T09:00:00", "on_hand": 46, "sales": 1, "reason": "46 units"},
    ])
    result = deduplicate_daily_rows(duplicate_rows)
    assert len(result) == 1
    assert result.iloc[0]["on_hand"] == 46
    assert result.iloc[0]["reason"] == "46 units"


def test_ranked_duplicate_uses_best_existing_rank() -> None:
    duplicate_rows = pd.DataFrame([
        {"date": "2025-07-01", "store_id": "S001", "sku_id": "SKU1", "rank": 2, "priority_score": 50, "on_hand": 47},
        {"date": "2025-07-01", "store_id": "S001", "sku_id": "SKU1", "rank": 1, "priority_score": 40, "on_hand": 49},
    ])
    result = deduplicate_daily_rows(duplicate_rows, ranked=True)
    assert len(result) == 1
    assert result.iloc[0]["rank"] == 1
    assert result.iloc[0]["on_hand"] == 49


def test_verified_count_never_overwrites_system_stock_or_its_explanation() -> None:
    source = pd.DataFrame([{
        "date": "2025-07-01",
        "store_id": "S001",
        "sku_id": "SKU0772",
        "on_hand": 49,
        "sales": 0,
        "positive_stock_zero_streak": 1,
        "sales_mean_7": 5.0,
    }])
    explanation = generate_reason(source.iloc[0])
    result = attach_inventory_verification(
        source,
        {"SKU0772": 0},
        {"SKU0772": "stock_missing"},
        key_column="sku_id",
    )
    assert result.iloc[0]["on_hand"] == 49
    assert result.iloc[0]["system_recorded_on_hand"] == 49
    assert result.iloc[0]["verified_on_hand"] == 0
    assert "49 units" in explanation
    assert generate_reason(result.iloc[0]) == explanation


def test_priority_tiers_follow_risk_score_and_signal_persistence(cfg: dict) -> None:
    scored = [
        priority_from_evidence(300, 3, cfg),
        priority_from_evidence(150, 2, cfg),
        priority_from_evidence(40, 1, cfg),
        priority_from_evidence(10, 1, cfg),
        priority_from_evidence(float("nan"), float("nan"), cfg),
    ]
    assert scored == ["Critical", "High", "Medium", "Low", "Low"]


def test_signal_labels_distinguish_supported_patterns_and_remain_hypotheses() -> None:
    dates = pd.date_range("2025-05-07", periods=56, freq="D")
    candidates: list[dict[str, object]] = []
    history: list[dict[str, object]] = []
    store_rows = [{"store_id": store, "city_tier": "T1"} for store in ["S001", "S002", "S003"]]

    def add_series(sku: str, sales: list[float], stock: list[float], stores: list[str] | None = None) -> None:
        candidates.append({"date": dates[-1] + pd.DateOffset(days=1), "store_id": "S001", "sku_id": sku})
        active_stores = stores or ["S001"]
        for store in active_stores:
            for index, day in enumerate(dates):
                history.append({
                    "date": day,
                    "store_id": store,
                    "sku_id": sku,
                    "sales": sales[index],
                    "on_hand": stock[index],
                    "unit_price": 10.0,
                })

    steady_to_zero = [2.0] * 49 + [0.0] * 7
    steady_stock = [8.0] * 56
    add_series("PHANTOM", steady_to_zero, steady_stock)

    rebound_sales = [2.0] * 49 + [0.0] * 6 + [2.0]
    changing_stock = [10.0] * 49 + [10.0, 9.0, 8.0, 7.0, 6.0, 5.0, 4.0]
    add_series("MISPLACED", rebound_sales, changing_stock)

    regional_sales = [2.0] * 49 + [0.0] * 7
    add_series("DELISTED", regional_sales, steady_stock, ["S001", "S002", "S003"])

    slow_sales = [1.0] + [0.0] * 42 + [1.0] + [0.0] * 12
    add_series("SLOW", slow_sales, steady_stock)

    labels = classify_queue_candidates(
        pd.DataFrame(candidates), pd.DataFrame(history), pd.DataFrame(store_rows), dates[-1] + pd.DateOffset(days=1)
    )
    assert labels == {
        "PHANTOM": "POSSIBLE_PHANTOM_STOCKOUT",
        "MISPLACED": "POSSIBLE_MISPLACED",
        "DELISTED": "POSSIBLE_DELISTED",
        "SLOW": "NORMAL_SLOW_MOVER",
    }


def test_missing_history_does_not_invent_a_root_cause() -> None:
    candidates = pd.DataFrame([{"date": "2025-07-01", "store_id": "S001", "sku_id": "SKU1"}])
    labels = classify_queue_candidates(candidates, pd.DataFrame(), None, "2025-07-01")
    assert labels == {"SKU1": "UNSPECIFIED_DISCREPANCY"}


def test_morning_root_cause_ignores_selected_date_sales() -> None:
    dates = pd.date_range("2025-01-01", periods=8, freq="D")
    history = pd.DataFrame({
        "date": list(dates) + [dates[-1] + pd.DateOffset(days=1)],
        "store_id": ["S001"] * 9,
        "sku_id": ["SKU1"] * 9,
        "sales": [2.0] * 5 + [0.0] * 3 + [50.0],
        "on_hand": [10.0] * 9,
        "unit_price": [10.0] * 9,
    })
    candidates = pd.DataFrame([{
        "date": dates[-1] + pd.DateOffset(days=1),
        "store_id": "S001",
        "sku_id": "SKU1",
        "on_hand": 10.0,
    }])
    history_with_changed_current_sales = history.copy()
    history_with_changed_current_sales.loc[
        history_with_changed_current_sales["date"].eq(candidates.iloc[0]["date"]), "sales"
    ] = 500.0
    first = classify_queue_candidates(
        candidates, history, None, candidates.iloc[0]["date"], "start_of_day"
    )
    second = classify_queue_candidates(
        candidates, history_with_changed_current_sales, None, candidates.iloc[0]["date"], "start_of_day"
    )
    assert first == second == {"SKU1": "POSSIBLE_PHANTOM_STOCKOUT"}
