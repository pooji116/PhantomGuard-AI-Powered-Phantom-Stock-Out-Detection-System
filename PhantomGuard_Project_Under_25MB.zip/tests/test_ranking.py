from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from src.baseline import generate_baseline_reason, score_baseline
from src.features import build_features
from src.queue_data import deduplicate_daily_rows
from src.rank_alerts import generate_reason, rank_store_day_alerts


def _many_skus(n_skus: int = 30, days: int = 3) -> pd.DataFrame:
    rows = []
    dates = pd.date_range("2024-06-01", periods=days, freq="D")
    for d in dates:
        for i in range(n_skus):
            rows.append(
                {
                    "date": d,
                    "store_id": "S01",
                    "sku_id": f"K{i:03d}",
                    "sales": 0.0,
                    "sales_lag_1": 0.0,
                    "days_since_previous_observation": 1,
                    "on_hand": 6.0,
                    "unit_price": 10.0 + i,
                    "expected_demand": 1.0 + i * 0.1,
                    "history_days": 30,
                    "positive_stock_zero_streak": 5,
                    "zero_sales_streak": 5,
                    "promo_flag": 0,
                    "predicted_probability": 0.2 + (i / 100.0),
                    "sales_velocity": 1.0,
                    "insufficient_history": 0,
                }
            )
            rows.append(
                {
                    "date": d,
                    "store_id": "S02",
                    "sku_id": f"K{i:03d}",
                    "sales": 0.0,
                    "sales_lag_1": 0.0,
                    "days_since_previous_observation": 1,
                    "on_hand": 6.0,
                    "unit_price": 10.0 + i,
                    "expected_demand": 1.0,
                    "history_days": 30,
                    "positive_stock_zero_streak": 5,
                    "zero_sales_streak": 5,
                    "promo_flag": 0,
                    "predicted_probability": 0.5,
                    "sales_velocity": 1.0,
                    "insufficient_history": 0,
                }
            )
    return pd.DataFrame(rows)


def test_never_more_than_20_per_store_day(cfg: dict) -> None:
    ranked = rank_store_day_alerts(_many_skus(), cfg)
    sizes = ranked.groupby(["store_id", "date"]).size()
    assert sizes.max() <= 20
    assert (sizes <= 20).all()


def test_does_not_pad_to_twenty(cfg: dict) -> None:
    df = _many_skus(n_skus=4, days=1)
    ranked = rank_store_day_alerts(df, cfg)
    assert ranked.groupby(["store_id", "date"]).size().max() == 4


def test_duplicate_sku_store_day_keeps_latest_inventory_snapshot(cfg: dict) -> None:
    df = _many_skus(n_skus=1, days=1)
    duplicate = df.iloc[[0]].copy()
    df["inventory_updated_at"] = pd.Timestamp("2024-06-01 08:00:00")
    duplicate["inventory_updated_at"] = pd.Timestamp("2024-06-01 18:00:00")
    duplicate["on_hand"] = 0
    source = pd.concat([df, duplicate], ignore_index=True)
    latest = deduplicate_daily_rows(source)
    selected = latest.loc[latest["store_id"].eq("S01") & latest["sku_id"].eq("K000")]
    assert len(selected) == 1
    assert selected.iloc[0]["on_hand"] == 0
    ranked = rank_store_day_alerts(source, cfg)
    selected = ranked.loc[ranked["store_id"].eq("S01") & ranked["sku_id"].eq("K000")]
    assert selected.empty  # latest on-hand is zero, so it is no longer actionable


def test_queue_contains_unique_skus_per_store_day(cfg: dict) -> None:
    ranked = rank_store_day_alerts(_many_skus(), cfg)
    assert not ranked.duplicated(["date", "store_id", "sku_id"]).any()
    counts = ranked.groupby(["date", "store_id"]).size()
    unique_counts = ranked.groupby(["date", "store_id"])["sku_id"].nunique()
    assert (counts == unique_counts).all()


def test_queue_risk_order_descends_within_store_day(cfg: dict) -> None:
    ranked = rank_store_day_alerts(_many_skus(), cfg)
    for _, group in ranked.groupby(["store_id", "date"]):
        scores = group["priority_score"].to_numpy()
        assert (scores[:-1] >= scores[1:]).all()


def test_morning_ranking_uses_yesterday_sales_and_rejects_calendar_gaps(cfg: dict) -> None:
    df = _many_skus(n_skus=2, days=1)
    df["sales"] = 8.0
    ranked = rank_store_day_alerts(df, cfg)
    assert len(ranked) == 4
    assert ranked["reason"].str.contains("consecutive completed day").all()

    df.loc[df.index[0], "days_since_previous_observation"] = 2
    ranked_after_gap = rank_store_day_alerts(df, cfg)
    assert not ((ranked_after_gap["store_id"] == "S01") & (ranked_after_gap["sku_id"] == "K000")).any()


def test_daily_queue_requires_two_consecutive_completed_zero_sales_days(cfg: dict) -> None:
    df = _many_skus(n_skus=1, days=1)
    df["positive_stock_zero_streak"] = 1
    assert rank_store_day_alerts(df, cfg).empty
    df["positive_stock_zero_streak"] = 2
    assert len(rank_store_day_alerts(df, cfg)) == 2


def test_priority_score_formula(cfg: dict) -> None:
    df = _many_skus(n_skus=5, days=1)
    ranked = rank_store_day_alerts(df, cfg)
    recoverable = float(cfg["ranking"]["recoverable_fraction"])
    expected = ranked["predicted_probability"] * ranked["expected_demand"] * ranked["unit_price"] * recoverable
    assert np.allclose(ranked["priority_score"], expected)
    assert (ranked["ranking_mode"] == "probability_times_expected_daily_revenue_loss").all()


def test_missing_price_fallback_probability_only(cfg: dict) -> None:
    df = _many_skus(n_skus=5, days=1).drop(columns=["unit_price"])
    local = dict(cfg)
    local["ranking"] = dict(cfg["ranking"])
    local["ranking"]["fallback_unit_price"] = None
    ranked = rank_store_day_alerts(df, local)
    assert (ranked["ranking_mode"] == "probability_only").all()
    assert ranked["priority_score"].equals(ranked["predicted_probability"])


def test_deterministic_reasons() -> None:
    row = pd.Series(
        {
            "on_hand": 6,
            "positive_stock_zero_streak": 6,
            "expected_demand": 1.5,
            "sales": 0,
            "promo_flag": 0,
        }
    )
    a = generate_reason(row)
    b = generate_reason(row)
    assert a == b
    assert "6 units" in a
    assert "Check the shelf, then check the backroom" in a
    assert "theft" not in a.lower()


def test_morning_reason_uses_last_completed_sales_day() -> None:
    row = pd.Series({
        "on_hand": 6,
        "sales": 12,
        "sales_lag_1": 0,
        "positive_stock_zero_streak": 2,
        "expected_demand": 1.5,
        "sales_mean_7": 1.5,
        "promo_flag": 0,
    })
    reason = generate_reason(row, scoring_time="start_of_day")
    assert "no sales were recorded for 2 consecutive completed day(s)" in reason
    assert "12 units were sold" not in reason


def test_baseline_deterministic(tiny_panel: pd.DataFrame, cfg: dict) -> None:
    feats = build_features(tiny_panel, cfg)
    a = score_baseline(feats, cfg)
    b = score_baseline(feats, cfg)
    pd.testing.assert_series_equal(a["baseline_score"], b["baseline_score"])
    row = a.iloc[-1]
    assert generate_baseline_reason(row) == generate_baseline_reason(row)


def test_baseline_score_does_not_use_future_panel_quantiles(cfg: dict) -> None:
    historical = _many_skus(n_skus=1, days=1)
    historical["positive_sales_days_28"] = 10
    historical["stock_to_demand_ratio"] = 5.0
    first = score_baseline(historical, cfg).iloc[0]["baseline_score"]
    future = historical.copy()
    future["date"] = pd.Timestamp("2025-01-01")
    future["expected_demand"] = 10_000.0
    combined = score_baseline(pd.concat([historical, future], ignore_index=True), cfg).iloc[0]["baseline_score"]
    assert first == combined
